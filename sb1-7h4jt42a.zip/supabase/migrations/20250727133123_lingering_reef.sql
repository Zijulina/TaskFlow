/*
  # Create check_email_exists function

  1. New Function
    - `check_email_exists(email_to_check text)` - Checks if email exists in auth.users
    - Returns boolean (true if exists, false if not)
    - Uses SECURITY DEFINER to access auth schema
    - Safe for public use via RPC calls

  2. Security
    - SECURITY DEFINER allows function to access auth.users
    - Function is safe as it only returns boolean existence check
    - No sensitive data is exposed
*/

CREATE OR REPLACE FUNCTION public.check_email_exists(email_to_check text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    email_exists boolean;
BEGIN
    -- Check if email exists in auth.users table
    SELECT EXISTS (
        SELECT 1 
        FROM auth.users 
        WHERE email = email_to_check
    ) INTO email_exists;
    
    RETURN email_exists;
END;
$$;

-- Grant execute permission to authenticated and anonymous users
GRANT EXECUTE ON FUNCTION public.check_email_exists(text) TO anon;
GRANT EXECUTE ON FUNCTION public.check_email_exists(text) TO authenticated;