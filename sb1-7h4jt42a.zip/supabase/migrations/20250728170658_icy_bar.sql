/*
  # Remove unused database tables

  This migration removes tables that are not being used in the application to simplify the database schema and improve performance.

  ## Tables being removed:
  1. `subtasks` - Subtasks functionality not implemented
  2. `task_tags` - Tag relationship table (tags system not fully implemented)
  3. `task_reminders` - Reminder system not implemented
  4. `weekly_plans` - Weekly planning not implemented
  5. `task_groupings` - Advanced grouping not implemented
  6. `email_tracking` - Basic tracking system not needed

  ## Security:
  - All related policies and triggers will be automatically removed
  - Foreign key constraints will be handled automatically

  ## Notes:
  - This will permanently delete these tables and all their data
  - Make sure to backup if you plan to implement these features later
*/

-- Remove task_tags table (many-to-many relationship)
DROP TABLE IF EXISTS task_tags CASCADE;

-- Remove subtasks table
DROP TABLE IF EXISTS subtasks CASCADE;

-- Remove task_reminders table
DROP TABLE IF EXISTS task_reminders CASCADE;

-- Remove weekly_plans table
DROP TABLE IF EXISTS weekly_plans CASCADE;

-- Remove task_groupings table
DROP TABLE IF EXISTS task_groupings CASCADE;

-- Remove email_tracking table
DROP TABLE IF EXISTS email_tracking CASCADE;

-- Clean up any orphaned functions that might reference these tables
-- (The triggers and policies are automatically removed with CASCADE)

-- Update tasks table to remove unused columns if any exist
-- (keeping all current columns as they might be used)

-- Verify remaining tables are clean
-- The following tables are kept as they are actively used:
-- - users (user profiles)
-- - tasks (main functionality)
-- - projects (used in dashboard)
-- - tags (used in useTasks hook)
-- - task_history (completed tasks history)
-- - productivity_stats (statistics with triggers)
-- - stripe_customers (payment system)
-- - stripe_subscriptions (payment system)
-- - stripe_orders (payment system)
-- - feedback (feedback system)
-- - piggy_bank (piggy bank page)
-- - piggy_transactions (piggy bank page)
-- - investments (piggy bank page)
-- - financial_goals (piggy bank page)
-- - user_preferences (theme system)