/*
  # Sistema de Auditoria para Exclusão de Contas - Conformidade LGPD

  1. Nova Tabela
    - `account_deletion_audit`
      - `id` (uuid, primary key)
      - `user_id` (uuid) - ID do usuário excluído (não é FK pois usuário será excluído)
      - `email_hash` (text) - Hash do email para auditoria sem expor dados pessoais
      - `deletion_timestamp` (timestamptz) - Quando a exclusão foi processada
      - `ip_address` (text) - IP de onde veio a solicitação
      - `user_agent` (text) - User agent do navegador
      - `deleted_records` (jsonb) - Contagem de registros excluídos por tabela
      - `lgpd_compliance` (boolean) - Confirmação de conformidade LGPD
      - `created_at` (timestamptz) - Timestamp de criação do log

  2. Segurança
    - Tabela apenas para auditoria (sem RLS)
    - Dados anonimizados para proteção de privacidade
    - Retenção de logs por período legal obrigatório

  3. Função
    - Função para criar hash anônimo do email
    - Trigger para limpeza automática de logs antigos
*/

-- Criar tabela de auditoria para exclusões de conta
CREATE TABLE IF NOT EXISTS account_deletion_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL, -- Não é FK pois usuário será excluído
  email_hash text NOT NULL, -- Hash SHA-256 do email para auditoria anônima
  deletion_timestamp timestamptz NOT NULL DEFAULT now(),
  ip_address text,
  user_agent text,
  deleted_records jsonb DEFAULT '{}',
  lgpd_compliance boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Criar índices para consultas de auditoria
CREATE INDEX IF NOT EXISTS idx_account_deletion_audit_timestamp ON account_deletion_audit(deletion_timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_account_deletion_audit_user_id ON account_deletion_audit(user_id);
CREATE INDEX IF NOT EXISTS idx_account_deletion_audit_created_at ON account_deletion_audit(created_at DESC);

-- Função para criar hash anônimo do email
CREATE OR REPLACE FUNCTION create_email_hash(email_input text)
RETURNS text AS $$
BEGIN
  -- Criar hash SHA-256 do email para auditoria anônima
  RETURN encode(digest(lower(trim(email_input)), 'sha256'), 'hex');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para registrar exclusão de conta
CREATE OR REPLACE FUNCTION log_account_deletion(
  p_user_id uuid,
  p_email text,
  p_ip_address text DEFAULT NULL,
  p_user_agent text DEFAULT NULL,
  p_deleted_records jsonb DEFAULT '{}'
)
RETURNS uuid AS $$
DECLARE
  audit_id uuid;
BEGIN
  INSERT INTO account_deletion_audit (
    user_id,
    email_hash,
    deletion_timestamp,
    ip_address,
    user_agent,
    deleted_records,
    lgpd_compliance
  ) VALUES (
    p_user_id,
    create_email_hash(p_email),
    now(),
    p_ip_address,
    p_user_agent,
    p_deleted_records,
    true
  ) RETURNING id INTO audit_id;
  
  RETURN audit_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Função para limpeza automática de logs antigos (após 5 anos conforme LGPD)
CREATE OR REPLACE FUNCTION cleanup_old_audit_logs()
RETURNS void AS $$
BEGIN
  -- Excluir logs de auditoria com mais de 5 anos
  DELETE FROM account_deletion_audit 
  WHERE created_at < (CURRENT_DATE - INTERVAL '5 years');
  
  -- Log da limpeza
  RAISE NOTICE 'Limpeza de logs de auditoria executada em %', now();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Criar função para executar limpeza automática (pode ser chamada por cron job)
-- Esta função deve ser executada periodicamente (ex: mensalmente)
CREATE OR REPLACE FUNCTION schedule_audit_cleanup()
RETURNS void AS $$
BEGIN
  PERFORM cleanup_old_audit_logs();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Comentários para documentação
COMMENT ON TABLE account_deletion_audit IS 'Tabela de auditoria para exclusões de conta - Conformidade LGPD';
COMMENT ON COLUMN account_deletion_audit.email_hash IS 'Hash SHA-256 do email para auditoria anônima';
COMMENT ON COLUMN account_deletion_audit.lgpd_compliance IS 'Confirmação de que a exclusão seguiu os requisitos da LGPD';
COMMENT ON FUNCTION create_email_hash(text) IS 'Cria hash anônimo do email para auditoria sem expor dados pessoais';
COMMENT ON FUNCTION log_account_deletion(uuid, text, text, text, jsonb) IS 'Registra exclusão de conta para auditoria LGPD';
COMMENT ON FUNCTION cleanup_old_audit_logs() IS 'Remove logs de auditoria com mais de 5 anos conforme LGPD';