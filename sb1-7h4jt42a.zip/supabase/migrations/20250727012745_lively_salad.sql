/*
  # Fix users table created_at column default value

  1. Changes
    - Add DEFAULT now() to the created_at column in users table
    - This resolves the "Database error saving new user" issue during signup

  2. Security
    - No changes to existing RLS policies
    - Maintains existing table structure and constraints
*/

-- Add default value to created_at column if it doesn't already have one
DO $$
BEGIN
  -- Check if the column exists and update its default value
  IF EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'users' 
    AND column_name = 'created_at' 
    AND table_schema = 'public'
  ) THEN
    ALTER TABLE users ALTER COLUMN created_at SET DEFAULT now();
  END IF;
END $$;