/*
  # Add name column to users table

  1. Changes
    - Add `name` column to `users` table
    - Set default value as empty string
    - Make it nullable to handle existing users

  2. Security
    - No RLS changes needed as existing policies cover the new column
*/

-- Add name column to users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'name'
  ) THEN
    ALTER TABLE users ADD COLUMN name text;
  END IF;
END $$;