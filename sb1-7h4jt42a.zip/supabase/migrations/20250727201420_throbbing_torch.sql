/*
  # Add Essential Plan Features

  1. New Tables
    - `projects` - For organizing tasks into projects
    - `subtasks` - For breaking down tasks into smaller items
    - `tags` - For organizing and categorizing tasks
    - `task_tags` - Many-to-many relationship between tasks and tags
    - `task_reminders` - For smart reminders and notifications
    - `task_history` - For tracking completed tasks history
    - `productivity_stats` - For weekly productivity statistics

  2. Enhanced Tasks Table
    - Add priority, due_date, estimated_time, focus_mode fields
    - Add project_id foreign key

  3. Security
    - Enable RLS on all new tables
    - Add policies for authenticated users to manage their own data

  4. Indexes
    - Add performance indexes for common queries
*/

-- Create projects table
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  color text DEFAULT '#3b82f6',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own projects"
  ON projects
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create tags table
CREATE TABLE IF NOT EXISTS tags (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  color text DEFAULT '#6b7280',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE tags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own tags"
  ON tags
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Add unique constraint for user_id + name
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_name = 'tags' AND constraint_name = 'tags_user_id_name_key'
  ) THEN
    ALTER TABLE tags ADD CONSTRAINT tags_user_id_name_key UNIQUE (user_id, name);
  END IF;
END $$;

-- Enhance tasks table with new fields
DO $$
BEGIN
  -- Add project_id column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tasks' AND column_name = 'project_id'
  ) THEN
    ALTER TABLE tasks ADD COLUMN project_id uuid REFERENCES projects(id) ON DELETE SET NULL;
  END IF;

  -- Add priority column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tasks' AND column_name = 'priority'
  ) THEN
    ALTER TABLE tasks ADD COLUMN priority text DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high', 'urgent'));
  END IF;

  -- Add due_date column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tasks' AND column_name = 'due_date'
  ) THEN
    ALTER TABLE tasks ADD COLUMN due_date timestamptz;
  END IF;

  -- Add estimated_time column (in minutes)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tasks' AND column_name = 'estimated_time'
  ) THEN
    ALTER TABLE tasks ADD COLUMN estimated_time integer;
  END IF;

  -- Add focus_mode column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tasks' AND column_name = 'focus_mode'
  ) THEN
    ALTER TABLE tasks ADD COLUMN focus_mode boolean DEFAULT false;
  END IF;

  -- Add completed_at column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tasks' AND column_name = 'completed_at'
  ) THEN
    ALTER TABLE tasks ADD COLUMN completed_at timestamptz;
  END IF;
END $$;

-- Create subtasks table
CREATE TABLE IF NOT EXISTS subtasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  title text NOT NULL,
  is_done boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz
);

ALTER TABLE subtasks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage subtasks of own tasks"
  ON subtasks
  FOR ALL
  TO authenticated
  USING (
    task_id IN (
      SELECT id FROM tasks WHERE user_id = auth.uid()
    )
  )
  WITH CHECK (
    task_id IN (
      SELECT id FROM tasks WHERE user_id = auth.uid()
    )
  );

-- Create task_tags junction table
CREATE TABLE IF NOT EXISTS task_tags (
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  tag_id uuid NOT NULL REFERENCES tags(id) ON DELETE CASCADE,
  created_at timestamptz DEFAULT now(),
  PRIMARY KEY (task_id, tag_id)
);

ALTER TABLE task_tags ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage task tags for own tasks"
  ON task_tags
  FOR ALL
  TO authenticated
  USING (
    task_id IN (
      SELECT id FROM tasks WHERE user_id = auth.uid()
    )
  )
  WITH CHECK (
    task_id IN (
      SELECT id FROM tasks WHERE user_id = auth.uid()
    )
  );

-- Create task_reminders table
CREATE TABLE IF NOT EXISTS task_reminders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  reminder_time timestamptz NOT NULL,
  is_sent boolean DEFAULT false,
  reminder_type text DEFAULT 'due_date' CHECK (reminder_type IN ('due_date', 'custom', 'smart')),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE task_reminders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage reminders for own tasks"
  ON task_reminders
  FOR ALL
  TO authenticated
  USING (
    task_id IN (
      SELECT id FROM tasks WHERE user_id = auth.uid()
    )
  )
  WITH CHECK (
    task_id IN (
      SELECT id FROM tasks WHERE user_id = auth.uid()
    )
  );

-- Create task_history table for tracking completed tasks
CREATE TABLE IF NOT EXISTS task_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  task_id uuid, -- Can be null if original task is deleted
  title text NOT NULL,
  project_name text,
  tags text[], -- Store tag names as array
  priority text,
  estimated_time integer,
  completed_at timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE task_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own task history"
  ON task_history
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "System can insert task history"
  ON task_history
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create productivity_stats table
CREATE TABLE IF NOT EXISTS productivity_stats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  week_start_date date NOT NULL,
  tasks_completed integer DEFAULT 0,
  tasks_created integer DEFAULT 0,
  total_estimated_time integer DEFAULT 0, -- in minutes
  total_actual_time integer DEFAULT 0, -- in minutes
  focus_sessions integer DEFAULT 0,
  productivity_score decimal(5,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE productivity_stats ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can manage own productivity stats"
  ON productivity_stats
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Add unique constraint for user_id + week_start_date
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_name = 'productivity_stats' AND constraint_name = 'productivity_stats_user_week_key'
  ) THEN
    ALTER TABLE productivity_stats ADD CONSTRAINT productivity_stats_user_week_key UNIQUE (user_id, week_start_date);
  END IF;
END $$;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_projects_user_id ON projects(user_id);
CREATE INDEX IF NOT EXISTS idx_tags_user_id ON tags(user_id);
CREATE INDEX IF NOT EXISTS idx_subtasks_task_id ON subtasks(task_id);
CREATE INDEX IF NOT EXISTS idx_task_tags_task_id ON task_tags(task_id);
CREATE INDEX IF NOT EXISTS idx_task_tags_tag_id ON task_tags(tag_id);
CREATE INDEX IF NOT EXISTS idx_task_reminders_task_id ON task_reminders(task_id);
CREATE INDEX IF NOT EXISTS idx_task_reminders_reminder_time ON task_reminders(reminder_time);
CREATE INDEX IF NOT EXISTS idx_task_history_user_id ON task_history(user_id);
CREATE INDEX IF NOT EXISTS idx_task_history_completed_at ON task_history(completed_at DESC);
CREATE INDEX IF NOT EXISTS idx_productivity_stats_user_week ON productivity_stats(user_id, week_start_date);
CREATE INDEX IF NOT EXISTS idx_tasks_project_id ON tasks(project_id);
CREATE INDEX IF NOT EXISTS idx_tasks_priority ON tasks(priority);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date);

-- Function to automatically create task history when task is completed
CREATE OR REPLACE FUNCTION create_task_history()
RETURNS TRIGGER AS $$
BEGIN
  -- Only create history when task is marked as done
  IF NEW.is_done = true AND (OLD.is_done = false OR OLD.is_done IS NULL) THEN
    INSERT INTO task_history (
      user_id,
      task_id,
      title,
      project_name,
      tags,
      priority,
      estimated_time,
      completed_at
    )
    SELECT 
      NEW.user_id,
      NEW.id,
      NEW.title,
      p.name,
      COALESCE(
        ARRAY(
          SELECT t.name 
          FROM tags t 
          JOIN task_tags tt ON t.id = tt.tag_id 
          WHERE tt.task_id = NEW.id
        ),
        ARRAY[]::text[]
      ),
      NEW.priority,
      NEW.estimated_time,
      COALESCE(NEW.completed_at, now())
    FROM tasks
    LEFT JOIN projects p ON p.id = NEW.project_id
    WHERE tasks.id = NEW.id;
    
    -- Update completed_at timestamp
    NEW.completed_at = COALESCE(NEW.completed_at, now());
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for task history
DROP TRIGGER IF EXISTS trigger_create_task_history ON tasks;
CREATE TRIGGER trigger_create_task_history
  BEFORE UPDATE ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION create_task_history();

-- Function to update productivity stats
CREATE OR REPLACE FUNCTION update_productivity_stats()
RETURNS TRIGGER AS $$
DECLARE
  week_start date;
BEGIN
  -- Calculate week start (Monday)
  week_start := date_trunc('week', CURRENT_DATE)::date;
  
  -- Insert or update productivity stats
  INSERT INTO productivity_stats (
    user_id,
    week_start_date,
    tasks_completed,
    tasks_created
  )
  VALUES (
    NEW.user_id,
    week_start,
    CASE WHEN NEW.is_done THEN 1 ELSE 0 END,
    1
  )
  ON CONFLICT (user_id, week_start_date)
  DO UPDATE SET
    tasks_completed = productivity_stats.tasks_completed + CASE WHEN NEW.is_done THEN 1 ELSE 0 END,
    tasks_created = productivity_stats.tasks_created + 1,
    updated_at = now();
    
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for productivity stats on task insert
DROP TRIGGER IF EXISTS trigger_update_productivity_stats_insert ON tasks;
CREATE TRIGGER trigger_update_productivity_stats_insert
  AFTER INSERT ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION update_productivity_stats();

-- Function to update productivity stats on task completion
CREATE OR REPLACE FUNCTION update_productivity_stats_completion()
RETURNS TRIGGER AS $$
DECLARE
  week_start date;
BEGIN
  -- Only update when task is marked as completed
  IF NEW.is_done = true AND (OLD.is_done = false OR OLD.is_done IS NULL) THEN
    week_start := date_trunc('week', CURRENT_DATE)::date;
    
    INSERT INTO productivity_stats (
      user_id,
      week_start_date,
      tasks_completed
    )
    VALUES (
      NEW.user_id,
      week_start,
      1
    )
    ON CONFLICT (user_id, week_start_date)
    DO UPDATE SET
      tasks_completed = productivity_stats.tasks_completed + 1,
      updated_at = now();
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for productivity stats on task completion
DROP TRIGGER IF EXISTS trigger_update_productivity_stats_completion ON tasks;
CREATE TRIGGER trigger_update_productivity_stats_completion
  AFTER UPDATE ON tasks
  FOR EACH ROW
  EXECUTE FUNCTION update_productivity_stats_completion();