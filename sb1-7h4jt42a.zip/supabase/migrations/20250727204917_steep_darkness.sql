/*
  # Add Weekly Planning Features for Pro Plan

  1. New Tables
    - `weekly_plans`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `week_start_date` (date)
      - `goals` (text array)
      - `notes` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `task_groupings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `name` (text)
      - `grouping_type` (enum: 'tag', 'context', 'time_estimate')
      - `criteria` (jsonb)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for authenticated users to manage their own data

  3. Enhancements
    - Add indexes for performance
    - Add constraints for data integrity
*/

-- Create enum for grouping types
CREATE TYPE grouping_type AS ENUM ('tag', 'context', 'time_estimate', 'priority', 'project');

-- Create weekly_plans table
CREATE TABLE IF NOT EXISTS weekly_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  week_start_date date NOT NULL,
  goals text[] DEFAULT '{}',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id, week_start_date)
);

-- Create task_groupings table
CREATE TABLE IF NOT EXISTS task_groupings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  grouping_type grouping_type NOT NULL,
  criteria jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE weekly_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_groupings ENABLE ROW LEVEL SECURITY;

-- Create policies for weekly_plans
CREATE POLICY "Users can manage own weekly plans"
  ON weekly_plans
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create policies for task_groupings
CREATE POLICY "Users can manage own task groupings"
  ON task_groupings
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_weekly_plans_user_week ON weekly_plans(user_id, week_start_date);
CREATE INDEX IF NOT EXISTS idx_task_groupings_user_id ON task_groupings(user_id);
CREATE INDEX IF NOT EXISTS idx_task_groupings_type ON task_groupings(grouping_type);

-- Add trigger to update updated_at on weekly_plans
CREATE OR REPLACE FUNCTION update_weekly_plans_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_weekly_plans_updated_at
  BEFORE UPDATE ON weekly_plans
  FOR EACH ROW
  EXECUTE FUNCTION update_weekly_plans_updated_at();