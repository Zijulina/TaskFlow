/*
  # Adicionar funcionalidades avançadas ao gestor de tarefas

  1. Novas Tabelas
    - `quick_notes` - Anotações rápidas (diferencial exclusivo)
    - `subtasks` - Subtarefas para organização detalhada
    - `task_templates` - Templates de tarefas (Pro exclusivo)
    - `pomodoro_sessions` - Sessões de foco/pomodoro
    - `productivity_insights` - Insights de produtividade (Pro exclusivo)

  2. Funcionalidades por Plano
    - Free: Anotações rápidas básicas (até 10)
    - Essencial: Subtarefas, Pomodoro, anotações ilimitadas
    - Pro: Templates, insights avançados, análise de produtividade

  3. Segurança
    - RLS habilitado em todas as tabelas
    - Políticas específicas para cada tipo de usuário
*/

-- Tabela de anotações rápidas (diferencial exclusivo)
CREATE TABLE IF NOT EXISTS quick_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content text NOT NULL,
  color text DEFAULT '#fbbf24',
  position_x integer DEFAULT 0,
  position_y integer DEFAULT 0,
  is_pinned boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela de subtarefas
CREATE TABLE IF NOT EXISTS subtasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
  title text NOT NULL,
  is_done boolean DEFAULT false,
  position integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  completed_at timestamptz DEFAULT NULL
);

-- Tabela de templates de tarefas (Pro exclusivo)
CREATE TABLE IF NOT EXISTS task_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  description text DEFAULT '',
  template_data jsonb NOT NULL, -- Estrutura da tarefa e subtarefas
  category text DEFAULT 'geral',
  is_public boolean DEFAULT false,
  usage_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela de sessões Pomodoro
CREATE TABLE IF NOT EXISTS pomodoro_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  task_id uuid REFERENCES tasks(id) ON DELETE SET NULL,
  duration_minutes integer NOT NULL DEFAULT 25,
  completed boolean DEFAULT false,
  started_at timestamptz DEFAULT now(),
  completed_at timestamptz DEFAULT NULL,
  session_type text DEFAULT 'work' CHECK (session_type IN ('work', 'short_break', 'long_break'))
);

-- Tabela de insights de produtividade (Pro exclusivo)
CREATE TABLE IF NOT EXISTS productivity_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  insight_type text NOT NULL,
  insight_data jsonb NOT NULL,
  period_start date NOT NULL,
  period_end date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_quick_notes_user_id ON quick_notes(user_id);
CREATE INDEX IF NOT EXISTS idx_quick_notes_created_at ON quick_notes(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_subtasks_task_id ON subtasks(task_id);
CREATE INDEX IF NOT EXISTS idx_subtasks_position ON subtasks(task_id, position);
CREATE INDEX IF NOT EXISTS idx_task_templates_user_id ON task_templates(user_id);
CREATE INDEX IF NOT EXISTS idx_task_templates_category ON task_templates(category);
CREATE INDEX IF NOT EXISTS idx_pomodoro_sessions_user_id ON pomodoro_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_pomodoro_sessions_task_id ON pomodoro_sessions(task_id);
CREATE INDEX IF NOT EXISTS idx_productivity_insights_user_id ON productivity_insights(user_id);
CREATE INDEX IF NOT EXISTS idx_productivity_insights_period ON productivity_insights(period_start, period_end);

-- Habilitar RLS
ALTER TABLE quick_notes ENABLE ROW LEVEL SECURITY;
ALTER TABLE subtasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE task_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE pomodoro_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE productivity_insights ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para quick_notes
CREATE POLICY "Users can manage own quick notes"
  ON quick_notes
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Políticas RLS para subtasks
CREATE POLICY "Users can manage subtasks of own tasks"
  ON subtasks
  FOR ALL
  TO authenticated
  USING (
    task_id IN (
      SELECT id FROM tasks WHERE user_id = auth.uid()
    )
  )
  WITH CHECK (
    task_id IN (
      SELECT id FROM tasks WHERE user_id = auth.uid()
    )
  );

-- Políticas RLS para task_templates
CREATE POLICY "Users can manage own templates"
  ON task_templates
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view public templates"
  ON task_templates
  FOR SELECT
  TO authenticated
  USING (is_public = true);

-- Políticas RLS para pomodoro_sessions
CREATE POLICY "Users can manage own pomodoro sessions"
  ON pomodoro_sessions
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Políticas RLS para productivity_insights
CREATE POLICY "Users can manage own productivity insights"
  ON productivity_insights
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Função para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers para updated_at
CREATE TRIGGER update_quick_notes_updated_at
  BEFORE UPDATE ON quick_notes
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_task_templates_updated_at
  BEFORE UPDATE ON task_templates
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Função para gerar insights de produtividade automaticamente
CREATE OR REPLACE FUNCTION generate_productivity_insights()
RETURNS void AS $$
DECLARE
  user_record RECORD;
  week_start date;
  week_end date;
  insight_data jsonb;
BEGIN
  -- Para cada usuário ativo
  FOR user_record IN 
    SELECT DISTINCT user_id FROM tasks 
    WHERE created_at >= CURRENT_DATE - INTERVAL '7 days'
  LOOP
    week_start := CURRENT_DATE - INTERVAL '6 days';
    week_end := CURRENT_DATE;
    
    -- Gerar insights de produtividade
    SELECT jsonb_build_object(
      'tasks_completed', COUNT(*) FILTER (WHERE is_done = true),
      'tasks_created', COUNT(*),
      'completion_rate', ROUND(
        (COUNT(*) FILTER (WHERE is_done = true)::numeric / NULLIF(COUNT(*), 0)) * 100, 2
      ),
      'most_productive_day', (
        SELECT EXTRACT(DOW FROM created_at)::text
        FROM tasks 
        WHERE user_id = user_record.user_id 
          AND created_at >= week_start 
          AND created_at <= week_end + INTERVAL '1 day'
          AND is_done = true
        GROUP BY EXTRACT(DOW FROM created_at)
        ORDER BY COUNT(*) DESC
        LIMIT 1
      ),
      'average_tasks_per_day', ROUND(
        COUNT(*)::numeric / 7, 2
      ),
      'priority_distribution', jsonb_build_object(
        'urgent', COUNT(*) FILTER (WHERE priority = 'urgent'),
        'high', COUNT(*) FILTER (WHERE priority = 'high'),
        'medium', COUNT(*) FILTER (WHERE priority = 'medium'),
        'low', COUNT(*) FILTER (WHERE priority = 'low')
      )
    ) INTO insight_data
    FROM tasks 
    WHERE user_id = user_record.user_id 
      AND created_at >= week_start 
      AND created_at <= week_end + INTERVAL '1 day';
    
    -- Inserir insight se houver dados
    IF insight_data->>'tasks_created' != '0' THEN
      INSERT INTO productivity_insights (
        user_id, 
        insight_type, 
        insight_data, 
        period_start, 
        period_end
      ) VALUES (
        user_record.user_id,
        'weekly_summary',
        insight_data,
        week_start,
        week_end
      )
      ON CONFLICT DO NOTHING;
    END IF;
  END LOOP;
END;
$$ LANGUAGE plpgsql;