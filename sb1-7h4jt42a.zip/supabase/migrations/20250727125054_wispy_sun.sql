/*
  # Criar tabela para rastreamento de emails

  1. Nova Tabela
    - `email_tracking`
      - `id` (uuid, primary key)
      - `email` (text, unique)
      - `status` (text) - 'registered', 'pending', 'failed'
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Segurança
    - Enable RLS na tabela `email_tracking`
    - Adicionar políticas para operações CRUD

  3. Função
    - Função para verificar se email já existe
    - Trigger para atualizar automaticamente
*/

-- Criar tabela de rastreamento de emails
CREATE TABLE IF NOT EXISTS email_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Adicionar constraint para status válidos
ALTER TABLE email_tracking 
ADD CONSTRAINT email_tracking_status_check 
CHECK (status IN ('registered', 'pending', 'failed'));

-- Habilitar RLS
ALTER TABLE email_tracking ENABLE ROW LEVEL SECURITY;

-- Políticas RLS
CREATE POLICY "Anyone can read email tracking"
  ON email_tracking
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can insert email tracking"
  ON email_tracking
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can update email tracking"
  ON email_tracking
  FOR UPDATE
  TO public
  USING (true);

-- Função para atualizar timestamp
CREATE OR REPLACE FUNCTION update_email_tracking_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar timestamp automaticamente
CREATE TRIGGER update_email_tracking_updated_at
  BEFORE UPDATE ON email_tracking
  FOR EACH ROW
  EXECUTE FUNCTION update_email_tracking_updated_at();

-- Função para verificar se email existe
CREATE OR REPLACE FUNCTION check_email_exists(email_to_check text)
RETURNS boolean AS $$
BEGIN
  -- Verifica na tabela users
  IF EXISTS (SELECT 1 FROM users WHERE email = email_to_check) THEN
    RETURN true;
  END IF;
  
  -- Verifica na tabela email_tracking com status registered
  IF EXISTS (SELECT 1 FROM email_tracking WHERE email = email_to_check AND status = 'registered') THEN
    RETURN true;
  END IF;
  
  RETURN false;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;