/*
  # Add name field to users table

  1. Changes
    - Add `name` column to `users` table
    - Update existing users to have null name initially
    - Add expenses table for tracking user expenses
    - Update tasks table to use cost_value instead of value_associated

  2. New Tables
    - `expenses` table for tracking user spending

  3. Security
    - Maintain existing RLS policies
    - Add RLS for expenses table
*/

-- Add name column to users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'name'
  ) THEN
    ALTER TABLE users ADD COLUMN name text;
  END IF;
END $$;

-- Update tasks table to use cost_value instead of value_associated
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'tasks' AND column_name = 'value_associated'
  ) THEN
    ALTER TABLE tasks RENAME COLUMN value_associated TO cost_value;
  END IF;
END $$;

-- Create expenses table
CREATE TABLE IF NOT EXISTS expenses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  amount numeric(10,2) NOT NULL DEFAULT 0,
  category text NOT NULL DEFAULT 'outros',
  expense_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS on expenses table
ALTER TABLE expenses ENABLE ROW LEVEL SECURITY;

-- Create policies for expenses
CREATE POLICY "Users can manage own expenses"
  ON expenses
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create indexes for expenses
CREATE INDEX IF NOT EXISTS idx_expenses_user_id ON expenses(user_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(expense_date DESC);
CREATE INDEX IF NOT EXISTS idx_expenses_category ON expenses(category);

-- Add constraint for expense categories
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_name = 'expenses' AND constraint_name = 'expenses_category_check'
  ) THEN
    ALTER TABLE expenses ADD CONSTRAINT expenses_category_check 
    CHECK (category IN ('casa', 'alimentacao', 'transporte', 'saude', 'educacao', 'lazer', 'outros'));
  END IF;
END $$;

-- Create trigger for updating updated_at
CREATE OR REPLACE FUNCTION update_expenses_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.triggers
    WHERE trigger_name = 'update_expenses_updated_at'
  ) THEN
    CREATE TRIGGER update_expenses_updated_at
      BEFORE UPDATE ON expenses
      FOR EACH ROW
      EXECUTE FUNCTION update_expenses_updated_at();
  END IF;
END $$;