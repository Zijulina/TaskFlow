import 'jsr:@supabase/functions-js/edge-runtime.d.ts';
import { createClient } from 'npm:@supabase/supabase-js@2.49.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Validar variáveis de ambiente obrigatórias
const supabaseUrl = Deno.env.get('SUPABASE_URL');
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Variáveis de ambiente obrigatórias não encontradas:', {
    SUPABASE_URL: !!supabaseUrl,
    SUPABASE_SERVICE_ROLE_KEY: !!supabaseServiceKey
  });
  throw new Error('Configuração do servidor incompleta');
}

// Cliente Supabase com privilégios administrativos
const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey);

Deno.serve(async (req) => {
  try {
    // Tratar requisições OPTIONS para CORS
    if (req.method === 'OPTIONS') {
      return new Response(null, { 
        status: 204, 
        headers: corsHeaders 
      });
    }

    if (req.method !== 'POST') {
      return new Response(
        JSON.stringify({ error: 'Método não permitido' }),
        { 
          status: 405, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Obter dados da requisição
    const { email, password, confirmationText } = await req.json();

    // Validações básicas
    if (!email || !password || !confirmationText) {
      return new Response(
        JSON.stringify({ 
          error: 'Dados obrigatórios não fornecidos',
          details: 'Email, senha e confirmação são obrigatórios'
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Verificar confirmação de texto
    if (confirmationText !== 'EXCLUIR PERMANENTEMENTE') {
      return new Response(
        JSON.stringify({ 
          error: 'Confirmação inválida',
          details: 'Digite exatamente "EXCLUIR PERMANENTEMENTE" para confirmar'
        }),
        { 
          status: 400, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Obter token de autenticação
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      return new Response(
        JSON.stringify({ error: 'Token de autenticação não fornecido' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    const token = authHeader.replace('Bearer ', '');
    
    // Validar usuário autenticado
    const { data: { user }, error: userError } = await supabaseAdmin.auth.getUser(token);

    if (userError || !user) {
      console.error('Erro de autenticação:', userError);
      return new Response(
        JSON.stringify({ error: 'Usuário não autenticado' }),
        { 
          status: 401, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Verificar se o email fornecido corresponde ao usuário autenticado
    if (user.email !== email.toLowerCase().trim()) {
      return new Response(
        JSON.stringify({ 
          error: 'Email não corresponde ao usuário autenticado',
          details: 'O email fornecido deve ser o mesmo da conta logada'
        }),
        { 
          status: 403, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Verificar senha atual fazendo login
    const { error: passwordError } = await supabaseAdmin.auth.signInWithPassword({
      email: email.toLowerCase().trim(),
      password: password
    });

    if (passwordError) {
      return new Response(
        JSON.stringify({ 
          error: 'Senha incorreta',
          details: 'A senha fornecida não está correta'
        }),
        { 
          status: 403, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Registrar log de auditoria (sem dados pessoais)
    const auditLog = {
      action: 'account_deletion_initiated',
      user_id: user.id,
      timestamp: new Date().toISOString(),
      ip_address: req.headers.get('x-forwarded-for') || 'unknown',
      user_agent: req.headers.get('user-agent') || 'unknown'
    };

    console.info('Iniciando exclusão de conta:', auditLog);

    // Executar exclusão em transação atômica
    const deletionResult = await executeAccountDeletion(user.id);

    if (!deletionResult.success) {
      console.error('Erro na exclusão:', deletionResult.error);
      return new Response(
        JSON.stringify({ 
          error: 'Erro interno durante exclusão',
          details: 'Tente novamente em alguns minutos'
        }),
        { 
          status: 500, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    // Log de auditoria final
    console.info('Exclusão de conta concluída com sucesso:', {
      action: 'account_deletion_completed',
      user_id: user.id,
      timestamp: new Date().toISOString(),
      deleted_records: deletionResult.deletedRecords
    });

    return new Response(
      JSON.stringify({ 
        success: true,
        message: 'Conta excluída com sucesso',
        timestamp: new Date().toISOString()
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Erro inesperado na exclusão de conta:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Erro interno do servidor',
        details: 'Tente novamente mais tarde'
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});

/**
 * Executa a exclusão completa da conta do usuário
 * Remove todos os dados relacionados de forma atômica
 */
async function executeAccountDeletion(userId: string): Promise<{
  success: boolean;
  error?: string;
  deletedRecords?: Record<string, number>;
}> {
  try {
    const deletedRecords: Record<string, number> = {};

    // 1. Excluir anotações rápidas
    const { count: quickNotesCount, error: quickNotesError } = await supabaseAdmin
      .from('quick_notes')
      .delete()
      .eq('user_id', userId);

    if (quickNotesError) throw new Error(`Erro ao excluir anotações: ${quickNotesError.message}`);
    deletedRecords.quick_notes = quickNotesCount || 0;

    // 2. Excluir sessões Pomodoro
    const { count: pomodoroCount, error: pomodoroError } = await supabaseAdmin
      .from('pomodoro_sessions')
      .delete()
      .eq('user_id', userId);

    if (pomodoroError) throw new Error(`Erro ao excluir sessões Pomodoro: ${pomodoroError.message}`);
    deletedRecords.pomodoro_sessions = pomodoroCount || 0;

    // 3. Excluir insights de produtividade
    const { count: insightsCount, error: insightsError } = await supabaseAdmin
      .from('productivity_insights')
      .delete()
      .eq('user_id', userId);

    if (insightsError) throw new Error(`Erro ao excluir insights: ${insightsError.message}`);
    deletedRecords.productivity_insights = insightsCount || 0;

    // 4. Excluir templates de tarefas
    const { count: templatesCount, error: templatesError } = await supabaseAdmin
      .from('task_templates')
      .delete()
      .eq('user_id', userId);

    if (templatesError) throw new Error(`Erro ao excluir templates: ${templatesError.message}`);
    deletedRecords.task_templates = templatesCount || 0;

    // 5. Excluir histórico de tarefas
    const { count: historyCount, error: historyError } = await supabaseAdmin
      .from('task_history')
      .delete()
      .eq('user_id', userId);

    if (historyError) throw new Error(`Erro ao excluir histórico: ${historyError.message}`);
    deletedRecords.task_history = historyCount || 0;

    // 6. Excluir estatísticas de produtividade
    const { count: statsCount, error: statsError } = await supabaseAdmin
      .from('productivity_stats')
      .delete()
      .eq('user_id', userId);

    if (statsError) throw new Error(`Erro ao excluir estatísticas: ${statsError.message}`);
    deletedRecords.productivity_stats = statsCount || 0;

    // 7. Excluir despesas
    const { count: expensesCount, error: expensesError } = await supabaseAdmin
      .from('expenses')
      .delete()
      .eq('user_id', userId);

    if (expensesError) throw new Error(`Erro ao excluir despesas: ${expensesError.message}`);
    deletedRecords.expenses = expensesCount || 0;

    // 8. Excluir metas financeiras
    const { count: goalsCount, error: goalsError } = await supabaseAdmin
      .from('financial_goals')
      .delete()
      .eq('user_id', userId);

    if (goalsError) throw new Error(`Erro ao excluir metas: ${goalsError.message}`);
    deletedRecords.financial_goals = goalsCount || 0;

    // 9. Excluir investimentos
    const { count: investmentsCount, error: investmentsError } = await supabaseAdmin
      .from('investments')
      .delete()
      .eq('user_id', userId);

    if (investmentsError) throw new Error(`Erro ao excluir investimentos: ${investmentsError.message}`);
    deletedRecords.investments = investmentsCount || 0;

    // 10. Excluir feedback
    const { count: feedbackCount, error: feedbackError } = await supabaseAdmin
      .from('feedback')
      .delete()
      .eq('user_id', userId);

    if (feedbackError) throw new Error(`Erro ao excluir feedback: ${feedbackError.message}`);
    deletedRecords.feedback = feedbackCount || 0;

    // 11. Excluir preferências do usuário
    const { count: preferencesCount, error: preferencesError } = await supabaseAdmin
      .from('user_preferences')
      .delete()
      .eq('user_id', userId);

    if (preferencesError) throw new Error(`Erro ao excluir preferências: ${preferencesError.message}`);
    deletedRecords.user_preferences = preferencesCount || 0;

    // 12. Excluir tags do usuário
    const { count: tagsCount, error: tagsError } = await supabaseAdmin
      .from('tags')
      .delete()
      .eq('user_id', userId);

    if (tagsError) throw new Error(`Erro ao excluir tags: ${tagsError.message}`);
    deletedRecords.tags = tagsCount || 0;

    // 13. Excluir projetos do usuário
    const { count: projectsCount, error: projectsError } = await supabaseAdmin
      .from('projects')
      .delete()
      .eq('user_id', userId);

    if (projectsError) throw new Error(`Erro ao excluir projetos: ${projectsError.message}`);
    deletedRecords.projects = projectsCount || 0;

    // 14. Excluir tarefas do usuário (CASCADE irá excluir subtarefas automaticamente)
    const { count: tasksCount, error: tasksError } = await supabaseAdmin
      .from('tasks')
      .delete()
      .eq('user_id', userId);

    if (tasksError) throw new Error(`Erro ao excluir tarefas: ${tasksError.message}`);
    deletedRecords.tasks = tasksCount || 0;

    // 15. Excluir dados de assinatura Stripe
    const { count: stripeCustomersCount, error: stripeCustomersError } = await supabaseAdmin
      .from('stripe_customers')
      .delete()
      .eq('user_id', userId);

    if (stripeCustomersError) throw new Error(`Erro ao excluir dados Stripe: ${stripeCustomersError.message}`);
    deletedRecords.stripe_customers = stripeCustomersCount || 0;

    // 16. Excluir perfil do usuário
    const { count: usersCount, error: usersError } = await supabaseAdmin
      .from('users')
      .delete()
      .eq('id', userId);

    if (usersError) throw new Error(`Erro ao excluir perfil: ${usersError.message}`);
    deletedRecords.users = usersCount || 0;

    // 17. Finalmente, excluir conta do Supabase Auth
    const { error: authError } = await supabaseAdmin.auth.admin.deleteUser(userId);

    if (authError) throw new Error(`Erro ao excluir conta de autenticação: ${authError.message}`);
    deletedRecords.auth_user = 1;

    return {
      success: true,
      deletedRecords
    };

  } catch (error) {
    console.error('Erro durante exclusão de dados:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Erro desconhecido'
    };
  }
}