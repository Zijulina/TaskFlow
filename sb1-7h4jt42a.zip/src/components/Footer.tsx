import React from 'react'
import { CheckSquare } from 'lucide-react'

export function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <CheckSquare className="w-8 h-8 text-blue-600" />
              <span className="text-xl font-bold text-gray-900">TaskFlow</span>
            </div>
            <p className="text-gray-600 mb-4">
              A solução completa para gerenciar suas tarefas de forma eficiente e organizada.
            </p>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wider mb-4">
              Produto
            </h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-gray-900">Recursos</a></li>
              <li><a href="#" className="text-gray-600 hover:text-gray-900">Preços</a></li>
              <li><a href="#" className="text-gray-600 hover:text-gray-900">FAQ</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-sm font-semibold text-gray-900 uppercase tracking-wider mb-4">
              Legal
            </h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-gray-600 hover:text-gray-900">Termos de Uso</a></li>
              <li><a href="#" className="text-gray-600 hover:text-gray-900">Privacidade</a></li>
              <li><a href="#" className="text-gray-600 hover:text-gray-900">Suporte</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-200 pt-8 mt-8">
          <p className="text-center text-gray-600">
            © 2025 TaskFlow. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}