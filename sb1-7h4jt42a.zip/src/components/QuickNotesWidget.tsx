import React, { useState } from 'react'
import { Plus, X, Pin, PinOff, Palette, StickyNote } from 'lucide-react'
import { Button } from './ui/Button'
import { Card } from './ui/Card'
import { Modal } from './ui/Modal'
import { useQuickNotes } from '../hooks/useQuickNotes'
import { useSubscription } from '../hooks/useSubscription'
import { cn } from '../lib/utils'

const noteColors = [
  { name: 'Amarelo', value: '#fbbf24' },
  { name: 'Rosa', value: '#f472b6' },
  { name: 'Azul', value: '#60a5fa' },
  { name: 'Verde', value: '#34d399' },
  { name: 'Roxo', value: '#a78bfa' },
  { name: 'Laranja', value: '#fb923c' },
]

export function QuickNotesWidget() {
  const { notes, createNote, updateNote, deleteNote } = useQuickNotes()
  const { hasPremiumFeatures } = useSubscription()
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [newNoteContent, setNewNoteContent] = useState('')
  const [selectedColor, setSelectedColor] = useState('#fbbf24')
  const [editingNote, setEditingNote] = useState<string | null>(null)
  const [editContent, setEditContent] = useState('')

  const canCreateMore = hasPremiumFeatures || notes.length < 10

  const handleCreateNote = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newNoteContent.trim()) return

    await createNote(newNoteContent.trim(), selectedColor)
    setNewNoteContent('')
    setSelectedColor('#fbbf24')
    setShowCreateModal(false)
  }

  const handleEditNote = (noteId: string, content: string) => {
    setEditingNote(noteId)
    setEditContent(content)
  }

  const handleSaveEdit = async (noteId: string) => {
    if (!editContent.trim()) return

    await updateNote(noteId, { content: editContent.trim() })
    setEditingNote(null)
    setEditContent('')
  }

  const handleTogglePin = async (noteId: string, isPinned: boolean) => {
    await updateNote(noteId, { is_pinned: !isPinned })
  }

  const pinnedNotes = notes.filter(note => note.is_pinned)
  const unpinnedNotes = notes.filter(note => !note.is_pinned)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <StickyNote className="w-5 h-5 text-yellow-600 mr-2" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Anotações Rápidas
          </h3>
        </div>
        <Button
          onClick={() => setShowCreateModal(true)}
          size="sm"
          disabled={!canCreateMore}
          title={!canCreateMore ? 'Limite de 10 anotações no plano gratuito' : ''}
        >
          <Plus className="w-4 h-4 mr-1" />
          Nova
        </Button>
      </div>

      {!hasPremiumFeatures && (
        <div className="text-sm text-gray-600 dark:text-gray-400">
          {notes.length}/10 anotações no plano gratuito
        </div>
      )}

      {notes.length === 0 ? (
        <Card className="text-center py-8">
          <StickyNote className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-2" />
          <p className="text-gray-600 dark:text-gray-400">
            Nenhuma anotação ainda. Crie sua primeira!
          </p>
        </Card>
      ) : (
        <div className="space-y-4">
          {/* Pinned Notes */}
          {pinnedNotes.length > 0 && (
            <div>
              <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 flex items-center">
                <Pin className="w-4 h-4 mr-1" />
                Fixadas
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {pinnedNotes.map(note => (
                  <NoteCard
                    key={note.id}
                    note={note}
                    isEditing={editingNote === note.id}
                    editContent={editContent}
                    onEdit={handleEditNote}
                    onSave={handleSaveEdit}
                    onCancel={() => setEditingNote(null)}
                    onDelete={deleteNote}
                    onTogglePin={handleTogglePin}
                    onEditContentChange={setEditContent}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Regular Notes */}
          {unpinnedNotes.length > 0 && (
            <div>
              {pinnedNotes.length > 0 && (
                <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Outras
                </h4>
              )}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {unpinnedNotes.map(note => (
                  <NoteCard
                    key={note.id}
                    note={note}
                    isEditing={editingNote === note.id}
                    editContent={editContent}
                    onEdit={handleEditNote}
                    onSave={handleSaveEdit}
                    onCancel={() => setEditingNote(null)}
                    onDelete={deleteNote}
                    onTogglePin={handleTogglePin}
                    onEditContentChange={setEditContent}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Create Note Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => {
          setShowCreateModal(false)
          setNewNoteContent('')
          setSelectedColor('#fbbf24')
        }}
        title="Nova Anotação Rápida"
      >
        <form onSubmit={handleCreateNote} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Conteúdo
            </label>
            <textarea
              value={newNoteContent}
              onChange={(e) => setNewNoteContent(e.target.value)}
              placeholder="Digite sua anotação..."
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
              rows={4}
              maxLength={500}
              required
            />
            <div className="text-xs text-gray-500 mt-1">
              {newNoteContent.length}/500 caracteres
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Cor
            </label>
            <div className="flex space-x-2">
              {noteColors.map(color => (
                <button
                  key={color.value}
                  type="button"
                  onClick={() => setSelectedColor(color.value)}
                  className={cn(
                    'w-8 h-8 rounded-full border-2 transition-all',
                    selectedColor === color.value
                      ? 'border-gray-900 dark:border-white scale-110'
                      : 'border-gray-300 dark:border-gray-600 hover:scale-105'
                  )}
                  style={{ backgroundColor: color.value }}
                  title={color.name}
                />
              ))}
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setShowCreateModal(false)
                setNewNoteContent('')
                setSelectedColor('#fbbf24')
              }}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button type="submit" className="flex-1">
              Criar Anotação
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}

interface NoteCardProps {
  note: any
  isEditing: boolean
  editContent: string
  onEdit: (id: string, content: string) => void
  onSave: (id: string) => void
  onCancel: () => void
  onDelete: (id: string) => void
  onTogglePin: (id: string, isPinned: boolean) => void
  onEditContentChange: (content: string) => void
}

function NoteCard({
  note,
  isEditing,
  editContent,
  onEdit,
  onSave,
  onCancel,
  onDelete,
  onTogglePin,
  onEditContentChange
}: NoteCardProps) {
  return (
    <div
      className="p-3 rounded-lg border-l-4 shadow-sm hover:shadow-md transition-shadow relative group"
      style={{ 
        borderLeftColor: note.color,
        backgroundColor: `${note.color}15`
      }}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center space-x-1">
          {note.is_pinned && (
            <Pin className="w-3 h-3 text-gray-600 dark:text-gray-400" />
          )}
        </div>
        <div className="flex items-center space-x-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onTogglePin(note.id, note.is_pinned)}
            className="p-1"
            title={note.is_pinned ? 'Desfixar' : 'Fixar'}
          >
            {note.is_pinned ? (
              <PinOff className="w-3 h-3" />
            ) : (
              <Pin className="w-3 h-3" />
            )}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onDelete(note.id)}
            className="p-1 text-red-500 hover:text-red-700"
            title="Excluir"
          >
            <X className="w-3 h-3" />
          </Button>
        </div>
      </div>

      {isEditing ? (
        <div className="space-y-2">
          <textarea
            value={editContent}
            onChange={(e) => onEditContentChange(e.target.value)}
            className="w-full px-2 py-1 text-sm border border-gray-300 dark:border-gray-600 rounded focus:ring-1 focus:ring-blue-500 focus:border-transparent resize-none bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
            rows={3}
            maxLength={500}
          />
          <div className="flex space-x-2">
            <Button size="sm" onClick={() => onSave(note.id)}>
              Salvar
            </Button>
            <Button variant="outline" size="sm" onClick={onCancel}>
              Cancelar
            </Button>
          </div>
        </div>
      ) : (
        <div
          className="text-sm text-gray-900 dark:text-white cursor-pointer"
          onClick={() => onEdit(note.id, note.content)}
        >
          {note.content}
        </div>
      )}

      <div className="text-xs text-gray-500 dark:text-gray-400 mt-2">
        {new Date(note.created_at).toLocaleDateString('pt-BR')}
      </div>
    </div>
  )
}