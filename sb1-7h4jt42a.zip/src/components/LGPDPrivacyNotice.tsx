import React from 'react'
import { Shield, FileText, Trash2, Eye, Download, Edit } from 'lucide-react'
import { Card } from './ui/Card'

interface LGPDPrivacyNoticeProps {
  className?: string
}

export function LGPDPrivacyNotice({ className }: LGPDPrivacyNoticeProps) {
  return (
    <Card className={className}>
      <div className="flex items-center mb-4">
        <Shield className="w-5 h-5 text-blue-600 mr-2" />
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Seus Direitos - LGPD
        </h3>
      </div>
      
      <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
        Conforme a Lei Geral de Proteção de Dados (LGPD), você tem os seguintes direitos 
        sobre seus dados pessoais:
      </p>
      
      <div className="space-y-3">
        <div className="flex items-start space-x-3">
          <Eye className="w-4 h-4 text-blue-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900 dark:text-white">
              Acesso aos dados
            </h4>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              Visualizar quais dados pessoais temos sobre você
            </p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <Edit className="w-4 h-4 text-green-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900 dark:text-white">
              Correção de dados
            </h4>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              Atualizar informações incorretas ou incompletas
            </p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <Download className="w-4 h-4 text-purple-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900 dark:text-white">
              Portabilidade
            </h4>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              Exportar seus dados em formato estruturado
            </p>
          </div>
        </div>
        
        <div className="flex items-start space-x-3">
          <Trash2 className="w-4 h-4 text-red-600 mt-0.5" />
          <div>
            <h4 className="text-sm font-medium text-gray-900 dark:text-white">
              Exclusão de dados
            </h4>
            <p className="text-xs text-gray-600 dark:text-gray-400">
              Solicitar a remoção permanente de seus dados pessoais
            </p>
          </div>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
        <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
          <FileText className="w-3 h-3 mr-1" />
          <span>
            Para exercer seus direitos, acesse as configurações da conta ou entre em contato conosco.
          </span>
        </div>
      </div>
    </Card>
  )
}