import React, { useState } from 'react'
import { Check, Trash2, DollarSign, Edit3, Save, X, AlertTriangle, ArrowUp, Minus, ArrowDown, ChevronDown, ChevronRight } from 'lucide-react'
import { Button } from './ui/Button'
import { Card } from './ui/Card'
import { Input } from './ui/Input'
import { SubtasksManager } from './SubtasksManager'
import { Task, Project } from '../hooks/useTasks'
import { useSubscription } from '../hooks/useSubscription'
import { cn } from '../lib/utils'

interface TaskCardProps {
  task: Task
  projects: Project[]
  onToggle: (id: string, isDone: boolean) => void
  onDelete: (id: string) => void
  onUpdateCost: (id: string, cost: number, currency: string) => void
  canDelete: boolean
}

export function TaskCard({ task, projects, onToggle, onDelete, onUpdateCost, canDelete }: TaskCardProps) {
  const [isEditingCost, setIsEditingCost] = useState(false)
  const [costInput, setCostInput] = useState(task.value_associated?.toString() || '')
  const [currencyInput, setCurrencyInput] = useState(task.currency || 'BRL')
  const [showSubtasks, setShowSubtasks] = useState(false)
  const { hasPremiumFeatures } = useSubscription()
  
  const project = projects.find(p => p.id === task.project_id)
  
  const formatCurrency = (value: number, currency: string) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: currency
    }).format(value)
  }

  const getPriorityIcon = (priority: string | null) => {
    switch (priority) {
      case 'urgent':
        return <AlertTriangle className="w-3 h-3" />
      case 'high':
        return <ArrowUp className="w-3 h-3" />
      case 'medium':
        return <Minus className="w-3 h-3" />
      case 'low':
        return <ArrowDown className="w-3 h-3" />
      case null:
        return <Minus className="w-3 h-3 text-gray-400" />
      default:
        return <Minus className="w-3 h-3" />
    }
  }

  const getPriorityLabel = (priority: string | null) => {
    switch (priority) {
      case 'urgent':
        return 'Urgente'
      case 'high':
        return 'Alta'
      case 'medium':
        return 'Média'
      case 'low':
        return 'Baixa'
      case null:
        return 'Sem prioridade'
      default:
        return 'Média'
    }
  }

  const handleSaveCost = () => {
    const cost = parseFloat(costInput)
    if (!isNaN(cost) && cost >= 0) {
      onUpdateCost(task.id, cost, currencyInput)
    }
    setIsEditingCost(false)
  }

  const handleCancelEdit = () => {
    setIsEditingCost(false)
    setCostInput(task.value_associated?.toString() || '')
    setCurrencyInput(task.currency || 'BRL')
  }

  return (
    <Card className="hover:shadow-md transition-shadow duration-200 card-themed">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-3 flex-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onToggle(task.id, !task.is_done)}
            className={cn(
              'p-1 rounded-full transition-all duration-200',
              task.is_done 
                ? 'bg-green-100 text-green-600 hover:bg-green-200' 
                : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
            )}
          >
            <Check className="w-4 h-4" />
          </Button>
          
          <span className={cn(
            'flex-1 transition-all duration-200',
            task.is_done && 'line-through text-gray-500'
          )}>
            {task.title}
          </span>
          
          {/* Priority Badge - only show if task has priority */}
          {task.priority && (
            <span className={cn(
              'inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border',
              `priority-${task.priority}`
            )}>
              {getPriorityIcon(task.priority)}
              <span className="ml-1">{getPriorityLabel(task.priority)}</span>
            </span>
          )}
          
          {/* Cost Badge */}
          {task.value_associated && task.value_associated > 0 && (
            <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-300">
              <DollarSign className="w-3 h-3 mr-1" />
              {formatCurrency(task.value_associated, task.currency || 'BRL')}
            </span>
          )}
        </div>
        
        <div className="flex items-center space-x-1">
          {/* Edit Cost Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setIsEditingCost(true)}
            className="p-1 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
            title="Editar custo da tarefa"
          >
            <DollarSign className="w-4 h-4" />
          </Button>

          {canDelete && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onDelete(task.id)}
              className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>
      
      {/* Cost Edit Form */}
      {isEditingCost && (
        <div className="mt-4 p-3 bg-gray-50 rounded-lg border">
          <div className="flex items-center space-x-2 mb-3">
            <DollarSign className="w-4 h-4 text-red-600" />
            <span className="text-sm font-medium text-gray-900 dark:text-white">Custo da Tarefa</span>
          </div>
          <div className="flex items-center space-x-2">
            <select
              value={currencyInput}
              onChange={(e) => setCurrencyInput(e.target.value)}
              className="px-2 py-1 border border-gray-300 dark:border-gray-600 rounded text-sm bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
            >
              <option value="BRL">R$</option>
              <option value="USD">$</option>
              <option value="EUR">€</option>
            </select>
            <Input
              type="number"
              value={costInput}
              onChange={(e) => setCostInput(e.target.value)}
              placeholder="0.00"
              className="flex-1"
              min="0"
              step="0.01"
            />
            <Button size="sm" onClick={handleSaveCost}>
              <Save className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={handleCancelEdit}>
              <X className="w-4 h-4" />
            </Button>
          </div>
          <div className="text-xs text-gray-500 mt-2">
            Quanto você precisa gastar para completar esta tarefa
          </div>
        </div>
      )}
      
      {/* Subtasks Manager - Only for premium users */}
      {hasPremiumFeatures && (
        <SubtasksManager
          taskId={task.id}
          isExpanded={showSubtasks}
          onToggleExpanded={() => setShowSubtasks(!showSubtasks)}
        />
      )}
      
      <div className="mt-3 flex items-center justify-between text-xs text-gray-500">
        <div className="flex items-center space-x-4">
          <span>{new Date(task.created_at).toLocaleDateString('pt-BR')}</span>
          
          {/* Project */}
          {project && (
            <div className="flex items-center">
              <div 
                className="w-2 h-2 rounded-full mr-1" 
                style={{ backgroundColor: project.color }}
              />
              <span>{project.name}</span>
            </div>
          )}
        </div>
      </div>
    </Card>
  )
}