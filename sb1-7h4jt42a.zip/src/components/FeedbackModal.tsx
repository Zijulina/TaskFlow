import React, { useState } from 'react'
import { Star, MessageSquare, Send } from 'lucide-react'
import { Button } from './ui/Button'
import { Modal } from './ui/Modal'
import { useFeedback } from '../hooks/useFeedback'
import { cn } from '../lib/utils'

interface FeedbackModalProps {
  isOpen: boolean
  onClose: () => void
  onSuccess: () => void
}

export function FeedbackModal({ isOpen, onClose, onSuccess }: FeedbackModalProps) {
  const [rating, setRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const [message, setMessage] = useState('')
  const { submitFeedback, loading, error } = useFeedback()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (rating === 0) {
      return
    }

    if (!message.trim()) {
      return
    }

    const { error } = await submitFeedback(message, rating)
    
    if (!error) {
      onSuccess()
      onClose()
      // Reset form
      setRating(0)
      setHoveredRating(0)
      setMessage('')
    }
  }

  const handleClose = () => {
    onClose()
    // Reset form when closing
    setRating(0)
    setHoveredRating(0)
    setMessage('')
  }

  return (
    <Modal isOpen={isOpen} onClose={handleClose} title="Enviar Feedback">
      <form onSubmit={handleSubmit} className="space-y-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
            {error}
          </div>
        )}

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-3">
            Como você avalia sua experiência?
          </label>
          <div className="flex items-center space-x-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <button
                key={star}
                type="button"
                onClick={() => setRating(star)}
                onMouseEnter={() => setHoveredRating(star)}
                onMouseLeave={() => setHoveredRating(0)}
                className="p-1 transition-colors"
              >
                <Star
                  className={cn(
                    'w-8 h-8 transition-colors',
                    (hoveredRating >= star || rating >= star)
                      ? 'text-yellow-400 fill-yellow-400'
                      : 'text-gray-300'
                  )}
                />
              </button>
            ))}
          </div>
          {rating > 0 && (
            <p className="text-sm text-gray-600 mt-2">
              {rating === 1 && 'Muito ruim'}
              {rating === 2 && 'Ruim'}
              {rating === 3 && 'Regular'}
              {rating === 4 && 'Bom'}
              {rating === 5 && 'Excelente'}
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Conte-nos mais sobre sua experiência
          </label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Compartilhe suas sugestões, problemas encontrados ou o que mais gostou..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
            rows={4}
            required
          />
          <div className="text-xs text-gray-500 mt-1">
            {message.length}/500 caracteres
          </div>
        </div>

        <div className="flex gap-3">
          <Button
            type="button"
            variant="outline"
            onClick={handleClose}
            className="flex-1"
            disabled={loading}
          >
            Cancelar
          </Button>
          <Button
            type="submit"
            className="flex-1"
            disabled={loading || rating === 0 || !message.trim()}
          >
            <Send className="w-4 h-4 mr-2" />
            {loading ? 'Enviando...' : 'Enviar Feedback'}
          </Button>
        </div>
      </form>
    </Modal>
  )
}