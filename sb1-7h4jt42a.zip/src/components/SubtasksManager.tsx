import React, { useState } from 'react'
import { Plus, Check, X, GripVertical, ChevronDown, ChevronRight } from 'lucide-react'
import { Button } from './ui/Button'
import { Input } from './ui/Input'
import { useSubtasks } from '../hooks/useSubtasks'
import { cn } from '../lib/utils'

interface SubtasksManagerProps {
  taskId: string
  isExpanded: boolean
  onToggleExpanded: () => void
}

export function SubtasksManager({ taskId, isExpanded, onToggleExpanded }: SubtasksManagerProps) {
  const { subtasks, createSubtask, toggleSubtask, deleteSubtask, updateSubtask } = useSubtasks(taskId)
  const [newSubtaskTitle, setNewSubtaskTitle] = useState('')
  const [editingSubtask, setEditingSubtask] = useState<string | null>(null)
  const [editTitle, setEditTitle] = useState('')

  const completedCount = subtasks.filter(s => s.is_done).length
  const totalCount = subtasks.length

  const handleCreateSubtask = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newSubtaskTitle.trim()) return

    await createSubtask(newSubtaskTitle.trim())
    setNewSubtaskTitle('')
  }

  const handleEditSubtask = (subtaskId: string, title: string) => {
    setEditingSubtask(subtaskId)
    setEditTitle(title)
  }

  const handleSaveEdit = async (subtaskId: string) => {
    if (!editTitle.trim()) return

    await updateSubtask(subtaskId, { title: editTitle.trim() })
    setEditingSubtask(null)
    setEditTitle('')
  }

  const handleCancelEdit = () => {
    setEditingSubtask(null)
    setEditTitle('')
  }

  return (
    <div className="mt-3 border-t border-gray-200 dark:border-gray-700 pt-3">
      <div className="flex items-center justify-between mb-3">
        <button
          onClick={onToggleExpanded}
          className="flex items-center text-sm font-medium text-gray-700 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white transition-colors"
        >
          {isExpanded ? (
            <ChevronDown className="w-4 h-4 mr-1" />
          ) : (
            <ChevronRight className="w-4 h-4 mr-1" />
          )}
          Subtarefas
          {totalCount > 0 && (
            <span className="ml-2 px-2 py-1 text-xs bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 rounded-full">
              {completedCount}/{totalCount}
            </span>
          )}
        </button>
      </div>

      {isExpanded && (
        <div className="space-y-2">
          {/* Add new subtask */}
          <form onSubmit={handleCreateSubtask} className="flex items-center space-x-2">
            <Input
              value={newSubtaskTitle}
              onChange={(e) => setNewSubtaskTitle(e.target.value)}
              placeholder="Adicionar subtarefa..."
              className="flex-1 text-sm"
            />
            <Button type="submit" size="sm" disabled={!newSubtaskTitle.trim()}>
              <Plus className="w-4 h-4" />
            </Button>
          </form>

          {/* Subtasks list */}
          {subtasks.length > 0 && (
            <div className="space-y-2">
              {subtasks.map(subtask => (
                <div
                  key={subtask.id}
                  className={cn(
                    'flex items-center space-x-2 p-2 rounded-lg border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50',
                    subtask.is_done && 'opacity-60'
                  )}
                >
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleSubtask(subtask.id, !subtask.is_done)}
                    className={cn(
                      'p-1 rounded-full transition-all duration-200',
                      subtask.is_done 
                        ? 'bg-green-100 text-green-600 hover:bg-green-200' 
                        : 'bg-gray-100 text-gray-400 hover:bg-gray-200'
                    )}
                  >
                    <Check className="w-3 h-3" />
                  </Button>

                  {editingSubtask === subtask.id ? (
                    <div className="flex-1 flex items-center space-x-2">
                      <Input
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        className="flex-1 text-sm"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            handleSaveEdit(subtask.id)
                          } else if (e.key === 'Escape') {
                            handleCancelEdit()
                          }
                        }}
                        autoFocus
                      />
                      <Button
                        size="sm"
                        onClick={() => handleSaveEdit(subtask.id)}
                        className="p-1"
                      >
                        <Check className="w-3 h-3" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={handleCancelEdit}
                        className="p-1"
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <>
                      <span
                        className={cn(
                          'flex-1 text-sm cursor-pointer transition-all duration-200',
                          subtask.is_done && 'line-through text-gray-500'
                        )}
                        onClick={() => handleEditSubtask(subtask.id, subtask.title)}
                      >
                        {subtask.title}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteSubtask(subtask.id)}
                        className="p-1 text-red-500 hover:text-red-700 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </>
                  )}
                </div>
              ))}
            </div>
          )}

          {/* Progress bar */}
          {totalCount > 0 && (
            <div className="mt-3">
              <div className="flex items-center justify-between text-xs text-gray-600 dark:text-gray-400 mb-1">
                <span>Progresso</span>
                <span>{Math.round((completedCount / totalCount) * 100)}%</span>
              </div>
              <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                <div
                  className="bg-green-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${(completedCount / totalCount) * 100}%` }}
                />
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}