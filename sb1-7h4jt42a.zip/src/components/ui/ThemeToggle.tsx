import React from 'react'
import { Moon, Sun } from 'lucide-react'
import { Button } from './Button'
import { useTheme } from '../../contexts/ThemeContext'

export function ThemeToggle() {
  const { theme, toggleTheme, loading } = useTheme()

  if (loading) {
    return (
      <Button variant="ghost" size="sm" className="p-2" disabled>
        <div className="w-5 h-5 animate-pulse bg-gray-300 rounded" />
      </Button>
    )
  }

  return (
    <Button
      variant="ghost"
      size="sm"
      onClick={toggleTheme}
      className="p-2 theme-toggle-button relative overflow-hidden"
      title={theme === 'dark' ? 'Mudar para tema claro' : 'Mudar para tema escuro'}
    >
      {theme === 'dark' ? (
        <Sun className="w-5 h-5 text-yellow-500 transition-transform duration-300 hover:rotate-180 hover:scale-110" />
      ) : (
        <Moon className="w-5 h-5 text-gray-600 transition-transform duration-300 hover:rotate-12 hover:scale-110" />
      )}
    </Button>
  )
}