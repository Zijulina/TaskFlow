import React, { useState } from 'react'
import { Play, Pause, Square, Timer, Coffee, RotateCcw } from 'lucide-react'
import { Button } from './ui/Button'
import { Card } from './ui/Card'
import { Modal } from './ui/Modal'
import { usePomodoro } from '../hooks/usePomodoro'
import { Task } from '../hooks/useTasks'
import { cn } from '../lib/utils'

interface PomodoroTimerProps {
  tasks: Task[]
}

export function PomodoroTimer({ tasks }: PomodoroTimerProps) {
  const {
    currentSession,
    timeLeft,
    isRunning,
    startSession,
    pauseSession,
    resumeSession,
    stopSession,
    formatTime,
    getTodayStats
  } = usePomodoro()

  const [showStartModal, setShowStartModal] = useState(false)
  const [selectedTaskId, setSelectedTaskId] = useState<string>('')
  const [sessionDuration, setSessionDuration] = useState(25)
  const [sessionType, setSessionType] = useState<'work' | 'short_break' | 'long_break'>('work')

  const stats = getTodayStats()
  const pendingTasks = tasks.filter(task => !task.is_done)

  const handleStartSession = async () => {
    await startSession(
      selectedTaskId || null,
      sessionDuration,
      sessionType
    )
    setShowStartModal(false)
    setSelectedTaskId('')
  }

  const getSessionTypeLabel = (type: string) => {
    switch (type) {
      case 'work': return 'Trabalho'
      case 'short_break': return 'Pausa Curta'
      case 'long_break': return 'Pausa Longa'
      default: return 'Trabalho'
    }
  }

  const getSessionTypeColor = (type: string) => {
    switch (type) {
      case 'work': return 'text-red-600'
      case 'short_break': return 'text-green-600'
      case 'long_break': return 'text-blue-600'
      default: return 'text-red-600'
    }
  }

  return (
    <Card>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center">
          <Timer className="w-5 h-5 text-red-600 mr-2" />
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
            Pomodoro Timer
          </h3>
        </div>
        {!currentSession && (
          <Button onClick={() => setShowStartModal(true)} size="sm">
            <Play className="w-4 h-4 mr-1" />
            Iniciar
          </Button>
        )}
      </div>

      {currentSession ? (
        <div className="text-center space-y-4">
          <div className="space-y-2">
            <div className={cn(
              'text-4xl font-mono font-bold',
              getSessionTypeColor(currentSession.session_type)
            )}>
              {formatTime(timeLeft)}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">
              {getSessionTypeLabel(currentSession.session_type)} • {currentSession.duration_minutes} min
            </div>
            {currentSession.task_id && (
              <div className="text-sm text-gray-700 dark:text-gray-300">
                {tasks.find(t => t.id === currentSession.task_id)?.title || 'Tarefa removida'}
              </div>
            )}
          </div>

          <div className="flex items-center justify-center space-x-2">
            {isRunning ? (
              <Button onClick={pauseSession} variant="outline">
                <Pause className="w-4 h-4 mr-1" />
                Pausar
              </Button>
            ) : (
              <Button onClick={resumeSession}>
                <Play className="w-4 h-4 mr-1" />
                Continuar
              </Button>
            )}
            <Button onClick={stopSession} variant="outline">
              <Square className="w-4 h-4 mr-1" />
              Parar
            </Button>
          </div>

          {/* Progress bar */}
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
            <div
              className={cn(
                'h-2 rounded-full transition-all duration-1000',
                currentSession.session_type === 'work' ? 'bg-red-500' :
                currentSession.session_type === 'short_break' ? 'bg-green-500' :
                'bg-blue-500'
              )}
              style={{ 
                width: `${((currentSession.duration_minutes * 60 - timeLeft) / (currentSession.duration_minutes * 60)) * 100}%` 
              }}
            />
          </div>
        </div>
      ) : (
        <div className="text-center py-4">
          <Timer className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-2" />
          <p className="text-gray-600 dark:text-gray-400 text-sm">
            Nenhuma sessão ativa
          </p>
        </div>
      )}

      {/* Today's Stats */}
      <div className="mt-6 pt-4 border-t border-gray-200 dark:border-gray-700">
        <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
          Estatísticas de Hoje
        </h4>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-lg font-semibold text-gray-900 dark:text-white">
              {stats.completedSessions}
            </div>
            <div className="text-xs text-gray-600 dark:text-gray-400">
              Sessões
            </div>
          </div>
          <div>
            <div className="text-lg font-semibold text-gray-900 dark:text-white">
              {stats.totalMinutes}
            </div>
            <div className="text-xs text-gray-600 dark:text-gray-400">
              Minutos
            </div>
          </div>
          <div>
            <div className="text-lg font-semibold text-gray-900 dark:text-white">
              {stats.workSessions}
            </div>
            <div className="text-xs text-gray-600 dark:text-gray-400">
              Trabalho
            </div>
          </div>
        </div>
      </div>

      {/* Start Session Modal */}
      <Modal
        isOpen={showStartModal}
        onClose={() => {
          setShowStartModal(false)
          setSelectedTaskId('')
        }}
        title="Iniciar Sessão Pomodoro"
      >
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Tipo de Sessão
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => {
                  setSessionType('work')
                  setSessionDuration(25)
                }}
                className={cn(
                  'p-3 rounded-lg border text-center transition-all',
                  sessionType === 'work'
                    ? 'border-red-500 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300'
                    : 'border-gray-300 dark:border-gray-600 hover:border-gray-400'
                )}
              >
                <div className="text-sm font-medium">Trabalho</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">25 min</div>
              </button>
              <button
                onClick={() => {
                  setSessionType('short_break')
                  setSessionDuration(5)
                }}
                className={cn(
                  'p-3 rounded-lg border text-center transition-all',
                  sessionType === 'short_break'
                    ? 'border-green-500 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300'
                    : 'border-gray-300 dark:border-gray-600 hover:border-gray-400'
                )}
              >
                <div className="text-sm font-medium">Pausa</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">5 min</div>
              </button>
              <button
                onClick={() => {
                  setSessionType('long_break')
                  setSessionDuration(15)
                }}
                className={cn(
                  'p-3 rounded-lg border text-center transition-all',
                  sessionType === 'long_break'
                    ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-300'
                    : 'border-gray-300 dark:border-gray-600 hover:border-gray-400'
                )}
              >
                <div className="text-sm font-medium">Pausa Longa</div>
                <div className="text-xs text-gray-600 dark:text-gray-400">15 min</div>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Duração (minutos)
            </label>
            <input
              type="number"
              value={sessionDuration}
              onChange={(e) => setSessionDuration(parseInt(e.target.value) || 25)}
              min="1"
              max="60"
              className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
            />
          </div>

          {sessionType === 'work' && pendingTasks.length > 0 && (
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Tarefa (opcional)
              </label>
              <select
                value={selectedTaskId}
                onChange={(e) => setSelectedTaskId(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
              >
                <option value="">Nenhuma tarefa específica</option>
                {pendingTasks.map(task => (
                  <option key={task.id} value={task.id}>
                    {task.title}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setShowStartModal(false)
                setSelectedTaskId('')
              }}
              className="flex-1"
            >
              Cancelar
            </Button>
            <Button onClick={handleStartSession} className="flex-1">
              <Play className="w-4 h-4 mr-2" />
              Iniciar Sessão
            </Button>
          </div>
        </div>
      </Modal>
    </Card>
  )
}