import React from 'react'
import { CheckSquare, User, LogOut, MessageSquare, PiggyBank, Settings } from 'lucide-react'
import { Button } from './ui/Button'
import { ThemeToggle } from './ui/ThemeToggle'
import { FeedbackModal } from './FeedbackModal'
import { useSubscription } from '../hooks/useSubscription'
import { useAuth } from '../hooks/useAuth'
import { useUserProfile } from '../hooks/useUserProfile'
import { useTheme } from '../contexts/ThemeContext'
import { getDisplayName } from '../utils/nameValidation'
import { Link, useNavigate, useLocation } from 'react-router-dom'

export function Header() {
  const { user, signOut } = useAuth()
  const { profile } = useUserProfile()
  const { isPro, isEssential } = useSubscription()
  const { saveThemeToStorage } = useTheme()
  const navigate = useNavigate()
  const location = useLocation()
  const [showFeedbackModal, setShowFeedbackModal] = React.useState(false)
  const [feedbackSubmitted, setFeedbackSubmitted] = React.useState(() => {
    // Check if feedback was already submitted in this session
    return sessionStorage.getItem('feedback-submitted') === 'true'
  })

  const handleSignOut = async () => {
    // Clear feedback session storage on logout
    sessionStorage.removeItem('feedback-submitted')
    
    try {
      const { error } = await signOut(saveThemeToStorage)
      if (error) {
        console.error('Header logout error:', error)
      }
      
      // Clear all storage
      const savedTheme = localStorage.getItem('taskflow-theme')
      localStorage.clear()
      sessionStorage.clear()
      
      // Restore theme
      if (savedTheme) {
        localStorage.setItem('taskflow-theme', savedTheme)
      }
      
      // Force redirect to home
      window.location.href = '/'
    } catch (err) {
      console.error('Unexpected header logout error:', err)
      // Force redirect even on error
      window.location.href = '/'
    }
  }

  const handleLogoClick = () => {
    if (user) {
      navigate('/dashboard')
    } else {
      navigate('/')
    }
  }

  const handleFeedbackSuccess = () => {
    setFeedbackSubmitted(true)
    sessionStorage.setItem('feedback-submitted', 'true')
  }

  return (
    <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <button onClick={handleLogoClick} className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
            <CheckSquare className="w-8 h-8 text-blue-600" />
            <span className="text-xl font-bold text-gray-900">TaskFlow</span>
          </button>

          <nav className="flex items-center space-x-4">
            <ThemeToggle />
            {user ? (
              <>
                <Link to="/dashboard">
                  <Button variant="ghost" size="sm">
                    Dashboard
                  </Button>
                </Link>
                <Link to="/cofrinho">
                  <Button variant="ghost" size="sm">
                    <PiggyBank className="w-4 h-4 mr-1" />
                    Cofrinho
                  </Button>
                </Link>
                <Link to="/upgrade">
                  <Button variant="ghost" size="sm">
                    Upgrade
                  </Button>
                </Link>
                {!feedbackSubmitted && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setShowFeedbackModal(true)}
                  >
                    <MessageSquare className="w-4 h-4 mr-1" />
                    Feedback
                  </Button>
                )}
                <div className="flex items-center space-x-2">
                  <User className="w-5 h-5 text-gray-600" />
                  <span className="text-sm text-gray-600 dark:text-gray-300">
                    Olá, {getDisplayName(profile?.name || '')}
                  </span>
                  {(isPro || isEssential) && (
                    <span className={`px-2 py-1 text-xs rounded-full font-medium ${
                      isPro 
                        ? 'bg-yellow-100 text-yellow-800' 
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {isPro ? 'Pro' : 'Essencial'}
                    </span>
                  )}
                  <Link to="/configuracoes">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="p-1"
                      title="Configurações da conta"
                    >
                      <Settings className="w-4 h-4" />
                    </Button>
                  </Link>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleSignOut}
                    className="p-1"
                    title="Sair da conta"
                  >
                    <LogOut className="w-4 h-4" />
                  </Button>
                </div>
              </>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="ghost" size="sm">
                    Entrar
                  </Button>
                </Link>
                <Link to="/signup">
                  <Button variant="primary" size="sm">
                    Cadastrar
                  </Button>
                </Link>
              </>
            )}
          </nav>
        </div>
      </div>
      
      <FeedbackModal
        isOpen={showFeedbackModal}
        onClose={() => setShowFeedbackModal(false)}
        onSuccess={handleFeedbackSuccess}
      />
    </header>
  )
}