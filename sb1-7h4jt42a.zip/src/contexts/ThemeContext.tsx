import React, { createContext, useContext, useState, useEffect } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from '../hooks/useAuth'

interface ThemeContextType {
  theme: 'light' | 'dark'
  toggleTheme: () => void
  saveThemeToStorage: () => void
  loading: boolean
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth()
  const [theme, setTheme] = useState<'light' | 'dark'>('light')
  const [loading, setLoading] = useState(true)

  // Load theme from database or localStorage
  useEffect(() => {
    const loadTheme = async () => {
      if (user) {
        // Load from database for authenticated users
        const { data } = await supabase
          .from('user_preferences')
          .select('theme')
          .eq('user_id', user.id)
          .single()
        
        if (data?.theme) {
          setTheme(data.theme === 'dark' ? 'dark' : 'light')
        } else {
          // Create default preference
          await supabase
            .from('user_preferences')
            .upsert({
              user_id: user.id,
              theme: 'light'
            })
        }
      } else {
        // Load from localStorage for non-authenticated users
        const saved = localStorage.getItem('taskflow-theme')
        setTheme(saved === 'dark' ? 'dark' : 'light')
      }
      setLoading(false)
    }

    loadTheme()
  }, [user])

  // Apply theme to document
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [theme])

  const saveThemeToStorage = () => {
    // Always save current theme to localStorage for persistence across sessions
    localStorage.setItem('taskflow-theme', theme)
  }
  const toggleTheme = async () => {
    const newTheme = theme === 'light' ? 'dark' : 'light'
    setTheme(newTheme)

    // Always save to localStorage immediately
    localStorage.setItem('taskflow-theme', newTheme)
    if (user) {
      // Save to database
      supabase
        .from('user_preferences')
        .upsert({
          user_id: user.id,
          theme: newTheme
        })
    }
  }

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, saveThemeToStorage, loading }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (context === undefined) {
    throw new Error('useTheme must be used within a ThemeProvider')
  }
  return context
}