export const stripeProducts = [
  {
    id: 'prod_essential_monthly',
    priceId: 'price_essential_monthly', // You'll need to create this in Stripe Dashboard
    name: 'Plano Essencial',
    description: 'Funcionalidades essenciais para organizar suas tarefas com eficiência.',
    mode: 'subscription' as const,
    price: 'R$ 2,90/mês',
    interval: 'monthly' as const,
    features: [
      'Tarefas ilimitadas',
      'Subtarefas e checklists',
      'Organização por etiquetas',
      'Lembretes inteligentes',
      'Filtros personalizados',
      'Modo de foco',
      'Salvamento automático',
      'Histórico de 30 dias',
      'Modo de data da tarefa',
      'Anotações rápidas ilimitadas',
      'Subtarefas e checklists',
      'Timer Pomodoro integrado'
    ]
  },
  {
    id: 'prod_Sl6ICX12tCMszM',
    priceId: 'price_1Rpa5iPJ1AWhgUPiM5hGnQrk',
    name: 'Plano Pro Anual',
    description: 'Todas as funcionalidades do Essencial + recursos avançados para máxima produtividade.',
    mode: 'subscription' as const,
    price: 'R$ 19,00/ano',
    interval: 'yearly' as const,
    features: [
      'Todas as funcionalidades do Essencial',
      'Histórico completo de tarefas',
      'Agrupamento avançado',
      'Estatísticas de produtividade',
      'Planejamento semanal',
      'Suporte prioritário',
      'Backup automático',
      'Templates de tarefas',
      'Insights avançados de produtividade',
      'Análise de padrões de trabalho'
    ]
  }
] as const

export type StripeProduct = typeof stripeProducts[number]