import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import { Header } from './components/Header'
import { Footer } from './components/Footer'
import { ProtectedRoute } from './components/ProtectedRoute'
import { AuthenticatedRoute } from './components/AuthenticatedRoute'
import { LandingPage } from './pages/LandingPage'
import { LoginPage } from './pages/LoginPage'
import { SignupPage } from './pages/SignupPage'
import { ForgotPasswordPage } from './pages/ForgotPasswordPage'
import { ResetPasswordPage } from './pages/ResetPasswordPage'
import { Dashboard } from './pages/Dashboard'
import { UpgradePage } from './pages/UpgradePage'
import { SuccessPage } from './pages/SuccessPage'
import { PiggyBankPage } from './pages/PiggyBankPage'
import { AccountSettingsPage } from './pages/AccountSettingsPage'
import { AccountDeletionSuccessPage } from './pages/AccountDeletionSuccessPage'

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-white dark:bg-black flex flex-col transition-colors duration-200">
        <Header />
        <main className="flex-1">
          <Routes>
            <Route 
              path="/" 
              element={
                <AuthenticatedRoute>
                  <LandingPage />
                </AuthenticatedRoute>
              } 
            />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/reset-password" element={<ResetPasswordPage />} />
            <Route 
              path="/login" 
              element={
                <AuthenticatedRoute>
                  <LoginPage />
                </AuthenticatedRoute>
              } 
            />
            <Route 
              path="/signup" 
              element={
                <AuthenticatedRoute>
                  <SignupPage />
                </AuthenticatedRoute>
              } 
            />
            <Route 
              path="/dashboard" 
              element={
                <ProtectedRoute>
                  <Dashboard />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/cofrinho" 
              element={
                <ProtectedRoute>
                  <PiggyBankPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/upgrade" 
              element={
                <ProtectedRoute>
                  <UpgradePage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/success" 
              element={
                <ProtectedRoute>
                  <SuccessPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/configuracoes" 
              element={
                <ProtectedRoute>
                  <AccountSettingsPage />
                </ProtectedRoute>
              } 
            />
            <Route 
              path="/account-deleted" 
              element={<AccountDeletionSuccessPage />} 
            />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  )
}

export default App