import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { CheckSquare, Mail, Lock, User } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Input } from '../components/ui/Input'
import { Card } from '../components/ui/Card'
import { useAuth } from '../hooks/useAuth'
import { validateName, formatNameForSave } from '../utils/nameValidation'
import { supabase } from '../lib/supabase'

export function SignupPage() {
  const [email, setEmail] = useState('')
  const [name, setName] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [showVerificationMessage, setShowVerificationMessage] = useState(false)
  
  const { signUpWithName } = useAuth()
  const navigate = useNavigate()

  const checkIfEmailExists = async (email: string): Promise<boolean> => {
    try {
      // Usa a função do banco para verificar se email existe
      const { data, error } = await supabase.rpc('check_email_exists', {
        email_to_check: email
      })
      
      if (error) {
        console.error('Erro ao verificar email:', error)
        return false
      }
      
      return data === true
    } catch (error) {
      console.error('Erro na verificação de email:', error)
      return false
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    if (!email || !name || !password || !confirmPassword) {
      setError('Por favor, preencha todos os campos')
      setLoading(false)
      return
    }

    const nameValidation = validateName(name)
    if (!nameValidation.isValid) {
      setError(nameValidation.error!)
      setLoading(false)
      return
    }
    
    if (password !== confirmPassword) {
      setError('As senhas não coincidem')
      setLoading(false)
      return
    }

    if (password.length < 6) {
      setError('A senha deve ter pelo menos 6 caracteres')
      setLoading(false)
      return
    }

    // Verifica se email já existe antes de tentar cadastrar
    const emailExists = await checkIfEmailExists(email)
    if (emailExists) {
      setError('Esta conta já foi registrada. Tente fazer login ou use outro email.')
      setLoading(false)
      return
    }

    try {
      // Registra tentativa de cadastro
      await supabase.from('email_tracking').upsert({
        email,
        status: 'pending'
      })

      const formattedName = formatNameForSave(name)
      const { data: signUpData, error: signUpError } = await signUpWithName(email, password, formattedName)
      
      if (signUpError) {
        // Atualiza status para failed
        await supabase.from('email_tracking').upsert({
          email,
          status: 'failed'
        })
        
        if (signUpError.message.includes('User already registered') || 
            signUpError.message.includes('already registered') ||
            signUpError.message.includes('email_address_already_in_use')) {
          setError('Esta conta já foi registrada. Tente fazer login ou use outro email.')
        } else if (signUpError.message.includes('NetworkError') || signUpError.message.includes('Failed to fetch')) {
          setError('Erro de conexão. Verifique se as configurações do Supabase estão corretas.')
        } else {
          setError(signUpError.message)
        }
        setLoading(false)
        return
      }

      // Atualiza status para registered
      await supabase.from('email_tracking').upsert({
        email,
        status: 'registered'
      })

      // Se não houve erro, mostra a tela de verificação
      if (signUpData?.user && !signUpData.user.email_confirmed_at) {
        setShowVerificationMessage(true)
      } else {
        // Se o usuário já está confirmado, redireciona para o dashboard
        navigate('/dashboard')
      }
      
    } catch (err) {
      console.error('Erro no cadastro:', err)
      setError('Erro interno. Tente novamente.')
    }

    setLoading(false)
  }

  if (showVerificationMessage) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md w-full">
          <Card className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-green-600" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Verifique seu email
            </h2>
            <p className="text-gray-600 mb-6">
              Enviamos um link de confirmação para <strong>{email}</strong>. 
              Clique no link para ativar sua conta e começar a usar o TaskFlow.
            </p>
            <div className="space-y-3">
              <Button 
                onClick={() => navigate('/login')}
                className="w-full"
              >
                Ir para Login
              </Button>
              <Button 
                variant="outline"
                onClick={() => setShowVerificationMessage(false)}
                className="w-full"
              >
                Voltar ao Cadastro
              </Button>
            </div>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <CheckSquare className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-gray-900">
            Crie sua conta
          </h2>
          <p className="mt-2 text-gray-600">
            Já tem uma conta?{' '}
            <Link to="/login" className="text-blue-600 hover:text-blue-500">
              Entre aqui
            </Link>
          </p>
        </div>

        <Card>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
                {error}
              </div>
            )}
            
            <div className="relative">
              <User className="absolute left-3 top-9 w-5 h-5 text-gray-400" />
              <Input
                label="Nome completo"
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="pl-10"
                placeholder="Seu nome completo"
                maxLength={30}
                required
              />
              <div className="text-xs text-gray-500 mt-1">
                {name.length}/30 caracteres • Apenas letras e espaços
              </div>
            </div>

            <div className="relative">
              <Mail className="absolute left-3 top-9 w-5 h-5 text-gray-400" />
              <Input
                label="Email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10"
                placeholder="seu@email.com"
                required
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-9 w-5 h-5 text-gray-400" />
              <Input
                label="Senha"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10"
                placeholder="••••••••"
                required
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-9 w-5 h-5 text-gray-400" />
              <Input
                label="Confirmar senha"
                type="password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="pl-10"
                placeholder="••••••••"
                required
              />
            </div>

            <Button 
              type="submit" 
              className="w-full" 
              disabled={loading}
            >
              {loading ? 'Verificando...' : 'Criar conta'}
            </Button>
          </form>
        </Card>
      </div>
    </div>
  )
}