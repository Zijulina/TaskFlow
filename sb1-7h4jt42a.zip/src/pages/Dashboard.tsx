import React, { useState } from 'react'
import { Plus, CheckSquare, Clock, AlertTriangle, Settings, Trash2, FolderPlus, Folder, StickyNote, Timer, MoreVertical } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Input } from '../components/ui/Input'
import { Card } from '../components/ui/Card'
import { Modal } from '../components/ui/Modal'
import { TaskCard } from '../components/TaskCard'
import { QuickNotesWidget } from '../components/QuickNotesWidget'
import { PomodoroTimer } from '../components/PomodoroTimer'
import { useTasks } from '../hooks/useTasks'
import { useSubscription } from '../hooks/useSubscription'
import { useRateLimit } from '../hooks/useRateLimit'
import { isValidTaskTitle } from '../utils/taskValidation'
import { Link } from 'react-router-dom'

export function Dashboard() {
  const [newTaskTitle, setNewTaskTitle] = useState('')
  const [selectedPriority, setSelectedPriority] = useState<'low' | 'medium' | 'high' | 'urgent' | 'none'>('')
  const [selectedProject, setSelectedProject] = useState<string>('')
  const [filterPriority, setFilterPriority] = useState<string>('')
  const [filterProject, setFilterProject] = useState<string>('')
  const [showAdvancedForm, setShowAdvancedForm] = useState(false)
  const [showLimitModal, setShowLimitModal] = useState(false)
  const [showRateLimitModal, setShowRateLimitModal] = useState(false)
  const [showInvalidTaskModal, setShowInvalidTaskModal] = useState(false)
  const [showDeleteLimitModal, setShowDeleteLimitModal] = useState(false)
  const [showProjectModal, setShowProjectModal] = useState(false)
  const [showProjectLimitModal, setShowProjectLimitModal] = useState(false)
  const [showDeleteProjectModal, setShowDeleteProjectModal] = useState(false)
  const [projectToDelete, setProjectToDelete] = useState<any>(null)
  const [newProjectName, setNewProjectName] = useState('')
  const [newProjectDescription, setNewProjectDescription] = useState('')
  const [newProjectColor, setNewProjectColor] = useState('#3b82f6')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  
  const { tasks, projects, addTask, toggleTask, deleteTask, updateTaskCost, addProject, deleteProject } = useTasks()
  const { subscription, isPro, isEssential, hasPremiumFeatures } = useSubscription()
  const { isLimited, remainingTimeFormatted, incrementCount, currentCount } = useRateLimit(subscription?.customer_id || '')

  // Track deletions for free users
  const [deletionsToday, setDeletionsToday] = useState(() => {
    const today = new Date().toDateString()
    const saved = localStorage.getItem(`taskflow-deletions-${today}`)
    return saved ? parseInt(saved) : 0
  })

  const handleDeleteProject = async () => {
    if (!projectToDelete) return
    
    const { error } = await deleteProject(projectToDelete.id)
    
    if (!error) {
      setShowDeleteProjectModal(false)
      setProjectToDelete(null)
    }
  }
  const handleCreateProject = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Check project limit for free users
    if (!hasPremiumFeatures && projects.length >= 1) {
      setShowProjectLimitModal(true)
      return
    }
    
    if (!newProjectName.trim()) return
    
    await addProject(newProjectName.trim(), newProjectDescription.trim(), newProjectColor)
    
    setNewProjectName('')
    setNewProjectDescription('')
    setNewProjectColor('#3b82f6')
    setShowProjectModal(false)
  }

  const handleDeleteTask = async (taskId: string) => {
    // Check deletion limit for free users
    if (!hasPremiumFeatures) {
      if (deletionsToday >= 5) {
        setShowDeleteLimitModal(true)
        return
      }
    }

    // Proceed with deletion
    const { error } = await deleteTask(taskId)
    
    if (!error && !hasPremiumFeatures) {
      // Increment deletion count for free users
      const newCount = deletionsToday + 1
      setDeletionsToday(newCount)
      const today = new Date().toDateString()
      localStorage.setItem(`taskflow-deletions-${today}`, newCount.toString())
    }
  }

  // Filter tasks based on selected filters
  const filteredTasks = tasks.filter(task => {
    if (filterPriority) {
      if (task.priority !== filterPriority) return false
    }
    if (filterProject && task.project_id !== filterProject) return false
    return true
  })

  const handleAddTask = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newTaskTitle.trim()) return

    // Check for duplicate task names (max 3 with same name)
    const duplicateCount = tasks.filter(task => 
      task.title.toLowerCase().trim() === newTaskTitle.toLowerCase().trim()
    ).length
    
    if (duplicateCount >= 3) {
      setError('Você já tem 3 tarefas com este nome. Escolha um nome diferente.')
      return
    }

    // Validação de conteúdo da tarefa
    if (!isValidTaskTitle(newTaskTitle.trim())) {
      setShowInvalidTaskModal(true)
      return
    }

    // Check limits for free users
    if (!hasPremiumFeatures && tasks.length >= 5) {
      setShowLimitModal(true)
      return
    }

    // Check rate limit for Pro users
    if (hasPremiumFeatures && isLimited) {
      setShowRateLimitModal(true)
      return
    }

    setLoading(true)
    await addTask(newTaskTitle.trim(), {
      priority: selectedPriority === '' ? null : selectedPriority,
      project_id: selectedProject || undefined
    })
    
    // Incrementa contador de rate limit para usuários Pro
    if (hasPremiumFeatures) {
      incrementCount()
    }
    
    setNewTaskTitle('')
    setSelectedPriority('')
    setSelectedProject('')
    setShowAdvancedForm(false)
    setError('')
    setLoading(false)
  }

  const completedTasks = filteredTasks.filter(task => task.is_done).length
  const pendingTasks = filteredTasks.length - completedTasks
  const urgentTasks = filteredTasks.filter(task => task.priority === 'urgent' && !task.is_done).length

  const getPlanDisplayName = () => {
    if (isPro) return 'Plano Pro Anual'
    if (isEssential) return 'Plano Essencial'
    return 'Plano Gratuito'
  }

  const getPlanColor = () => {
    if (isPro) return 'bg-yellow-100 text-yellow-800'
    if (isEssential) return 'bg-blue-100 text-blue-800'
    return 'bg-gray-100 text-gray-800'
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
            <div className="flex items-center space-x-2">
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getPlanColor()}`}>
                {getPlanDisplayName()}
              </span>
            </div>
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mr-4">
                  <CheckSquare className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total de Tarefas</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{filteredTasks.length}</p>
                </div>
              </div>
            </Card>
            
            <Card>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mr-4">
                  <CheckSquare className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Concluídas</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{completedTasks}</p>
                </div>
              </div>
            </Card>
            
            <Card>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-orange-100 dark:bg-orange-900/30 rounded-lg flex items-center justify-center mr-4">
                  <Clock className="w-6 h-6 text-orange-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Pendentes</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{pendingTasks}</p>
                </div>
              </div>
            </Card>
            
            <Card>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center mr-4">
                  <AlertTriangle className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Urgentes</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{urgentTasks}</p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Add Task Form */}
            <Card>
              <div className="mb-4">
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Adicionar Nova Tarefa</h2>
                
                <form onSubmit={handleAddTask} className="space-y-4">
                  {error && (
                    <div className="bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-3 rounded-lg">
                      {error}
                    </div>
                  )}
                  
                  <div className="flex gap-4 items-end">
                    <Input
                      placeholder="Digite uma nova tarefa..."
                      value={newTaskTitle}
                      onChange={(e) => {
                        setNewTaskTitle(e.target.value)
                        setError('')
                      }}
                      className="flex-1"
                    />
                    
                    {hasPremiumFeatures && (
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setShowAdvancedForm(!showAdvancedForm)}
                      >
                        <Settings className="w-4 h-4 mr-2" />
                        {showAdvancedForm ? 'Simples' : 'Avançado'}
                      </Button>
                    )}
                    
                    <Button 
                      type="submit" 
                      disabled={loading || !newTaskTitle.trim() || (hasPremiumFeatures && isLimited)}
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      {loading ? 'Adicionando...' : 'Adicionar'}
                    </Button>
                  </div>
                  
                  {/* Advanced Form */}
                  {showAdvancedForm && hasPremiumFeatures && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-gray-200 dark:border-gray-700">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Prioridade
                        </label>
                        <select
                          value={selectedPriority}
                          onChange={(e) => setSelectedPriority(e.target.value as any)}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                        >
                          <option value="">Nenhuma</option>
                          <option value="low">Baixa</option>
                          <option value="medium">Média</option>
                          <option value="high">Alta</option>
                          <option value="urgent">Urgente</option>
                        </select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                          Projeto
                        </label>
                        <select
                          value={selectedProject}
                          onChange={(e) => setSelectedProject(e.target.value)}
                          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                        >
                          <option value="">Nenhum projeto</option>
                          {projects.map(project => (
                            <option key={project.id} value={project.id}>
                              {project.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  )}
                </form>
                
                {!hasPremiumFeatures && (
                  <div className="mt-4 text-sm text-gray-600 dark:text-gray-400">
                    Você está usando {tasks.length} de 5 tarefas disponíveis no plano gratuito.
                    {tasks.length >= 4 && (
                      <span className="text-orange-600 font-medium">
                        {' '}Considere o Plano Essencial para ter tarefas ilimitadas!
                      </span>
                    )}
                  </div>
                )}
                
                {hasPremiumFeatures && isLimited && (
                  <div className="mt-4 p-3 bg-orange-50 dark:bg-orange-900/30 border border-orange-200 dark:border-orange-800 rounded-lg">
                    <div className="flex items-center">
                      <Clock className="w-4 h-4 text-orange-600 mr-2" />
                      <span className="text-sm text-orange-800 dark:text-orange-300">
                        Rate limit ativo. Você pode criar mais tarefas em {remainingTimeFormatted}
                      </span>
                    </div>
                    <div className="text-xs text-orange-600 dark:text-orange-400 mt-1">
                      Criadas {currentCount}/30 tarefas nos últimos 3 minutos
                    </div>
                  </div>
                )}
              </div>
            </Card>

            {/* Filters */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Filtros</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    setFilterPriority('')
                    setFilterProject('')
                  }}
                >
                  Limpar
                </Button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Prioridade
                  </label>
                  <select
                    value={filterPriority}
                    onChange={(e) => setFilterPriority(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  >
                    <option value="">Todas as prioridades</option>
                    <option value="urgent">Urgente</option>
                    <option value="high">Alta</option>
                    <option value="medium">Média</option>
                    <option value="low">Baixa</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Projeto
                  </label>
                  <select
                    value={filterProject}
                    onChange={(e) => setFilterProject(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  >
                    <option value="">Todos os projetos</option>
                    {projects.map(project => (
                      <option key={project.id} value={project.id}>
                        {project.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </Card>

            {/* Tasks List */}
            <div>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white mb-4">Suas Tarefas</h2>
              <div className="space-y-4">
                {filteredTasks.length === 0 ? (
                  <Card className="text-center py-12">
                    <CheckSquare className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                      {tasks.length === 0 ? 'Nenhuma tarefa ainda' : 'Nenhuma tarefa encontrada'}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {tasks.length === 0 
                        ? 'Adicione sua primeira tarefa para começar a se organizar!'
                        : 'Tente ajustar os filtros para encontrar suas tarefas.'
                      }
                    </p>
                  </Card>
                ) : (
                  filteredTasks.map(task => (
                    <TaskCard
                      key={task.id}
                      task={task}
                      projects={projects}
                      onToggle={toggleTask}
                      onDelete={handleDeleteTask}
                      onUpdateCost={updateTaskCost}
                      canDelete={true}
                    />
                  ))
                )}
              </div>
            </div>
          </div>

          {/* Right Column - Sidebar */}
          <div className="space-y-8">
            {/* Projects Section */}
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white flex items-center">
                  <Folder className="w-5 h-5 mr-2" />
                  Projetos
                </h3>
                <Button
                  onClick={() => setShowProjectModal(true)}
                  size="sm"
                >
                  <FolderPlus className="w-4 h-4 mr-2" />
                  Novo
                </Button>
              </div>
              
              {projects.length === 0 ? (
                <div className="text-center py-6">
                  <Folder className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-2" />
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    Nenhum projeto criado ainda
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  {projects.map(project => (
                    <div
                      key={project.id}
                      className="p-3 border border-gray-200 dark:border-gray-700 rounded-lg hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                          <div 
                            className="w-3 h-3 rounded-full mr-2" 
                            style={{ backgroundColor: project.color }}
                          />
                          <h4 className="font-medium text-gray-900 dark:text-white text-sm">{project.name}</h4>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setProjectToDelete(project)
                            setShowDeleteProjectModal(true)
                          }}
                          className="p-1 text-red-500 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
                          title="Excluir projeto"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                      {project.description && (
                        <p className="text-xs text-gray-600 dark:text-gray-400 mb-2">
                          {project.description}
                        </p>
                      )}
                      <div className="text-xs text-gray-500 dark:text-gray-500">
                        {tasks.filter(task => task.project_id === project.id).length} tarefas
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {!hasPremiumFeatures && (
                <div className="mt-4 text-xs text-gray-600 dark:text-gray-400">
                  {projects.length}/1 projeto disponível no plano gratuito
                </div>
              )}
            </Card>

            {/* Quick Notes Widget */}
            <Card>
              <QuickNotesWidget />
            </Card>

            {/* Pomodoro Timer - Only for premium users */}
            {hasPremiumFeatures && (
              <PomodoroTimer tasks={filteredTasks} />
            )}
          </div>
        </div>

        {/* Modals */}
        {/* Project Modal */}
        <Modal
          isOpen={showProjectModal}
          onClose={() => {
            setShowProjectModal(false)
            setNewProjectName('')
            setNewProjectDescription('')
            setNewProjectColor('#3b82f6')
          }}
          title="Criar Novo Projeto"
        >
          <form onSubmit={handleCreateProject} className="space-y-4">
            <Input
              label="Nome do Projeto"
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              placeholder="Ex: Trabalho, Estudos, Casa..."
              required
            />
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Descrição (Opcional)
              </label>
              <textarea
                value={newProjectDescription}
                onChange={(e) => setNewProjectDescription(e.target.value)}
                placeholder="Descreva o objetivo deste projeto..."
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                rows={3}
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Cor do Projeto
              </label>
              <div className="flex items-center space-x-2">
                <input
                  type="color"
                  value={newProjectColor}
                  onChange={(e) => setNewProjectColor(e.target.value)}
                  className="w-12 h-10 border border-gray-300 dark:border-gray-600 rounded cursor-pointer"
                />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  Escolha uma cor para identificar este projeto
                </span>
              </div>
            </div>
            
            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowProjectModal(false)
                  setNewProjectName('')
                  setNewProjectDescription('')
                  setNewProjectColor('#3b82f6')
                }}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button type="submit" className="flex-1">
                Criar Projeto
              </Button>
            </div>
          </form>
        </Modal>
        {/* Delete Project Modal */}
        <Modal
          isOpen={showDeleteProjectModal}
          onClose={() => {
            setShowDeleteProjectModal(false)
            setProjectToDelete(null)
          }}
          title="Excluir Projeto"
        >
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-8 h-8 text-red-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              Tem certeza?
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Você está prestes a excluir o projeto "{projectToDelete?.name}". 
              As tarefas associadas a este projeto não serão excluídas, mas perderão a associação com o projeto.
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => {
                  setShowDeleteProjectModal(false)
                  setProjectToDelete(null)
                }}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button
                variant="danger"
                onClick={handleDeleteProject}
                className="flex-1"
              >
                Excluir Projeto
              </Button>
            </div>
          </div>
        </Modal>

        {/* Project Limit Modal */}
        <Modal
          isOpen={showProjectLimitModal}
          onClose={() => setShowProjectLimitModal(false)}
          title="Limite de projetos atingido"
        >
          <div className="text-center">
            <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <Folder className="w-8 h-8 text-orange-600" />
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Você atingiu o limite de 1 projeto do plano gratuito. 
              Assine um plano premium para criar projetos ilimitados!
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowProjectLimitModal(false)}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Link to="/upgrade" className="flex-1">
                <Button className="w-full">
                  Ver Planos
                </Button>
              </Link>
            </div>
          </div>
        </Modal>

        {/* Limit Modal */}
        <Modal
          isOpen={showLimitModal}
          onClose={() => setShowLimitModal(false)}
          title="Limite de tarefas atingido"
        >
          <div className="text-center">
            <div className="w-16 h-16 bg-orange-100 dark:bg-orange-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckSquare className="w-8 h-8 text-orange-600" />
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Você atingiu o limite de 5 tarefas do plano gratuito. 
              Assine o Plano Essencial para ter tarefas ilimitadas e recursos avançados!
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowLimitModal(false)}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Link to="/upgrade" className="flex-1">
                <Button className="w-full">
                  Ver Planos
                </Button>
              </Link>
            </div>
          </div>
        </Modal>

        {/* Rate Limit Modal */}
        <Modal
          isOpen={showRateLimitModal}
          onClose={() => setShowRateLimitModal(false)}
          title="Limite de velocidade atingido"
        >
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-blue-600" />
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Você criou muitas tarefas rapidamente. Para evitar spam, aguarde {remainingTimeFormatted} 
              para criar mais tarefas.
            </p>
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              Limite: 30 tarefas a cada 3 minutos
            </div>
            <Button
              onClick={() => setShowRateLimitModal(false)}
              className="w-full"
            >
              Entendi
            </Button>
          </div>
        </Modal>
        
        {/* Invalid Task Modal */}
        <Modal
          isOpen={showInvalidTaskModal}
          onClose={() => setShowInvalidTaskModal(false)}
          title="Tarefa inválida"
        >
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-8 h-8 text-red-600" />
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              A tarefa deve conter palavras que façam sentido. Evite usar apenas 
              caracteres aleatórios ou texto sem significado.
            </p>
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              Exemplos válidos: "Treinar", "Estudar para prova", "Ler livros"
            </div>
            <Button
              onClick={() => setShowInvalidTaskModal(false)}
              className="w-full"
            >
              Entendi
            </Button>
          </div>
        </Modal>

        {/* Delete Limit Modal */}
        <Modal
          isOpen={showDeleteLimitModal}
          onClose={() => setShowDeleteLimitModal(false)}
          title="Limite de exclusões atingido"
        >
          <div className="text-center">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <Trash2 className="w-8 h-8 text-red-600" />
            </div>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Você atingiu o limite de 5 exclusões de tarefas por dia no plano gratuito. 
              Assine um plano premium para exclusões ilimitadas!
            </p>
            <div className="text-sm text-gray-500 dark:text-gray-400 mb-6">
              Exclusões hoje: {deletionsToday}/5
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowDeleteLimitModal(false)}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Link to="/upgrade" className="flex-1">
                <Button className="w-full">
                  Ver Planos
                </Button>
              </Link>
            </div>
          </div>
        </Modal>
      </div>
    </div>
  )
}