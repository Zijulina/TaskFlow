import React, { useEffect, useState } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { CheckCircle, ArrowRight, Crown } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Card } from '../components/ui/Card'

export function SuccessPage() {
  const [searchParams] = useSearchParams()
  const sessionId = searchParams.get('session_id')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate a brief loading period to allow webhook processing
    const timer = setTimeout(() => {
      setLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
        <Card className="max-w-md w-full text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-900 mb-2">
            Processando pagamento...
          </h2>
          <p className="text-gray-600">
            Aguarde enquanto confirmamos sua assinatura
          </p>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full">
        <Card className="text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          
          <h1 className="text-2xl font-bold text-gray-900 mb-4">
            Pagamento realizado com sucesso!
          </h1>
          
          <div className="mb-6">
            <div className="flex items-center justify-center mb-2">
              <Crown className="w-5 h-5 text-yellow-600 mr-2" />
              <span className="text-lg font-semibold text-gray-900">
                Plano Pro Anual
              </span>
            </div>
            <p className="text-gray-600">
              Sua assinatura foi ativada com sucesso. Agora você tem acesso a todos os recursos premium do TaskFlow!
            </p>
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <h3 className="font-semibold text-blue-900 mb-2">
              O que você desbloqueou:
            </h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>✓ Tarefas ilimitadas</li>
              <li>✓ Recursos avançados</li>
              <li>✓ Suporte prioritário</li>
              <li>✓ Relatórios detalhados</li>
              <li>✓ Exclusão de tarefas</li>
              <li>✓ Backup automático</li>
            </ul>
          </div>

          {sessionId && (
            <div className="text-xs text-gray-500 mb-6">
              ID da sessão: {sessionId}
            </div>
          )}

          <div className="space-y-3">
            <Link to="/dashboard">
              <Button className="w-full">
                Ir para o Dashboard
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
            
            <p className="text-xs text-gray-500">
              Você receberá um email de confirmação em breve
            </p>
          </div>
        </Card>
      </div>
    </div>
  )
}