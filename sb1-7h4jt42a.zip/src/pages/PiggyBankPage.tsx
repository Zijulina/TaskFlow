import React, { useState } from 'react'
import { PiggyBank, Plus, Target, TrendingUp, Calendar, DollarSign, PieChart, Edit3, Save, X, Trash2, CreditCard, Minus } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Input } from '../components/ui/Input'
import { Card } from '../components/ui/Card'
import { Modal } from '../components/ui/Modal'
import { useFinancialGoals } from '../hooks/useFinancialGoals'
import { useExpenses } from '../hooks/useExpenses'

const investmentTypes = [
  { id: 'renda_fixa', name: 'Renda Fixa', color: '#3b82f6' },
  { id: 'renda_variavel', name: 'Renda Variável', color: '#ef4444' },
  { id: 'criptomoedas', name: 'Criptomoedas', color: '#f59e0b' },
  { id: 'outros', name: 'Outros', color: '#8b5cf6' }
]

export function PiggyBankPage() {
  const { goals, investments, createGoal, updateGoal, deleteGoal, createInvestment, updateInvestment, deleteInvestment } = useFinancialGoals()
  const { expenses, createExpense, updateExpense, deleteExpense } = useExpenses()
  const [showGoalModal, setShowGoalModal] = useState(false)
  const [showInvestmentModal, setShowInvestmentModal] = useState(false)
  const [showExpenseModal, setShowExpenseModal] = useState(false)
  const [editingGoal, setEditingGoal] = useState<any>(null)
  const [editingInvestment, setEditingInvestment] = useState<any>(null)
  const [editingExpense, setEditingExpense] = useState<any>(null)

  // Goal form state
  const [goalTitle, setGoalTitle] = useState('')
  const [goalAmount, setGoalAmount] = useState('')
  const [goalCurrentAmount, setGoalCurrentAmount] = useState('')
  const [goalTargetDate, setGoalTargetDate] = useState('')

  // Investment form state
  const [investmentType, setInvestmentType] = useState('renda_fixa')
  const [investmentAmount, setInvestmentAmount] = useState('')

  // Expense form state
  const [expenseTitle, setExpenseTitle] = useState('')
  const [expenseAmount, setExpenseAmount] = useState('')
  const [expenseCategory, setExpenseCategory] = useState('casa')
  const [expenseDate, setExpenseDate] = useState(new Date().toISOString().split('T')[0])

  const totalInvestments = investments.reduce((sum, inv) => sum + inv.amount, 0)
  const totalExpenses = expenses.reduce((sum, exp) => sum + exp.amount, 0)
  const completedGoals = goals.filter(goal => goal.current_amount >= goal.target_amount).length
  const activeGoals = goals.filter(goal => goal.current_amount < goal.target_amount).length

  const handleCreateGoal = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const targetAmount = parseFloat(goalAmount)
    const currentAmount = parseFloat(goalCurrentAmount) || 0
    
    if (!goalTitle.trim() || isNaN(targetAmount) || targetAmount <= 0) return

    if (editingGoal) {
      await updateGoal(editingGoal.id, {
        title: goalTitle.trim(),
        target_amount: targetAmount,
        current_amount: currentAmount,
        target_date: goalTargetDate || null
      })
    } else {
      await createGoal(goalTitle.trim(), targetAmount, currentAmount, goalTargetDate || null)
    }

    resetGoalForm()
    setShowGoalModal(false)
  }

  const handleCreateInvestment = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const amount = parseFloat(investmentAmount)
    if (isNaN(amount) || amount <= 0) return

    if (editingInvestment) {
      await updateInvestment(editingInvestment.id, {
        investment_type: investmentType,
        amount
      })
    } else {
      await createInvestment(investmentType, amount)
    }

    resetInvestmentForm()
    setShowInvestmentModal(false)
  }

  const handleCreateExpense = async (e: React.FormEvent) => {
    e.preventDefault()
    
    const amount = parseFloat(expenseAmount)
    if (!expenseTitle.trim() || isNaN(amount) || amount <= 0) return

    if (editingExpense) {
      await updateExpense(editingExpense.id, {
        title: expenseTitle.trim(),
        amount,
        category: expenseCategory,
        expense_date: expenseDate
      })
    } else {
      await createExpense(expenseTitle.trim(), amount, expenseCategory, expenseDate)
    }

    resetExpenseForm()
    setShowExpenseModal(false)
  }

  const resetGoalForm = () => {
    setGoalTitle('')
    setGoalAmount('')
    setGoalCurrentAmount('')
    setGoalTargetDate('')
    setEditingGoal(null)
  }

  const resetInvestmentForm = () => {
    setInvestmentType('renda_fixa')
    setInvestmentAmount('')
    setEditingInvestment(null)
  }

  const resetExpenseForm = () => {
    setExpenseTitle('')
    setExpenseAmount('')
    setExpenseCategory('casa')
    setExpenseDate(new Date().toISOString().split('T')[0])
    setEditingExpense(null)
  }

  const handleEditGoal = (goal: any) => {
    setEditingGoal(goal)
    setGoalTitle(goal.title)
    setGoalAmount(goal.target_amount.toString())
    setGoalCurrentAmount(goal.current_amount.toString())
    setGoalTargetDate(goal.target_date ? goal.target_date.split('T')[0] : '')
    setShowGoalModal(true)
  }

  const handleEditInvestment = (investment: any) => {
    setEditingInvestment(investment)
    setInvestmentType(investment.investment_type)
    setInvestmentAmount(investment.amount.toString())
    setShowInvestmentModal(true)
  }

  const handleEditExpense = (expense: any) => {
    setEditingExpense(expense)
    setExpenseTitle(expense.title)
    setExpenseAmount(expense.amount.toString())
    setExpenseCategory(expense.category)
    setExpenseDate(expense.expense_date.split('T')[0])
    setShowExpenseModal(true)
  }

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value)
  }

  const getInvestmentTypeInfo = (type: string) => {
    return investmentTypes.find(t => t.id === type) || investmentTypes[0]
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg flex items-center justify-center mr-4">
                <PiggyBank className="w-6 h-6 text-yellow-600" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Cofrinho Financeiro</h1>
                <p className="text-gray-600 dark:text-gray-400">Gerencie suas metas financeiras e investimentos</p>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mr-4">
                  <Target className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Metas Ativas</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{activeGoals}</p>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mr-4">
                  <Target className="w-6 h-6 text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Metas Concluídas</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{completedGoals}</p>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center mr-4">
                  <TrendingUp className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Investido</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{formatCurrency(totalInvestments)}</p>
                </div>
              </div>
            </Card>

            <Card>
              <div className="flex items-center">
                <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-lg flex items-center justify-center mr-4">
                  <CreditCard className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Total Gastos</p>
                  <p className="text-2xl font-bold text-gray-900 dark:text-white">{formatCurrency(totalExpenses)}</p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Metas Financeiras */}
          <div>
            <div className="flex items-center justify-between mb-6 min-h-[2.5rem]">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white flex-1">Metas Financeiras</h2>
              <Button onClick={() => setShowGoalModal(true)} size="sm" className="ml-4 flex-shrink-0">
                <Plus className="w-4 h-4 mr-2" />
                Nova Meta
              </Button>
            </div>

            <div className="space-y-4">
              {goals.length === 0 ? (
                <Card className="text-center py-12">
                  <Target className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    Nenhuma meta ainda
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Crie sua primeira meta financeira para começar!
                  </p>
                </Card>
              ) : (
                goals.map(goal => {
                  const progress = (goal.current_amount / goal.target_amount) * 100
                  const isCompleted = progress >= 100
                  const isOverdue = goal.target_date && new Date(goal.target_date) < new Date() && !isCompleted

                  return (
                    <Card key={goal.id} className={`${isCompleted ? 'border-green-500 bg-green-50 dark:bg-green-900/20' : ''}`}>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{goal.title}</h3>
                        <div className="flex items-center space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditGoal(goal)}
                          >
                            <Edit3 className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteGoal(goal.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>

                      <div className="mb-4">
                        <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                          <span>{formatCurrency(goal.current_amount)} de {formatCurrency(goal.target_amount)}</span>
                          <span>{progress.toFixed(1)}%</span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-3">
                          <div 
                            className={`h-3 rounded-full transition-all duration-500 ${
                              isCompleted 
                                ? 'bg-gradient-to-r from-green-500 to-emerald-500' 
                                : isOverdue
                                ? 'bg-gradient-to-r from-red-500 to-red-600'
                                : 'bg-gradient-to-r from-blue-500 to-blue-600'
                            }`}
                            style={{ width: `${Math.min(progress, 100)}%` }}
                          />
                        </div>
                      </div>

                      {goal.target_date && (
                        <div className="flex items-center text-sm text-gray-600 dark:text-gray-400">
                          <Calendar className="w-4 h-4 mr-2" />
                          Meta para: {new Date(goal.target_date).toLocaleDateString('pt-BR')}
                          {isOverdue && (
                            <span className="ml-2 text-red-600 font-medium">(Atrasada)</span>
                          )}
                        </div>
                      )}

                      {isCompleted && (
                        <div className="mt-3 text-center">
                          <span className="text-green-600 dark:text-green-400 font-medium">
                            🎉 Meta alcançada! Parabéns!
                          </span>
                        </div>
                      )}
                    </Card>
                  )
                })
              )}
            </div>
          </div>

          {/* Investimentos */}
          <div>
            <div className="flex items-center justify-between mb-6 min-h-[2.5rem]">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white flex-1">Investimentos</h2>
              <Button onClick={() => setShowInvestmentModal(true)} size="sm" className="ml-4 flex-shrink-0">
                <Plus className="w-4 h-4 mr-2" />
                Novo Investimento
              </Button>
            </div>

            {/* Investment Chart */}
            {investments.length > 0 && (
              <Card className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Distribuição dos Investimentos</h3>
                <div className="space-y-3">
                  {investmentTypes.map(type => {
                    const typeInvestments = investments.filter(inv => inv.investment_type === type.id)
                    const typeTotal = typeInvestments.reduce((sum, inv) => sum + inv.amount, 0)
                    const percentage = totalInvestments > 0 ? (typeTotal / totalInvestments) * 100 : 0

                    if (typeTotal === 0) return null

                    return (
                      <div key={type.id}>
                        <div className="flex items-center justify-between text-sm mb-1">
                          <div className="flex items-center">
                            <div 
                              className="w-3 h-3 rounded-full mr-2" 
                              style={{ backgroundColor: type.color }}
                            />
                            <span className="text-gray-900 dark:text-white">{type.name}</span>
                          </div>
                          <span className="text-gray-600 dark:text-gray-400">
                            {formatCurrency(typeTotal)} ({percentage.toFixed(1)}%)
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full transition-all duration-500"
                            style={{ 
                              width: `${percentage}%`,
                              backgroundColor: type.color
                            }}
                          />
                        </div>
                      </div>
                    )
                  })}
                </div>
              </Card>
            )}

            {/* Investment List */}
            <div className="space-y-4">
              {investments.length === 0 ? (
                <Card className="text-center py-12">
                  <TrendingUp className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    Nenhum investimento ainda
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Adicione seus investimentos para acompanhar seu portfólio!
                  </p>
                </Card>
              ) : (
                investments.map(investment => {
                  const typeInfo = getInvestmentTypeInfo(investment.investment_type)
                  
                  return (
                    <Card key={investment.id}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center">
                          <div 
                            className="w-4 h-4 rounded-full mr-3" 
                            style={{ backgroundColor: typeInfo.color }}
                          />
                          <div>
                            <h4 className="font-medium text-gray-900 dark:text-white">{typeInfo.name}</h4>
                            <p className="text-sm text-gray-600 dark:text-gray-400">
                              Adicionado em {new Date(investment.created_at).toLocaleDateString('pt-BR')}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-lg font-semibold text-gray-900 dark:text-white">
                            {formatCurrency(investment.amount)}
                          </span>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditInvestment(investment)}
                          >
                            <Edit3 className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => deleteInvestment(investment.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </Card>
                  )
                })
              )}
            </div>
          </div>

          {/* Despesas */}
          <div>
            <div className="flex items-center justify-between mb-6 min-h-[2.5rem]">
              <h2 className="text-xl font-bold text-gray-900 dark:text-white flex-1">Despesas</h2>
              <Button onClick={() => setShowExpenseModal(true)} size="sm" className="ml-4 flex-shrink-0">
                <Plus className="w-4 h-4 mr-2" />
                Nova Despesa
              </Button>
            </div>

            <div className="space-y-4">
              {expenses.length === 0 ? (
                <Card className="text-center py-12">
                  <CreditCard className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                    Nenhuma despesa ainda
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400">
                    Adicione suas despesas para controlar seus gastos!
                  </p>
                </Card>
              ) : (
                expenses.map(expense => (
                  <Card key={expense.id}>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-4 h-4 bg-red-500 rounded-full mr-3" />
                        <div>
                          <h4 className="font-medium text-gray-900 dark:text-white">{expense.title}</h4>
                          <p className="text-sm text-gray-600 dark:text-gray-400">
                            {expense.category} • {new Date(expense.expense_date).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-lg font-semibold text-red-600 dark:text-red-400">
                          -{formatCurrency(expense.amount)}
                        </span>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditExpense(expense)}
                        >
                          <Edit3 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteExpense(expense.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Goal Modal */}
        <Modal
          isOpen={showGoalModal}
          onClose={() => {
            setShowGoalModal(false)
            resetGoalForm()
          }}
          title={editingGoal ? 'Editar Meta' : 'Nova Meta Financeira'}
        >
          <form onSubmit={handleCreateGoal} className="space-y-4">
            <Input
              label="Título da Meta"
              value={goalTitle}
              onChange={(e) => setGoalTitle(e.target.value)}
              placeholder="Ex: Guardar para viagem"
              required
            />

            <Input
              label="Valor da Meta (R$)"
              type="number"
              value={goalAmount}
              onChange={(e) => setGoalAmount(e.target.value)}
              placeholder="0.00"
              min="0"
              step="0.01"
              required
            />

            <Input
              label="Valor Atual (R$)"
              type="number"
              value={goalCurrentAmount}
              onChange={(e) => setGoalCurrentAmount(e.target.value)}
              placeholder="0.00"
              min="0"
              step="0.01"
            />

            <Input
              label="Data Meta (Opcional)"
              type="date"
              value={goalTargetDate}
              onChange={(e) => setGoalTargetDate(e.target.value)}
            />

            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowGoalModal(false)
                  resetGoalForm()
                }}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button type="submit" className="flex-1">
                {editingGoal ? 'Atualizar' : 'Criar Meta'}
              </Button>
            </div>
          </form>
        </Modal>

        {/* Investment Modal */}
        <Modal
          isOpen={showInvestmentModal}
          onClose={() => {
            setShowInvestmentModal(false)
            resetInvestmentForm()
          }}
          title={editingInvestment ? 'Editar Investimento' : 'Novo Investimento'}
        >
          <form onSubmit={handleCreateInvestment} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Tipo de Investimento
              </label>
              <select
                value={investmentType}
                onChange={(e) => setInvestmentType(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                required
              >
                {investmentTypes.map(type => (
                  <option key={type.id} value={type.id}>
                    {type.name}
                  </option>
                ))}
              </select>
            </div>

            <Input
              label="Valor Investido (R$)"
              type="number"
              value={investmentAmount}
              onChange={(e) => setInvestmentAmount(e.target.value)}
              placeholder="0.00"
              min="0"
              step="0.01"
              required
            />

            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowInvestmentModal(false)
                  resetInvestmentForm()
                }}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button type="submit" className="flex-1">
                {editingInvestment ? 'Atualizar' : 'Adicionar Investimento'}
              </Button>
            </div>
          </form>
        </Modal>

        {/* Expense Modal */}
        <Modal
          isOpen={showExpenseModal}
          onClose={() => {
            setShowExpenseModal(false)
            resetExpenseForm()
          }}
          title={editingExpense ? 'Editar Despesa' : 'Nova Despesa'}
        >
          <form onSubmit={handleCreateExpense} className="space-y-4">
            <Input
              label="Título da Despesa"
              value={expenseTitle}
              onChange={(e) => setExpenseTitle(e.target.value)}
              placeholder="Ex: Conta de luz"
              required
            />

            <Input
              label="Valor (R$)"
              type="number"
              value={expenseAmount}
              onChange={(e) => setExpenseAmount(e.target.value)}
              placeholder="0.00"
              min="0"
              step="0.01"
              required
            />

            <div>
              <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                Categoria
              </label>
              <select
                value={expenseCategory}
                onChange={(e) => setExpenseCategory(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                required
              >
                <option value="casa">Casa</option>
                <option value="alimentacao">Alimentação</option>
                <option value="transporte">Transporte</option>
                <option value="saude">Saúde</option>
                <option value="educacao">Educação</option>
                <option value="lazer">Lazer</option>
                <option value="outros">Outros</option>
              </select>
            </div>

            <Input
              label="Data da Despesa"
              type="date"
              value={expenseDate}
              onChange={(e) => setExpenseDate(e.target.value)}
              required
            />

            <div className="flex gap-3">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setShowExpenseModal(false)
                  resetExpenseForm()
                }}
                className="flex-1"
              >
                Cancelar
              </Button>
              <Button type="submit" className="flex-1">
                {editingExpense ? 'Atualizar' : 'Adicionar Despesa'}
              </Button>
            </div>
          </form>
        </Modal>
      </div>
    </div>
  )
}