import React, { useState } from 'react'
import { User, Mail, Lock, ArrowLeft, Eye, EyeOff, Trash2 } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Input } from '../components/ui/Input'
import { Card } from '../components/ui/Card'
import { DeleteAccountModal } from '../components/DeleteAccountModal'
import { LGPDPrivacyNotice } from '../components/LGPDPrivacyNotice'
import { useAuth } from '../hooks/useAuth'
import { useUserProfile } from '../hooks/useUserProfile'
import { useTheme } from '../contexts/ThemeContext'
import { validateName, formatNameForSave } from '../utils/nameValidation'
import { supabase } from '../lib/supabase'
import { Link, useNavigate } from 'react-router-dom'

export function AccountSettingsPage() {
  const { user, signOut } = useAuth()
  const { profile, updateProfile } = useUserProfile()
  const { saveThemeToStorage } = useTheme()
  const navigate = useNavigate()
  
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [showCurrentPassword, setShowCurrentPassword] = useState(false)
  const [showNewPassword, setShowNewPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState('')
  const [error, setError] = useState('')

  // Update form fields when profile/user data loads
  React.useEffect(() => {
    if (profile?.name) {
      setName(profile.name)
    }
    if (user?.email) {
      setEmail(user.email)
    }
  }, [profile, user])

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess('')

    const validation = validateName(name)
    if (!validation.isValid) {
      setError(validation.error!)
      setLoading(false)
      return
    }

    const formattedName = formatNameForSave(name)
    const { error: updateError } = await updateProfile({ name: formattedName })
    
    if (updateError) {
      setError('Erro ao atualizar perfil: ' + (typeof updateError === 'string' ? updateError : updateError.message || 'Erro desconhecido'))
    } else {
      setName(formattedName) // Update local state immediately
      setSuccess('Perfil atualizado com sucesso!')
      // Clear success message after 3 seconds
      setTimeout(() => setSuccess(''), 3000)
    }
    
    setLoading(false)
  }

  const handleUpdateEmail = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess('')

    if (!email.trim()) {
      setError('O email é obrigatório')
      setLoading(false)
      return
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      setError('Por favor, insira um email válido')
      setLoading(false)
      return
    }

    const { error: updateError } = await supabase.auth.updateUser({
      email: email.trim()
    })
    
    if (updateError) {
      setError('Erro ao atualizar email: ' + (updateError.message || 'Erro desconhecido'))
    } else {
      setSuccess('Email atualizado! Verifique sua caixa de entrada para confirmar.')
    }
    
    setLoading(false)
  }

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess('')

    if (!currentPassword || !newPassword || !confirmPassword) {
      setError('Preencha todos os campos de senha')
      setLoading(false)
      return
    }

    if (newPassword.length < 6) {
      setError('A nova senha deve ter pelo menos 6 caracteres')
      setLoading(false)
      return
    }

    if (newPassword !== confirmPassword) {
      setError('A confirmação da senha não confere')
      setLoading(false)
      return
    }

    // Verify current password by trying to sign in
    const { error: verifyError } = await supabase.auth.signInWithPassword({
      email: user?.email!,
      password: currentPassword
    })

    if (verifyError) {
      setError('Senha atual incorreta')
      setLoading(false)
      return
    }

    const { error: updateError } = await supabase.auth.updateUser({
      password: newPassword
    })
    
    if (updateError) {
      setError('Erro ao atualizar senha: ' + (updateError.message || 'Erro desconhecido'))
    } else {
      setSuccess('Senha atualizada com sucesso!')
      setCurrentPassword('')
      setNewPassword('')
      setConfirmPassword('')
    }
    
    setLoading(false)
  }

  const handleSignOut = async () => {
    try {
      const { error } = await signOut(saveThemeToStorage)
      if (error) {
        console.error('Logout error:', error)
        setError('Erro ao sair da conta: ' + error.message)
      } else {
        // Clear any local storage
        const savedTheme = localStorage.getItem('taskflow-theme')
        localStorage.clear()
        sessionStorage.clear()
        
        // Restore theme
        if (savedTheme) {
          localStorage.setItem('taskflow-theme', savedTheme)
        }
        
        // Force navigation to home
        window.location.href = '/'
      }
    } catch (err) {
      console.error('Unexpected logout error:', err)
      setError('Erro inesperado ao sair da conta')
    }
  }

  const handleAccountDeleted = () => {
    // Redirecionar para página de sucesso da exclusão
    navigate('/account-deleted')
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-black">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center">
              <Link to="/dashboard">
                <Button variant="ghost" size="sm" className="mr-4">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Voltar
                </Button>
              </Link>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Configurações da Conta</h1>
            </div>
          </div>
        </div>

        {/* Success/Error Messages */}
        {success && (
          <div className="mb-6 bg-green-50 dark:bg-green-900/30 border border-green-200 dark:border-green-800 text-green-700 dark:text-green-300 px-4 py-3 rounded-lg">
            {success}
          </div>
        )}

        {error && (
          <div className="mb-6 bg-red-50 dark:bg-red-900/30 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 px-4 py-3 rounded-lg">
            {error}
          </div>
        )}

        <div className="space-y-8">
          {/* Profile Settings */}
          <Card>
            <div className="flex items-center mb-6">
              <User className="w-5 h-5 text-blue-600 mr-2" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Informações do Perfil</h2>
            </div>
            
            <form onSubmit={handleUpdateProfile} className="space-y-4">
              <Input
                label="Nome completo"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Seu nome completo"
                maxLength={30}
                required
              />
              <div className="text-xs text-gray-500 dark:text-gray-400">
                {name.length}/30 caracteres • Apenas letras e espaços
              </div>
              
              <Button type="submit" disabled={loading}>
                {loading ? 'Salvando...' : 'Salvar Nome'}
              </Button>
            </form>
          </Card>

          {/* Email Settings */}
          <Card>
            <div className="flex items-center mb-6">
              <Mail className="w-5 h-5 text-blue-600 mr-2" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Email</h2>
            </div>
            
            <form onSubmit={handleUpdateEmail} className="space-y-4">
              <Input
                label="Email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                required
              />
              
              <Button type="submit" disabled={loading}>
                {loading ? 'Salvando...' : 'Atualizar Email'}
              </Button>
            </form>
          </Card>

          {/* Password Settings */}
          <Card>
            <div className="flex items-center mb-6">
              <Lock className="w-5 h-5 text-blue-600 mr-2" />
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">Alterar Senha</h2>
            </div>
            
            <form onSubmit={handleUpdatePassword} className="space-y-4">
              <div className="relative">
                <Input
                  label="Senha atual"
                  type={showCurrentPassword ? 'text' : 'password'}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="••••••••"
                  className="pr-10"
                  required
                />
                <button
                  type="button"
                  className="absolute right-3 top-9 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                >
                  {showCurrentPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              <div className="relative">
                <Input
                  label="Nova senha"
                  type={showNewPassword ? 'text' : 'password'}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="pr-10"
                  required
                />
                <button
                  type="button"
                  className="absolute right-3 top-9 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                >
                  {showNewPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>

              <div className="relative">
                <Input
                  label="Confirmar nova senha"
                  type={showConfirmPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="pr-10"
                  required
                />
                <button
                  type="button"
                  className="absolute right-3 top-9 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                >
                  {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              
              <Button type="submit" disabled={loading}>
                {loading ? 'Salvando...' : 'Alterar Senha'}
              </Button>
            </form>
          </Card>

          {/* LGPD Privacy Notice */}
          <LGPDPrivacyNotice />

          {/* Danger Zone */}
          <Card className="border-red-200 dark:border-red-800">
            <div className="flex items-center mb-6">
              <Trash2 className="w-5 h-5 text-red-600 dark:text-red-400 mr-2" />
              <h2 className="text-xl font-semibold text-red-600 dark:text-red-400">Zona de Perigo</h2>
            </div>
            
            <div className="space-y-4">
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
                <h3 className="font-semibold text-red-800 dark:text-red-300 mb-2">
                  Excluir conta permanentemente
                </h3>
                <p className="text-sm text-red-700 dark:text-red-300 mb-4">
                  Esta ação irá remover permanentemente sua conta e todos os dados associados. 
                  Esta operação não pode ser desfeita e está em conformidade com a LGPD.
                </p>
                <Button 
                  variant="danger" 
                  onClick={() => setShowDeleteModal(true)}
                  className="w-full sm:w-auto"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Excluir minha conta
                </Button>
              </div>
              
              <div className="border-t border-red-200 dark:border-red-800 pt-4">
                <h3 className="font-semibold text-gray-800 dark:text-gray-300 mb-2">
                  Sair da conta
                </h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Sair da conta irá desconectá-lo do sistema.
              </p>
              
              <Button 
                variant="outline" 
                onClick={handleSignOut}
                className="w-full sm:w-auto mt-2"
              >
                Sair da Conta
              </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Delete Account Modal */}
        <DeleteAccountModal
          isOpen={showDeleteModal}
          onClose={() => setShowDeleteModal(false)}
          onSuccess={handleAccountDeleted}
        />
      </div>
    </div>
  )
}