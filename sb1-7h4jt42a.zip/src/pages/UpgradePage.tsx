import React, { useState } from 'react'
import { Check, Crown, Zap, CreditCard, Calendar, Star } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Card } from '../components/ui/Card'
import { Modal } from '../components/ui/Modal'
import { useSubscription } from '../hooks/useSubscription'
import { useStripe } from '../hooks/useStripe'
import { stripeProducts } from '../stripe-config'
import { useNavigate } from 'react-router-dom'

export function UpgradePage() {
  const { subscription, isPro, isEssential, hasPremiumFeatures, loading: subscriptionLoading } = useSubscription()
  const { createCheckoutSession, loading: checkoutLoading, error } = useStripe()
  const [billingInterval, setBillingInterval] = useState<'monthly' | 'yearly'>('yearly')
  const navigate = useNavigate()

  const essentialProduct = stripeProducts[0] // Plano Essencial
  const proProduct = stripeProducts[1] // Plano Pro Anual

  const handleUpgrade = async (priceId: string, mode: 'payment' | 'subscription') => {
    await createCheckoutSession(priceId, mode)
  }

  if (subscriptionLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando informações da assinatura...</p>
        </div>
      </div>
    )
  }

  if (hasPremiumFeatures) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
        <Card className="max-w-md w-full text-center">
          <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
            {isPro ? <Crown className="w-8 h-8 text-yellow-600" /> : <Star className="w-8 h-8 text-blue-600" />}
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            {isPro ? 'Você já é Pro!' : 'Você tem o Plano Essencial!'}
          </h2>
          <p className="text-gray-600 mb-6">
            {isPro 
              ? 'Sua assinatura está ativa e você tem acesso a todos os recursos premium.'
              : 'Sua assinatura está ativa. Considere fazer upgrade para o Pro e ter ainda mais recursos!'
            }
          </p>
          {subscription?.current_period_end && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <p className="text-sm text-blue-800">
                Próxima renovação: {new Date(subscription.current_period_end * 1000).toLocaleDateString('pt-BR')}
              </p>
            </div>
          )}
          <div className="space-y-3">
            <Button onClick={() => navigate('/dashboard')} className="w-full">
              Voltar ao Dashboard
            </Button>
            {isEssential && (
              <Button 
                variant="outline" 
                onClick={() => handleUpgrade(proProduct.priceId, proProduct.mode)}
                disabled={checkoutLoading}
                className="w-full"
              >
                <Crown className="w-4 h-4 mr-2" />
                {checkoutLoading ? 'Redirecionando...' : 'Upgrade para Pro'}
              </Button>
            )}
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Escolha seu plano
          </h1>
          <p className="text-xl text-gray-600">
            Desbloqueie recursos avançados e aumente sua produtividade
          </p>
          
          {/* Billing Toggle */}
          <div className="flex items-center justify-center mt-8 mb-8">
            <div className="bg-white rounded-lg p-1 shadow-sm border border-gray-200">
              <button
                onClick={() => setBillingInterval('monthly')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  billingInterval === 'monthly'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Mensal
              </button>
              <button
                onClick={() => setBillingInterval('yearly')}
                className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                  billingInterval === 'yearly'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                Anual
                <span className="ml-1 text-xs bg-green-100 text-green-800 px-1.5 py-0.5 rounded-full">
                  Economize
                </span>
              </button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {/* Current Plan */}
          <Card>
            <div className="text-center mb-6">
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Gratuito</h3>
              <div className="text-4xl font-bold text-gray-900 mb-1">R$ 0</div>
              <p className="text-gray-600">Plano atual</p>
            </div>
            
            <ul className="space-y-3">
              <li className="flex items-center">
                <Check className="w-5 h-5 text-green-500 mr-3" />
                <span>Até 5 tarefas</span>
              </li>
              <li className="flex items-center">
                <Check className="w-5 h-5 text-green-500 mr-3" />
                <span>Interface básica</span>
              </li>
              <li className="flex items-center">
                <Check className="w-5 h-5 text-green-500 mr-3" />
                <span>Recursos limitados</span>
              </li>
              <li className="flex items-center text-gray-400">
                <span className="w-5 h-5 mr-3">✗</span>
                <span>Sem subtarefas</span>
              </li>
              <li className="flex items-center text-gray-400">
                <span className="w-5 h-5 mr-3">✗</span>
                <span>Sem etiquetas</span>
              </li>
            </ul>
          </Card>

          {/* Essential Plan */}
          {billingInterval === 'monthly' && (
            <Card className="border-2 border-blue-600 relative">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                  Mais Popular
                </span>
              </div>
              
              <div className="text-center mb-6">
                <div className="flex items-center justify-center mb-2">
                  <Star className="w-6 h-6 text-blue-600 mr-2" />
                  <h3 className="text-2xl font-bold text-gray-900">{essentialProduct.name}</h3>
                </div>
                <div className="text-4xl font-bold text-gray-900 mb-1">{essentialProduct.price}</div>
                <p className="text-gray-600">{essentialProduct.description}</p>
              </div>
              
              <ul className="space-y-3 mb-8">
                {essentialProduct.features.map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span className={index === 0 ? 'font-medium' : ''}>{feature}</span>
                  </li>
                ))}
              </ul>

              {error && (
                <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                  {error}
                </div>
              )}
              
              <Button 
                onClick={() => handleUpgrade(essentialProduct.priceId, essentialProduct.mode)}
                disabled={checkoutLoading}
                className="w-full"
              >
                <CreditCard className="w-4 h-4 mr-2" />
                {checkoutLoading ? 'Redirecionando...' : 'Assinar Essencial'}
              </Button>
            </Card>
          )}

          {/* Pro Plan */}
          <Card className={`relative ${billingInterval === 'yearly' ? 'border-2 border-yellow-600' : 'border border-gray-200'}`}>
            {billingInterval === 'yearly' && (
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-yellow-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                  Melhor Valor
                </span>
              </div>
            )}
            
            <div className="text-center mb-6">
              <div className="flex items-center justify-center mb-2">
                <Crown className="w-6 h-6 text-yellow-600 mr-2" />
                <h3 className="text-2xl font-bold text-gray-900">Pro</h3>
              </div>
              <div className="text-4xl font-bold text-gray-900 mb-1">
                {billingInterval === 'yearly' ? 'R$ 19,00/ano' : 'R$ 4,90/mês'}
              </div>
              <p className="text-gray-600">
                {billingInterval === 'yearly' 
                  ? 'Todas as funcionalidades + recursos avançados'
                  : 'Funcionalidades completas (em breve)'
                }
              </p>
              {billingInterval === 'yearly' && (
                <div className="mt-2 text-sm text-green-600 font-medium">
                  Economize R$ 39,80 por ano!
                </div>
              )}
            </div>
            
            <ul className="space-y-3 mb-8">
              <li className="flex items-center">
                <Check className="w-5 h-5 text-green-500 mr-3" />
                <span className="font-medium">Todas as funcionalidades do Essencial</span>
              </li>
              {proProduct.features.slice(1).map((feature, index) => (
                <li key={index} className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>{feature}</span>
                </li>
              ))}
            </ul>

            {error && (
              <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm">
                {error}
              </div>
            )}
            
            {billingInterval === 'yearly' ? (
              <Button 
                onClick={() => handleUpgrade(proProduct.priceId, proProduct.mode)}
                disabled={checkoutLoading}
                className="w-full bg-yellow-600 hover:bg-yellow-700"
              >
                <Crown className="w-4 h-4 mr-2" />
                {checkoutLoading ? 'Redirecionando...' : 'Assinar Pro Anual'}
              </Button>
            ) : (
              <Button 
                disabled
                variant="outline"
                className="w-full"
              >
                <Calendar className="w-4 h-4 mr-2" />
                Em breve
              </Button>
            )}
          </Card>
        </div>

        {/* Features Comparison */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Compare os planos
          </h2>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4">Funcionalidades</th>
                  <th className="text-center py-3 px-4">Gratuito</th>
                  <th className="text-center py-3 px-4">Essencial</th>
                  <th className="text-center py-3 px-4">Pro</th>
                </tr>
              </thead>
              <tbody className="text-sm">
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Número de tarefas</td>
                  <td className="text-center py-3 px-4">Até 5</td>
                  <td className="text-center py-3 px-4 text-green-600">Ilimitadas</td>
                  <td className="text-center py-3 px-4 text-green-600">Ilimitadas</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Anotações rápidas</td>
                  <td className="text-center py-3 px-4">Até 10</td>
                  <td className="text-center py-3 px-4 text-green-600">Ilimitadas</td>
                  <td className="text-center py-3 px-4 text-green-600">Ilimitadas</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Subtarefas e checklists</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Timer Pomodoro</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Organização por etiquetas</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Lembretes inteligentes</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Filtros personalizados</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Modo de foco</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Templates de tarefas</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Histórico de tarefas</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4">30 dias</td>
                  <td className="text-center py-3 px-4 text-green-600">Completo</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Agrupamento avançado</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Estatísticas de produtividade</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Planejamento semanal</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr className="border-b border-gray-100">
                  <td className="py-3 px-4">Insights de produtividade</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4">✗</td>
                  <td className="text-center py-3 px-4 text-green-600">✓</td>
                </tr>
                <tr>
                  <td className="py-3 px-4">Suporte</td>
                  <td className="text-center py-3 px-4">Básico</td>
                  <td className="text-center py-3 px-4">Email</td>
                  <td className="text-center py-3 px-4">Prioritário</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Benefits Section */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">
            Por que escolher um plano premium?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Produtividade Máxima
              </h3>
              <p className="text-gray-600 text-sm">
                Sem limites para suas tarefas e projetos
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Star className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Organização Avançada
              </h3>
              <p className="text-gray-600 text-sm">
                Etiquetas, projetos e filtros personalizados
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Crown className="w-6 h-6 text-yellow-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">
                Insights Inteligentes
              </h3>
              <p className="text-gray-600 text-sm">
                Estatísticas e planejamento semanal (Pro)
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}