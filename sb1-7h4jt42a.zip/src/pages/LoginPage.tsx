import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { CheckSquare, Mail, Lock, Eye, EyeOff } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Input } from '../components/ui/Input'
import { Card } from '../components/ui/Card'
import { useAuth } from '../hooks/useAuth'

export function LoginPage() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  
  const { signIn } = useAuth()
  const navigate = useNavigate()

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')

    if (!email || !password) {
      setError('Por favor, preencha todos os campos')
      setLoading(false)
      return
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      setError('Por favor, insira um email válido')
      setLoading(false)
      return
    }

    // Check for common email typos
    if (email.includes('?') || email.includes(' ') || !email.includes('@')) {
      setError(`❌ Email inválido detectado

🔍 Problema encontrado:
• O email "${email}" contém caracteres inválidos
• Verifique se não há espaços, "?" ou outros caracteres especiais
• Certifique-se de usar "@" no lugar correto

✅ Exemplo correto:
• usuario@dominio.com
• nome.sobrenome@empresa.com.br

📧 Verifique se digitou corretamente: ${email.replace('?', '@')}`)
      setLoading(false)
      return
    }

    const { error } = await signIn(email, password)
    
    if (error) {
      if (error.message.includes('Invalid login credentials') || error.code === 'invalid_credentials') {
        setError('Email ou senha incorretos. Verifique suas credenciais ou crie uma nova conta.')
      } else if (error.message.includes('NetworkError') || error.message.includes('Failed to fetch')) {
        setError('Erro de conexão. Verifique sua internet e tente novamente.')
      } else if (error.message.includes('Email not confirmed')) {
        setError('Email não confirmado. Verifique sua caixa de entrada e clique no link de confirmação.')
      } else {
        setError('Erro no login. Tente novamente.')
      }
    } else {
      navigate('/dashboard')
    }
    
    setLoading(false)
  }

  const handleQuickSignup = () => {
    navigate('/signup', { state: { email } })
  }

  const isInvalidCredentialsError = error.includes('Credenciais não encontradas') || error.includes('Email ou senha incorretos')

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <CheckSquare className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h2 className="text-3xl font-bold text-gray-900">
            Entre na sua conta
          </h2>
          <p className="mt-2 text-gray-600">
            Ou{' '}
            <Link to="/signup" className="text-blue-600 hover:text-blue-500">
              crie uma conta gratuita
            </Link>
          </p>
        </div>

        <Card>
          <form onSubmit={handleSubmit} className="space-y-6">
            {error && (
              <div className="bg-red-50 dark:bg-gray-800 border border-red-200 dark:border-gray-700 text-red-700 dark:text-red-300 px-4 py-3 rounded-lg">
                <div className="text-sm">{error}</div>
                {isInvalidCredentialsError && (
                  <div className="mt-3 pt-3 border-t border-red-200 dark:border-gray-600">
                    <Button
                      type="button"
                      onClick={handleQuickSignup}
                      className="w-full"
                    >
                      Criar conta com este email
                    </Button>
                  </div>
                )}
              </div>
            )}
            
            <div className="relative">
              <Mail className="absolute left-3 top-9 w-5 h-5 text-gray-400" />
              <Input
                label="Email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10"
                placeholder="seu@email.com"
                required
              />
            </div>

            <div className="relative">
              <Lock className="absolute left-3 top-9 w-5 h-5 text-gray-400" />
              <Input
                label="Senha"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 pr-10"
                placeholder="••••••••"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-9 w-5 h-5 text-gray-400 hover:text-gray-600 focus:outline-none"
              >
                {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
              </button>
            </div>

            <div className="text-right">
              <Link 
                to="/forgot-password" 
                className="text-sm text-blue-600 hover:text-blue-500"
              >
                Esqueceu a senha?
              </Link>
            </div>

            <Button 
              type="submit" 
              className="w-full" 
              disabled={loading}
            >
              {loading ? 'Entrando...' : 'Entrar'}
            </Button>
          </form>
        </Card>
        
        {/* Success message for password reset */}
        {new URLSearchParams(window.location.search).get('message') === 'password-reset-success' && (
          <div className="mt-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg text-center">
            Senha redefinida com sucesso! Faça login com sua nova senha.
          </div>
        )}
      </div>
    </div>
  )
}