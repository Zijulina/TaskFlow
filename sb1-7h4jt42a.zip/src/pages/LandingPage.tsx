import React from 'react'
import { CheckSquare, Zap, Shield, Users, Check, ArrowRight } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Card } from '../components/ui/Card'
import { Link } from 'react-router-dom'

export function LandingPage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-black py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="flex justify-center mb-8">
              <CheckSquare className="w-16 h-16 text-blue-600" />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Organize suas tarefas com
              <span className="text-blue-600 dark:text-blue-400 block">TaskFlow</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-8 max-w-3xl mx-auto">
              A solução completa para gerenciar suas tarefas de forma eficiente. 
              Aumente sua produtividade e nunca mais perca um prazo importante.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/signup">
                <Button size="lg" className="w-full sm:w-auto">
                  Começar Gratuitamente
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
              <Link to="/login">
                <Button variant="outline" size="lg" className="w-full sm:w-auto">
                  Fazer Login
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white dark:bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Por que escolher o TaskFlow?
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Desenvolvido para pessoas que valorizam organização e produtividade
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Zap className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Rápido e Simples
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                Interface intuitiva que permite adicionar e gerenciar tarefas em segundos
              </p>
            </Card>
            
            <Card className="text-center">
              <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Seguro e Confiável
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                Seus dados ficam seguros em nossa infraestrutura protegida
              </p>
            </Card>
            
            <Card className="text-center">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                Para Todos
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                Desde uso pessoal até equipes profissionais
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="bg-gray-50 dark:bg-gray-900 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 dark:text-white mb-4">
              Planos simples e transparentes
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
              Comece gratuitamente e evolua conforme suas necessidades
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            {/* Free Plan */}
            <Card className="relative">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Gratuito</h3>
                <div className="text-4xl font-bold text-gray-900 dark:text-white mb-1">R$ 0</div>
                <p className="text-gray-600 dark:text-gray-300">Para sempre</p>
              </div>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Até 5 tarefas</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Interface simples</span>
                </li>
                <li className="flex items-center">
                  <span className="w-5 h-5 mr-3 text-gray-400">✗</span>
                  <span className="text-gray-500 dark:text-gray-400">Recursos limitados</span>
                </li>
              </ul>
              
              <Link to="/signup" className="block">
                <Button variant="outline" className="w-full">
                  Começar Gratuitamente
                </Button>
              </Link>
            </Card>
            
            {/* Essential Plan */}
            <Card className="relative border-2 border-blue-600">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                  Mais Popular
                </span>
              </div>
              
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Plano Essencial</h3>
                <div className="text-4xl font-bold text-gray-900 dark:text-white mb-1">R$ 2,90</div>
                <p className="text-gray-600 dark:text-gray-300">por mês</p>
              </div>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Tarefas ilimitadas</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Subtarefas e checklists</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Organização por etiquetas</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Lembretes inteligentes</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Filtros personalizados</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Modo de foco</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Histórico de 30 dias</span>
                </li>
              </ul>
              
              <Link to="/signup" className="block">
                <Button className="w-full">
                  Começar com Essencial
                </Button>
              </Link>
            </Card>
            
            {/* Pro Plan */}
            <Card className="relative border-2 border-yellow-600">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-yellow-600 text-white px-4 py-1 rounded-full text-sm font-medium">
                  Melhor Valor
                </span>
              </div>
              
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">Pro Anual</h3>
                <div className="text-4xl font-bold text-gray-900 dark:text-white mb-1">R$ 19</div>
                <p className="text-gray-600 dark:text-gray-300">por ano</p>
                <div className="text-sm text-green-600 font-medium mt-1">
                  Economize R$ 15,80 por ano!
                </div>
              </div>
              
              <ul className="space-y-3 mb-8">
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Tudo do Essencial</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Histórico completo</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Agrupamento avançado</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Estatísticas avançadas</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Planejamento semanal</span>
                </li>
                <li className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3" />
                  <span>Suporte prioritário</span>
                </li>
              </ul>
              
              <Link to="/signup" className="block">
                <Button className="w-full bg-yellow-600 hover:bg-yellow-700">
                  Começar com Pro
                </Button>
              </Link>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 dark:bg-blue-800 py-16">
        <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Pronto para ser mais produtivo?
          </h2>
          <p className="text-xl text-blue-100 dark:text-blue-200 mb-8">
            Junte-se a milhares de usuários que já organizam suas tarefas com o TaskFlow
          </p>
          <Link to="/signup">
            <Button size="lg" variant="secondary">
              Começar Agora - É Gratuito
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}