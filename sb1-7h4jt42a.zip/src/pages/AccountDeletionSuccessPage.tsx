import React, { useState } from 'react'
import { CheckCircle, Heart, ArrowRight, MessageSquare } from 'lucide-react'
import { Button } from '../components/ui/Button'
import { Card } from '../components/ui/Card'
import { Link } from 'react-router-dom'

export function AccountDeletionSuccessPage() {
  const [showFeedback, setShowFeedback] = useState(false)
  const [feedback, setFeedback] = useState('')
  const [feedbackReason, setFeedbackReason] = useState('')
  const [feedbackSubmitted, setFeedbackSubmitted] = useState(false)

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Simular envio de feedback (pode ser implementado com uma API externa)
    console.log('Feedback de saída:', { reason: feedbackReason, message: feedback })
    
    setFeedbackSubmitted(true)
    
    // Limpar formulário após 2 segundos
    setTimeout(() => {
      setFeedback('')
      setFeedbackReason('')
      setShowFeedback(false)
    }, 2000)
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-black flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full">
        <Card className="text-center">
          <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
            <CheckCircle className="w-8 h-8 text-green-600" />
          </div>
          
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
            Conta excluída com sucesso
          </h1>
          
          <div className="space-y-4 mb-6">
            <p className="text-gray-600 dark:text-gray-400">
              Sua conta e todos os dados associados foram permanentemente removidos 
              do TaskFlow, conforme solicitado.
            </p>
            
            <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-4">
              <h3 className="font-semibold text-green-800 dark:text-green-300 mb-2">
                ✅ Confirmação LGPD
              </h3>
              <p className="text-sm text-green-700 dark:text-green-300">
                Seus dados pessoais foram excluídos em conformidade com a Lei Geral 
                de Proteção de Dados (LGPD). Mantemos apenas logs anônimos para 
                fins de segurança e auditoria.
              </p>
            </div>
          </div>

          {!showFeedback && !feedbackSubmitted && (
            <div className="space-y-3 mb-6">
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Gostaria de nos contar o motivo da sua saída? (Opcional)
              </p>
              <Button
                variant="outline"
                onClick={() => setShowFeedback(true)}
                className="w-full"
              >
                <MessageSquare className="w-4 h-4 mr-2" />
                Deixar Feedback
              </Button>
            </div>
          )}

          {showFeedback && !feedbackSubmitted && (
            <form onSubmit={handleFeedbackSubmit} className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Motivo principal da saída:
                </label>
                <select
                  value={feedbackReason}
                  onChange={(e) => setFeedbackReason(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  required
                >
                  <option value="">Selecione um motivo</option>
                  <option value="nao_uso_mais">Não uso mais</option>
                  <option value="encontrei_alternativa">Encontrei uma alternativa melhor</option>
                  <option value="muito_caro">Muito caro</option>
                  <option value="falta_funcionalidades">Falta de funcionalidades</option>
                  <option value="dificil_usar">Difícil de usar</option>
                  <option value="problemas_tecnicos">Problemas técnicos</option>
                  <option value="privacidade">Preocupações com privacidade</option>
                  <option value="outro">Outro motivo</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                  Comentários adicionais (opcional):
                </label>
                <textarea
                  value={feedback}
                  onChange={(e) => setFeedback(e.target.value)}
                  placeholder="Conte-nos como podemos melhorar..."
                  className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none bg-white dark:bg-gray-800 text-gray-900 dark:text-white"
                  rows={3}
                  maxLength={500}
                />
                <div className="text-xs text-gray-500 mt-1">
                  {feedback.length}/500 caracteres
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowFeedback(false)}
                  className="flex-1"
                >
                  Pular
                </Button>
                <Button type="submit" className="flex-1">
                  Enviar Feedback
                </Button>
              </div>
            </form>
          )}

          {feedbackSubmitted && (
            <div className="mb-6 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
              <p className="text-sm text-blue-700 dark:text-blue-300">
                <Heart className="w-4 h-4 inline mr-1" />
                Obrigado pelo seu feedback! Ele nos ajudará a melhorar o TaskFlow.
              </p>
            </div>
          )}

          <div className="space-y-4">
            <div className="text-sm text-gray-500 dark:text-gray-400">
              <p>Sentiremos sua falta! 💙</p>
              <p className="mt-1">
                Se mudar de ideia, você sempre pode criar uma nova conta.
              </p>
            </div>

            <Link to="/">
              <Button className="w-full">
                Voltar ao TaskFlow
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </Card>

        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500 dark:text-gray-400">
            Exclusão processada em {new Date().toLocaleString('pt-BR')}
          </p>
        </div>
      </div>
    </div>
  )
}