// Lista de palavras comuns em português para validação
const commonWords = [
  'a', 'e', 'o', 'de', 'do', 'da', 'em', 'um', 'uma', 'para', 'com', 'não', 'que', 'se', 'na', 'por', 'mais', 'as', 'dos', 'como', 'mas', 'foi', 'ao', 'ele', 'das', 'tem', 'à', 'seu', 'sua', 'ou', 'ser', 'quando', 'muito', 'há', 'nos', 'já', 'está', 'eu', 'também', 'só', 'pelo', 'pela', 'até', 'isso', 'ela', 'entre', 'era', 'depois', 'sem', 'mesmo', 'aos', 'ter', 'seus', 'suas', 'numa', 'pelos', 'pelas', 'esse', 'eles', 'essa', 'num', 'nem', 'suas', 'meu', 'às', 'minha', 'têm', 'numa', 'pelos', 'pelas', 'foi', 'contra', 'desde', 'sobre', 'entre', 'durante', 'antes', 'através', 'segundo', 'onde', 'porque', 'então', 'ainda', 'bem', 'pode', 'deve', 'fazer', 'dizer', 'cada', 'grande', 'novo', 'primeiro', 'último', 'bom', 'dia', 'vez', 'lugar', 'parte', 'tempo', 'casa', 'vida', 'ano', 'governo', 'mundo', 'trabalho', 'escola', 'pessoa', 'coisa', 'homem', 'mulher', 'criança', 'país', 'cidade', 'estado', 'problema', 'grupo', 'empresa', 'sistema', 'programa', 'projeto', 'produto', 'serviço', 'cliente', 'mercado', 'preço', 'valor', 'resultado', 'processo', 'informação', 'dados', 'tecnologia', 'internet', 'computador', 'telefone', 'email', 'site', 'página', 'texto', 'imagem', 'vídeo', 'música', 'filme', 'livro', 'jornal', 'revista', 'notícia', 'história', 'cultura', 'arte', 'esporte', 'jogo', 'festa', 'viagem', 'hotel', 'restaurante', 'comida', 'bebida', 'saúde', 'médico', 'hospital', 'remédio', 'doença', 'dor', 'amor', 'família', 'amigo', 'filho', 'pai', 'mãe', 'irmão', 'irmã', 'marido', 'esposa', 'namorado', 'namorada', 'dinheiro', 'banco', 'conta', 'cartão', 'comprar', 'vender', 'pagar', 'receber', 'ganhar', 'perder', 'estudar', 'aprender', 'ensinar', 'ler', 'escrever', 'falar', 'ouvir', 'ver', 'olhar', 'pensar', 'saber', 'conhecer', 'lembrar', 'esquecer', 'querer', 'gostar', 'amar', 'odiar', 'sentir', 'dormir', 'acordar', 'comer', 'beber', 'andar', 'correr', 'parar', 'sair', 'entrar', 'chegar', 'partir', 'voltar', 'ficar', 'morar', 'viver', 'morrer', 'nascer', 'crescer', 'mudar', 'começar', 'terminar', 'continuar', 'parar', 'abrir', 'fechar', 'ligar', 'desligar', 'usar', 'precisar', 'conseguir', 'tentar', 'ajudar', 'trabalhar', 'jogar', 'brincar', 'descansar', 'relaxar', 'divertir', 'sorrir', 'chorar', 'rir', 'gritar', 'cantar', 'dançar', 'desenhar', 'pintar', 'construir', 'criar', 'inventar', 'descobrir', 'encontrar', 'procurar', 'perguntar', 'responder', 'explicar', 'contar', 'mostrar', 'dar', 'receber', 'pegar', 'colocar', 'tirar', 'levar', 'trazer', 'mandar', 'enviar', 'receber', 'esperar', 'decidir', 'escolher', 'preferir', 'aceitar', 'recusar', 'concordar', 'discordar', 'brigar', 'discutir', 'conversar', 'falar', 'calar', 'gritar', 'sussurrar'
]

// Palavras relacionadas a tarefas e produtividade
const taskWords = [
  'tarefa', 'fazer', 'completar', 'finalizar', 'terminar', 'começar', 'iniciar', 'planejar', 'organizar', 'preparar', 'estudar', 'trabalhar', 'reunião', 'projeto', 'relatório', 'apresentação', 'email', 'ligação', 'comprar', 'pagar', 'agendar', 'marcar', 'consulta', 'médico', 'dentista', 'exercício', 'academia', 'corrida', 'caminhada', 'limpeza', 'casa', 'cozinhar', 'mercado', 'supermercado', 'farmácia', 'banco', 'documento', 'conta', 'fatura', 'imposto', 'declaração', 'viagem', 'passagem', 'hotel', 'reserva', 'aniversário', 'presente', 'festa', 'evento', 'curso', 'aula', 'prova', 'exame', 'entrevista', 'currículo', 'candidatura', 'aplicação', 'inscrição', 'matrícula', 'renovar', 'cancelar', 'confirmar', 'verificar', 'revisar', 'corrigir', 'atualizar', 'backup', 'salvar', 'arquivar', 'organizar', 'limpar', 'arrumar', 'consertar', 'reparar', 'manutenção', 'instalação', 'configuração', 'teste', 'análise', 'pesquisa', 'investigação', 'desenvolvimento', 'criação', 'design', 'layout', 'interface', 'funcionalidade', 'recurso', 'ferramenta', 'aplicativo', 'software', 'programa', 'sistema', 'plataforma', 'website', 'blog', 'artigo', 'post', 'publicação', 'compartilhar', 'divulgar', 'promover', 'marketing', 'vendas', 'cliente', 'fornecedor', 'parceiro', 'colaborador', 'equipe', 'time', 'grupo', 'departamento', 'setor', 'área', 'divisão', 'filial', 'matriz', 'sede', 'escritório', 'loja', 'estabelecimento', 'negócio', 'empresa', 'organização', 'instituição', 'órgão', 'entidade', 'associação', 'fundação', 'ong', 'governo', 'prefeitura', 'estado', 'federal', 'municipal', 'público', 'privado', 'particular', 'pessoal', 'profissional', 'acadêmico', 'escolar', 'universitário', 'faculdade', 'universidade', 'escola', 'colégio', 'curso', 'disciplina', 'matéria', 'assunto', 'tema', 'tópico', 'capítulo', 'seção', 'parte', 'item', 'elemento', 'componente', 'peça', 'produto', 'serviço', 'solução', 'problema', 'questão', 'dúvida', 'pergunta', 'resposta', 'solução', 'alternativa', 'opção', 'escolha', 'decisão', 'conclusão', 'resultado', 'consequência', 'efeito', 'impacto', 'influência', 'mudança', 'transformação', 'evolução', 'progresso', 'avanço', 'melhoria', 'aperfeiçoamento', 'otimização', 'eficiência', 'eficácia', 'produtividade', 'performance', 'desempenho', 'qualidade', 'excelência', 'padrão', 'norma', 'regra', 'procedimento', 'processo', 'método', 'técnica', 'estratégia', 'tática', 'abordagem', 'forma', 'maneira', 'modo', 'jeito', 'estilo', 'tipo', 'categoria', 'classe', 'grupo', 'conjunto', 'coleção', 'lista', 'relação', 'registro', 'controle', 'monitoramento', 'acompanhamento', 'supervisão', 'gestão', 'administração', 'gerenciamento', 'coordenação', 'direção', 'liderança', 'comando', 'chefia', 'responsabilidade', 'compromisso', 'obrigação', 'dever', 'direito', 'privilégio', 'benefício', 'vantagem', 'oportunidade', 'chance', 'possibilidade', 'probabilidade', 'risco', 'perigo', 'ameaça', 'desafio', 'obstáculo', 'dificuldade', 'problema', 'complicação', 'situação', 'condição', 'estado', 'status', 'posição', 'lugar', 'local', 'endereço', 'localização', 'região', 'área', 'zona', 'setor', 'bairro', 'cidade', 'município', 'estado', 'país', 'continente', 'mundo', 'planeta', 'terra', 'natureza', 'ambiente', 'meio', 'contexto', 'cenário', 'panorama', 'visão', 'perspectiva', 'ponto', 'vista', 'opinião', 'ideia', 'conceito', 'noção', 'pensamento', 'reflexão', 'consideração', 'análise', 'avaliação', 'julgamento', 'crítica', 'comentário', 'observação', 'nota', 'anotação', 'registro', 'documento', 'arquivo', 'pasta', 'diretório', 'folder', 'backup', 'cópia', 'duplicata', 'original', 'versão', 'edição', 'revisão', 'atualização', 'modificação', 'alteração', 'mudança', 'ajuste', 'correção', 'reparo', 'conserto', 'manutenção', 'cuidado', 'atenção', 'foco', 'concentração', 'dedicação', 'empenho', 'esforço', 'trabalho', 'atividade', 'ação', 'movimento', 'operação', 'função', 'papel', 'cargo', 'posição', 'emprego', 'profissão', 'carreira', 'vocação', 'talento', 'habilidade', 'competência', 'capacidade', 'potencial', 'força', 'poder', 'energia', 'vigor', 'vitalidade', 'saúde', 'bem-estar', 'qualidade', 'vida', 'existência', 'realidade', 'verdade', 'fato', 'informação', 'dado', 'detalhe', 'particular', 'específico', 'geral', 'comum', 'normal', 'regular', 'padrão', 'típico', 'característico', 'especial', 'único', 'diferente', 'distinto', 'particular', 'individual', 'pessoal', 'próprio', 'seu', 'meu', 'nosso', 'deles', 'dela', 'dele'
]

// Combina todas as palavras válidas
const validWords = [...new Set([...commonWords, ...taskWords])]

export function isValidTaskTitle(title: string): boolean {
  // Remove espaços extras e converte para minúsculas
  const cleanTitle = title.trim().toLowerCase()
  
  // Verifica se não está vazio
  if (!cleanTitle) return false
  
  // Verifica se tem pelo menos 2 caracteres
  if (cleanTitle.length < 2) return false
  
  // Verifica se não é apenas números ou caracteres especiais
  if (!/[a-záàâãéèêíïóôõöúçñ]/.test(cleanTitle)) return false
  
  // Divide em palavras
  const words = cleanTitle.split(/\s+/)
  
  // Verifica se tem pelo menos uma palavra válida
  let hasValidWord = false
  
  for (const word of words) {
    // Remove pontuação
    const cleanWord = word.replace(/[^\w\sáàâãéèêíïóôõöúçñ]/gi, '')
    
    // Verifica se a palavra tem pelo menos 2 caracteres
    if (cleanWord.length >= 2) {
      // Verifica se é uma palavra válida ou se parece com uma palavra real
      if (validWords.includes(cleanWord) || isWordLike(cleanWord)) {
        hasValidWord = true
        break
      }
    }
  }
  
  return hasValidWord
}

function isWordLike(word: string): boolean {
  // Verifica se a palavra tem padrões de uma palavra real
  // - Não tem mais de 3 consoantes seguidas
  // - Não tem mais de 2 vogais seguidas (exceto algumas exceções)
  // - Tem pelo menos uma vogal
  
  const vowels = 'aeiouáàâãéèêíïóôõöúç'
  const consonants = 'bcdfghjklmnpqrstvwxyzñ'
  
  let consecutiveConsonants = 0
  let consecutiveVowels = 0
  let hasVowel = false
  
  for (let i = 0; i < word.length; i++) {
    const char = word[i].toLowerCase()
    
    if (vowels.includes(char)) {
      hasVowel = true
      consecutiveVowels++
      consecutiveConsonants = 0
      
      // Máximo de 3 vogais seguidas (para palavras como "saúde")
      if (consecutiveVowels > 3) return false
    } else if (consonants.includes(char)) {
      consecutiveConsonants++
      consecutiveVowels = 0
      
      // Máximo de 3 consoantes seguidas
      if (consecutiveConsonants > 3) return false
    }
  }
  
  return hasVowel
}

export function getRateLimitInfo(taskCount: number, timeWindow: number): { 
  isLimited: boolean
  remainingTime: number 
} {
  const RATE_LIMIT = 30 // 30 tarefas
  const TIME_WINDOW = 3 * 60 * 1000 // 3 minutos em ms
  
  if (taskCount >= RATE_LIMIT) {
    const remainingTime = Math.max(0, TIME_WINDOW - timeWindow)
    return {
      isLimited: remainingTime > 0,
      remainingTime
    }
  }
  
  return {
    isLimited: false,
    remainingTime: 0
  }
}