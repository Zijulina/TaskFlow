/**
 * Utilitários para conformidade com a LGPD (Lei Geral de Proteção de Dados)
 * Implementa funcionalidades relacionadas aos direitos dos titulares de dados
 */

export interface LGPDDataSubject {
  userId: string
  email: string
  name?: string
  createdAt: string
}

export interface LGPDDeletionRequest {
  userId: string
  email: string
  requestTimestamp: string
  ipAddress?: string
  userAgent?: string
}

export interface LGPDDeletionReport {
  userId: string
  emailHash: string
  deletionTimestamp: string
  deletedRecords: Record<string, number>
  lgpdCompliance: boolean
  auditId: string
}

/**
 * Cria hash anônimo do email para auditoria
 * Permite rastreamento sem expor dados pessoais
 */
export function createEmailHash(email: string): string {
  // Normalizar email
  const normalizedEmail = email.toLowerCase().trim()
  
  // Em produção, usar uma biblioteca de hash criptográfico
  // Para este exemplo, usamos uma implementação simples
  let hash = 0
  for (let i = 0; i < normalizedEmail.length; i++) {
    const char = normalizedEmail.charCodeAt(i)
    hash = ((hash << 5) - hash) + char
    hash = hash & hash // Converter para 32bit integer
  }
  
  return Math.abs(hash).toString(16)
}

/**
 * Valida se uma solicitação de exclusão está em conformidade com a LGPD
 */
export function validateLGPDDeletionRequest(request: LGPDDeletionRequest): {
  isValid: boolean
  errors: string[]
} {
  const errors: string[] = []

  // Verificar campos obrigatórios
  if (!request.userId) {
    errors.push('ID do usuário é obrigatório')
  }

  if (!request.email) {
    errors.push('Email é obrigatório')
  }

  if (!request.requestTimestamp) {
    errors.push('Timestamp da solicitação é obrigatório')
  }

  // Verificar formato do email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (request.email && !emailRegex.test(request.email)) {
    errors.push('Formato de email inválido')
  }

  // Verificar se o timestamp é válido
  if (request.requestTimestamp && isNaN(Date.parse(request.requestTimestamp))) {
    errors.push('Timestamp inválido')
  }

  return {
    isValid: errors.length === 0,
    errors
  }
}

/**
 * Gera relatório de exclusão para conformidade LGPD
 */
export function generateLGPDDeletionReport(
  userId: string,
  email: string,
  deletedRecords: Record<string, number>
): LGPDDeletionReport {
  return {
    userId,
    emailHash: createEmailHash(email),
    deletionTimestamp: new Date().toISOString(),
    deletedRecords,
    lgpdCompliance: true,
    auditId: `audit_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
  }
}

/**
 * Textos padrão para conformidade LGPD
 */
export const LGPD_TEXTS = {
  DELETION_WARNING: `⚠️ ATENÇÃO: Esta ação é irreversível!

Ao excluir sua conta:
• Todos os seus dados serão apagados permanentemente
• Suas tarefas e projetos serão perdidos
• Não será possível recuperar essas informações
• Esta ação está em conformidade com a LGPD`,

  PRIVACY_RIGHTS: `📄 Direitos LGPD

Você tem o direito de solicitar a exclusão completa de seus dados pessoais conforme o Art. 18, VI da Lei Geral de Proteção de Dados (LGPD). Manteremos apenas logs anônimos para fins de segurança e auditoria.`,

  DELETION_CONFIRMATION: `✅ Confirmação LGPD

Seus dados pessoais foram excluídos em conformidade com a Lei Geral de Proteção de Dados (LGPD). Mantemos apenas logs anônimos para fins de segurança e auditoria.`,

  PRIVACY_POLICY_EXCERPT: `DIREITO DE EXCLUSÃO DE DADOS
Você pode solicitar a exclusão completa de sua conta e dados pessoais a qualquer momento através do painel de configurações. Ao excluir sua conta:
- Todos os seus dados pessoais serão permanentemente removidos
- A exclusão é processada imediatamente e de forma irreversível  
- Manteremos apenas logs anônimos para fins de segurança e auditoria
- Este direito está garantido pelo Art. 18, VI da LGPD`
}

/**
 * Configurações de retenção de dados para conformidade
 */
export const DATA_RETENTION_CONFIG = {
  // Logs de auditoria: 5 anos (prazo legal)
  AUDIT_LOGS_RETENTION_YEARS: 5,
  
  // Dados de usuário: exclusão imediata quando solicitada
  USER_DATA_RETENTION_DAYS: 0,
  
  // Backups: 30 dias para recuperação de emergência
  BACKUP_RETENTION_DAYS: 30,
  
  // Logs de segurança: 1 ano
  SECURITY_LOGS_RETENTION_YEARS: 1
}

/**
 * Valida se um período de retenção está em conformidade
 */
export function validateRetentionPeriod(
  dataType: keyof typeof DATA_RETENTION_CONFIG,
  retentionDate: Date
): boolean {
  const now = new Date()
  const config = DATA_RETENTION_CONFIG[dataType]
  
  if (typeof config === 'undefined') {
    return false
  }
  
  if (dataType.includes('YEARS')) {
    const maxRetentionDate = new Date()
    maxRetentionDate.setFullYear(now.getFullYear() - config)
    return retentionDate >= maxRetentionDate
  }
  
  if (dataType.includes('DAYS')) {
    const maxRetentionDate = new Date()
    maxRetentionDate.setDate(now.getDate() - config)
    return retentionDate >= maxRetentionDate
  }
  
  return false
}