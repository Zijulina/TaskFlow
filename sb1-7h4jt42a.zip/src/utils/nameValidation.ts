// Validação e formatação de nomes
export function validateName(name: string): { isValid: boolean; error?: string } {
  const trimmedName = name.trim()
  
  // Verifica se está vazio
  if (!trimmedName) {
    return { isValid: false, error: 'O nome é obrigatório' }
  }
  
  // Verifica tamanho mínimo e máximo
  if (trimmedName.length < 3) {
    return { isValid: false, error: 'O nome deve ter pelo menos 3 caracteres' }
  }
  
  if (trimmedName.length > 30) {
    return { isValid: false, error: 'O nome deve ter no máximo 30 caracteres' }
  }
  
  // Verifica se contém apenas letras e espaços
  const nameRegex = /^[a-zA-ZÀ-ÿ\s]+$/
  if (!nameRegex.test(trimmedName)) {
    return { isValid: false, error: 'O nome deve conter apenas letras e espaços' }
  }
  
  return { isValid: true }
}

export function getDisplayName(fullName: string): string {
  if (!fullName) return 'Usuário'
  
  const trimmedName = fullName.trim()
  
  // Pega só o primeiro nome (antes do primeiro espaço)
  let firstName = trimmedName
  if (trimmedName.includes(' ')) {
    firstName = trimmedName.split(' ')[0]
  }
  
  // Se o primeiro nome tem mais de 10 caracteres, trunca para 10
  if (firstName.length > 10) {
    return firstName.substring(0, 10)
  }
  
  // Retorna o primeiro nome (até 10 caracteres)
  return firstName
}

export function formatNameForSave(name: string): string {
  return name.trim().replace(/\s+/g, ' ') // Remove espaços extras
}