import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error(
    'Variáveis de ambiente do Supabase não encontradas. ' +
    'Certifique-se de que VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY estão definidas no arquivo .env'
  )
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Supressão de erros no console para erros esperados do Supabase
const originalConsoleError = console.error
console.error = (...args) => {
  const message = args.join(' ')
  
  // Filtra erros relacionados ao Supabase auth
  if (
    message.includes('Supabase request failed') ||
    message.includes('invalid_credentials') ||
    message.includes('Invalid login credentials')
  ) {
    // Ignora silenciosamente estes erros
    return
  }
  
  // Permite outros erros serem logados normalmente
  originalConsoleError.apply(console, args)
}

export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          name: string | null
          plan: 'free' | 'pro'
          created_at: string
        }
        Insert: {
          id: string
          email: string
          name?: string | null
          plan?: 'free' | 'pro'
          created_at?: string
        }
        Update: {
          id?: string
          email?: string
          name?: string | null
          plan?: 'free' | 'pro'
          created_at?: string
        }
      }
      tasks: {
        Row: {
          id: string
          user_id: string
          title: string
          is_done: boolean
          project_id: string | null
          priority: 'low' | 'medium' | 'high' | 'urgent'
          due_date: string | null
          estimated_time: number | null
          focus_mode: boolean
          completed_at: string | null
          value_associated: number | null
          currency: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          is_done?: boolean
          project_id?: string | null
          priority?: 'low' | 'medium' | 'high' | 'urgent'
          due_date?: string | null
          estimated_time?: number | null
          focus_mode?: boolean
          completed_at?: string | null
          value_associated?: number | null
          currency?: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          is_done?: boolean
          project_id?: string | null
          priority?: 'low' | 'medium' | 'high' | 'urgent'
          due_date?: string | null
          estimated_time?: number | null
          focus_mode?: boolean
          completed_at?: string | null
          value_associated?: number | null
          currency?: string
          created_at?: string
        }
      }
      projects: {
        Row: {
          id: string
          user_id: string
          name: string
          description: string
          color: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          description?: string
          color?: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          description?: string
          color?: string
          created_at?: string
          updated_at?: string
        }
      }
      tags: {
        Row: {
          id: string
          user_id: string
          name: string
          color: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          color?: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          color?: string
          created_at?: string
        }
      }
      subtasks: {
        Row: {
          id: string
          task_id: string
          title: string
          is_done: boolean
          created_at: string
          completed_at: string | null
        }
        Insert: {
          id?: string
          task_id: string
          title: string
          is_done?: boolean
          created_at?: string
          completed_at?: string | null
        }
        Update: {
          id?: string
          task_id?: string
          title?: string
          is_done?: boolean
          created_at?: string
          completed_at?: string | null
        }
      }
      task_tags: {
        Row: {
          task_id: string
          tag_id: string
          created_at: string
        }
        Insert: {
          task_id: string
          tag_id: string
          created_at?: string
        }
        Update: {
          task_id?: string
          tag_id?: string
          created_at?: string
        }
      }
      task_history: {
        Row: {
          id: string
          user_id: string
          task_id: string | null
          title: string
          project_name: string | null
          tags: string[] | null
          priority: string | null
          estimated_time: number | null
          completed_at: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          task_id?: string | null
          title: string
          project_name?: string | null
          tags?: string[] | null
          priority?: string | null
          estimated_time?: number | null
          completed_at: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          task_id?: string | null
          title?: string
          project_name?: string | null
          tags?: string[] | null
          priority?: string | null
          estimated_time?: number | null
          completed_at?: string
          created_at?: string
        }
      }
      productivity_stats: {
        Row: {
          id: string
          user_id: string
          week_start_date: string
          tasks_completed: number
          tasks_created: number
          total_estimated_time: number
          total_actual_time: number
          focus_sessions: number
          productivity_score: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          week_start_date: string
          tasks_completed?: number
          tasks_created?: number
          total_estimated_time?: number
          total_actual_time?: number
          focus_sessions?: number
          productivity_score?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          week_start_date?: string
          tasks_completed?: number
          tasks_created?: number
          total_estimated_time?: number
          total_actual_time?: number
          focus_sessions?: number
          productivity_score?: number
          created_at?: string
          updated_at?: string
        }
      }
      quick_notes: {
        Row: {
          id: string
          user_id: string
          content: string
          color: string
          position_x: number
          position_y: number
          is_pinned: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          content: string
          color?: string
          position_x?: number
          position_y?: number
          is_pinned?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          content?: string
          color?: string
          position_x?: number
          position_y?: number
          is_pinned?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      subtasks: {
        Row: {
          id: string
          task_id: string
          title: string
          is_done: boolean
          position: number
          created_at: string
          completed_at: string | null
        }
        Insert: {
          id?: string
          task_id: string
          title: string
          is_done?: boolean
          position?: number
          created_at?: string
          completed_at?: string | null
        }
        Update: {
          id?: string
          task_id?: string
          title?: string
          is_done?: boolean
          position?: number
          created_at?: string
          completed_at?: string | null
        }
      }
      task_templates: {
        Row: {
          id: string
          user_id: string
          name: string
          description: string
          template_data: any
          category: string
          is_public: boolean
          usage_count: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          name: string
          description?: string
          template_data: any
          category?: string
          is_public?: boolean
          usage_count?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          name?: string
          description?: string
          template_data?: any
          category?: string
          is_public?: boolean
          usage_count?: number
          created_at?: string
          updated_at?: string
        }
      }
      pomodoro_sessions: {
        Row: {
          id: string
          user_id: string
          task_id: string | null
          duration_minutes: number
          completed: boolean
          started_at: string
          completed_at: string | null
          session_type: 'work' | 'short_break' | 'long_break'
        }
        Insert: {
          id?: string
          user_id: string
          task_id?: string | null
          duration_minutes?: number
          completed?: boolean
          started_at?: string
          completed_at?: string | null
          session_type?: 'work' | 'short_break' | 'long_break'
        }
        Update: {
          id?: string
          user_id?: string
          task_id?: string | null
          duration_minutes?: number
          completed?: boolean
          started_at?: string
          completed_at?: string | null
          session_type?: 'work' | 'short_break' | 'long_break'
        }
      }
      productivity_insights: {
        Row: {
          id: string
          user_id: string
          insight_type: string
          insight_data: any
          period_start: string
          period_end: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          insight_type: string
          insight_data: any
          period_start: string
          period_end: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          insight_type?: string
          insight_data?: any
          period_start?: string
          period_end?: string
          created_at?: string
        }
      }
    }
  }
}