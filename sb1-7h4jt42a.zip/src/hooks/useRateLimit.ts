import { useState, useEffect } from 'react'
import { getRateLimitInfo } from '../utils/taskValidation'

interface RateLimitData {
  count: number
  startTime: number
}

export function useRateLimit(customerId: string) {
  const [rateLimitData, setRateLimitData] = useState<RateLimitData>({ count: 0, startTime: Date.now() })
  const [isLimited, setIsLimited] = useState(false)
  const [remainingTime, setRemainingTime] = useState(0)

  const storageKey = `taskflow-rate-limit-${customerId}`
  const TIME_WINDOW = 3 * 60 * 1000 // 3 minutos

  useEffect(() => {
    // Carrega dados do localStorage
    const saved = localStorage.getItem(storageKey)
    if (saved) {
      const data = JSON.parse(saved)
      const now = Date.now()
      
      // Se passou mais de 3 minutos, reseta o contador
      if (now - data.startTime > TIME_WINDOW) {
        const newData = { count: 0, startTime: now }
        setRateLimitData(newData)
        localStorage.setItem(storageKey, JSON.stringify(newData))
      } else {
        setRateLimitData(data)
      }
    }
  }, [customerId, storageKey])

  useEffect(() => {
    // Atualiza o status de rate limit
    const now = Date.now()
    const timeElapsed = now - rateLimitData.startTime
    const limitInfo = getRateLimitInfo(rateLimitData.count, timeElapsed)
    
    setIsLimited(limitInfo.isLimited)
    setRemainingTime(limitInfo.remainingTime)

    // Se ainda está no período de rate limit, configura um timer
    if (limitInfo.isLimited && limitInfo.remainingTime > 0) {
      const timer = setTimeout(() => {
        setIsLimited(false)
        setRemainingTime(0)
        // Reseta o contador após o período
        const newData = { count: 0, startTime: Date.now() }
        setRateLimitData(newData)
        localStorage.setItem(storageKey, JSON.stringify(newData))
      }, limitInfo.remainingTime)

      return () => clearTimeout(timer)
    }
  }, [rateLimitData, storageKey])

  const incrementCount = () => {
    const now = Date.now()
    let newData: RateLimitData

    // Se passou mais de 3 minutos, reseta
    if (now - rateLimitData.startTime > TIME_WINDOW) {
      newData = { count: 1, startTime: now }
    } else {
      newData = { ...rateLimitData, count: rateLimitData.count + 1 }
    }

    setRateLimitData(newData)
    localStorage.setItem(storageKey, JSON.stringify(newData))
  }

  const formatRemainingTime = (ms: number): string => {
    const minutes = Math.floor(ms / 60000)
    const seconds = Math.floor((ms % 60000) / 1000)
    return `${minutes}:${seconds.toString().padStart(2, '0')}`
  }

  return {
    isLimited,
    remainingTime,
    remainingTimeFormatted: formatRemainingTime(remainingTime),
    incrementCount,
    currentCount: rateLimitData.count
  }
}