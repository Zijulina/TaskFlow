import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export type TaskTemplate = {
  id: string
  user_id: string
  name: string
  description: string
  template_data: {
    title: string
    priority?: 'low' | 'medium' | 'high' | 'urgent'
    estimated_time?: number
    subtasks?: string[]
    tags?: string[]
  }
  category: string
  is_public: boolean
  usage_count: number
  created_at: string
  updated_at: string
}

export function useTaskTemplates() {
  const { user } = useAuth()
  const [templates, setTemplates] = useState<TaskTemplate[]>([])
  const [publicTemplates, setPublicTemplates] = useState<TaskTemplate[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) {
      setTemplates([])
      setPublicTemplates([])
      setLoading(false)
      return
    }

    const fetchTemplates = async () => {
      // Fetch user's own templates
      const { data: userTemplates } = await supabase
        .from('task_templates')
        .select('*')
        .eq('user_id', user.id)
        .order('usage_count', { ascending: false })

      if (userTemplates) {
        setTemplates(userTemplates)
      }

      // Fetch public templates
      const { data: publicTemplatesData } = await supabase
        .from('task_templates')
        .select('*')
        .eq('is_public', true)
        .neq('user_id', user.id)
        .order('usage_count', { ascending: false })
        .limit(10)

      if (publicTemplatesData) {
        setPublicTemplates(publicTemplatesData)
      }

      setLoading(false)
    }

    fetchTemplates()
  }, [user])

  const createTemplate = async (
    name: string,
    description: string,
    templateData: TaskTemplate['template_data'],
    category: string = 'geral',
    isPublic: boolean = false
  ) => {
    if (!user) return

    const { data, error } = await supabase
      .from('task_templates')
      .insert({
        user_id: user.id,
        name: name.trim(),
        description: description.trim(),
        template_data: templateData,
        category,
        is_public: isPublic
      })
      .select()
      .single()

    if (!error) {
      setTemplates(prev => [data, ...prev])
    }

    return { data, error }
  }

  const updateTemplate = async (id: string, updates: Partial<TaskTemplate>) => {
    const { data, error } = await supabase
      .from('task_templates')
      .update(updates)
      .eq('id', id)
      .select()
      .single()

    if (!error) {
      setTemplates(prev => prev.map(template => 
        template.id === id ? data : template
      ))
    }

    return { data, error }
  }

  const deleteTemplate = async (id: string) => {
    const { error } = await supabase
      .from('task_templates')
      .delete()
      .eq('id', id)

    if (!error) {
      setTemplates(prev => prev.filter(template => template.id !== id))
    }

    return { error }
  }

  const useTemplate = async (templateId: string) => {
    // Increment usage count
    const { error } = await supabase
      .from('task_templates')
      .update({ usage_count: supabase.sql`usage_count + 1` })
      .eq('id', templateId)

    return { error }
  }

  return {
    templates,
    publicTemplates,
    loading,
    createTemplate,
    updateTemplate,
    deleteTemplate,
    useTemplate,
  }
}