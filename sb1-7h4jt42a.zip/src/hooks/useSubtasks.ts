import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export type Subtask = {
  id: string
  task_id: string
  title: string
  is_done: boolean
  position: number
  created_at: string
  completed_at: string | null
}

export function useSubtasks(taskId: string | null) {
  const { user } = useAuth()
  const [subtasks, setSubtasks] = useState<Subtask[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user || !taskId) {
      setSubtasks([])
      setLoading(false)
      return
    }

    const fetchSubtasks = async () => {
      const { data, error } = await supabase
        .from('subtasks')
        .select('*')
        .eq('task_id', taskId)
        .order('position', { ascending: true })

      if (!error && data) {
        setSubtasks(data)
      }

      setLoading(false)
    }

    fetchSubtasks()
  }, [user, taskId])

  const createSubtask = async (title: string) => {
    if (!user || !taskId) return

    const maxPosition = Math.max(...subtasks.map(s => s.position), -1)

    const { data, error } = await supabase
      .from('subtasks')
      .insert({
        task_id: taskId,
        title: title.trim(),
        position: maxPosition + 1
      })
      .select()
      .single()

    if (!error) {
      setSubtasks(prev => [...prev, data])
    }

    return { data, error }
  }

  const toggleSubtask = async (id: string, isDone: boolean) => {
    const { data, error } = await supabase
      .from('subtasks')
      .update({ 
        is_done: isDone,
        completed_at: isDone ? new Date().toISOString() : null
      })
      .eq('id', id)
      .select()
      .single()

    if (!error) {
      setSubtasks(prev => prev.map(subtask => 
        subtask.id === id ? data : subtask
      ))
    }

    return { data, error }
  }

  const updateSubtask = async (id: string, updates: Partial<Subtask>) => {
    const { data, error } = await supabase
      .from('subtasks')
      .update(updates)
      .eq('id', id)
      .select()
      .single()

    if (!error) {
      setSubtasks(prev => prev.map(subtask => 
        subtask.id === id ? data : subtask
      ))
    }

    return { data, error }
  }

  const deleteSubtask = async (id: string) => {
    const { error } = await supabase
      .from('subtasks')
      .delete()
      .eq('id', id)

    if (!error) {
      setSubtasks(prev => prev.filter(subtask => subtask.id !== id))
    }

    return { error }
  }

  const reorderSubtasks = async (reorderedSubtasks: Subtask[]) => {
    const updates = reorderedSubtasks.map((subtask, index) => ({
      id: subtask.id,
      position: index
    }))

    for (const update of updates) {
      await supabase
        .from('subtasks')
        .update({ position: update.position })
        .eq('id', update.id)
    }

    setSubtasks(reorderedSubtasks)
  }

  return {
    subtasks,
    loading,
    createSubtask,
    toggleSubtask,
    updateSubtask,
    deleteSubtask,
    reorderSubtasks,
  }
}