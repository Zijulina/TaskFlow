import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export type PomodoroSession = {
  id: string
  user_id: string
  task_id: string | null
  duration_minutes: number
  completed: boolean
  started_at: string
  completed_at: string | null
  session_type: 'work' | 'short_break' | 'long_break'
}

export function usePomodoro() {
  const { user } = useAuth()
  const [sessions, setSessions] = useState<PomodoroSession[]>([])
  const [currentSession, setCurrentSession] = useState<PomodoroSession | null>(null)
  const [timeLeft, setTimeLeft] = useState(0)
  const [isRunning, setIsRunning] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) {
      setSessions([])
      setLoading(false)
      return
    }

    const fetchSessions = async () => {
      const { data, error } = await supabase
        .from('pomodoro_sessions')
        .select('*')
        .eq('user_id', user.id)
        .order('started_at', { ascending: false })
        .limit(10)

      if (!error && data) {
        setSessions(data)
      }

      setLoading(false)
    }

    fetchSessions()
  }, [user])

  // Timer effect
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null

    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(time => {
          if (time <= 1) {
            completeSession()
            return 0
          }
          return time - 1
        })
      }, 1000)
    }

    return () => {
      if (interval) clearInterval(interval)
    }
  }, [isRunning, timeLeft])

  const startSession = async (
    taskId: string | null = null,
    duration: number = 25,
    sessionType: PomodoroSession['session_type'] = 'work'
  ) => {
    if (!user) return

    const { data, error } = await supabase
      .from('pomodoro_sessions')
      .insert({
        user_id: user.id,
        task_id: taskId,
        duration_minutes: duration,
        session_type: sessionType
      })
      .select()
      .single()

    if (!error) {
      setCurrentSession(data)
      setTimeLeft(duration * 60) // Convert to seconds
      setIsRunning(true)
      setSessions(prev => [data, ...prev])
    }

    return { data, error }
  }

  const pauseSession = () => {
    setIsRunning(false)
  }

  const resumeSession = () => {
    setIsRunning(true)
  }

  const stopSession = async () => {
    if (!currentSession) return

    setIsRunning(false)
    setCurrentSession(null)
    setTimeLeft(0)

    // Don't mark as completed if stopped early
    return { error: null }
  }

  const completeSession = async () => {
    if (!currentSession) return

    const { data, error } = await supabase
      .from('pomodoro_sessions')
      .update({ 
        completed: true,
        completed_at: new Date().toISOString()
      })
      .eq('id', currentSession.id)
      .select()
      .single()

    if (!error) {
      setSessions(prev => prev.map(session => 
        session.id === currentSession.id ? data : session
      ))
      setCurrentSession(null)
      setIsRunning(false)
      setTimeLeft(0)
    }

    return { data, error }
  }

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  const getTodayStats = () => {
    const today = new Date().toDateString()
    const todaySessions = sessions.filter(session => 
      new Date(session.started_at).toDateString() === today && session.completed
    )

    return {
      completedSessions: todaySessions.length,
      totalMinutes: todaySessions.reduce((sum, session) => sum + session.duration_minutes, 0),
      workSessions: todaySessions.filter(s => s.session_type === 'work').length
    }
  }

  return {
    sessions,
    currentSession,
    timeLeft,
    isRunning,
    loading,
    startSession,
    pauseSession,
    resumeSession,
    stopSession,
    completeSession,
    formatTime,
    getTodayStats,
  }
}