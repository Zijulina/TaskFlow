import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export type Task = {
  id: string
  user_id: string
  title: string
  is_done: boolean
  project_id: string | null
  priority: 'low' | 'medium' | 'high' | 'urgent'
  priority: 'low' | 'medium' | 'high' | 'urgent' | null
  due_date: string | null
  estimated_time: number | null
  focus_mode: boolean
  completed_at: string | null
  value_associated: number | null
  currency: string
  created_at: string
}

export type Project = {
  id: string
  user_id: string
  name: string
  description: string
  color: string
  created_at: string
  updated_at: string
}

export type Tag = {
  id: string
  user_id: string
  name: string
  color: string
  created_at: string
}

export type Subtask = {
  id: string
  task_id: string
  title: string
  is_done: boolean
  created_at: string
  completed_at: string | null
}

export function useTasks() {
  const { user } = useAuth()
  const [tasks, setTasks] = useState<Task[]>([])
  const [projects, setProjects] = useState<Project[]>([])
  const [tags, setTags] = useState<Tag[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) {
      setTasks([])
      setProjects([])
      setTags([])
      setLoading(false)
      return
    }

    const fetchData = async () => {
      // Fetch tasks
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (!error) {
        setTasks(data || [])
      }

      // Fetch projects
      const { data: projectsData } = await supabase
        .from('projects')
        .select('*')
        .eq('user_id', user.id)
        .order('name')

      if (projectsData) {
        setProjects(projectsData)
      }

      // Fetch tags
      const { data: tagsData } = await supabase
        .from('tags')
        .select('*')
        .eq('user_id', user.id)
        .order('name')

      if (tagsData) {
        setTags(tagsData)
      }

      setLoading(false)
    }

    fetchData()
  }, [user])

  const addTask = async (
    title: string, 
    options?: {
      project_id?: string
      priority?: 'low' | 'medium' | 'high' | 'urgent' | null
      due_date?: string
      estimated_time?: number
      value_associated?: number
      currency?: string
    }
  ) => {
    if (!user) return

    const { data, error } = await supabase
      .from('tasks')
      .insert({
        title,
        user_id: user.id,
        is_done: false,
        project_id: options?.project_id || null,
        priority: options?.priority === undefined ? null : options.priority,
        due_date: options?.due_date || null,
        estimated_time: options?.estimated_time || null,
        value_associated: options?.value_associated || null,
        currency: options?.currency || 'BRL',
        focus_mode: false
      })
      .select()
      .single()

    if (!error) {
      setTasks(prev => [data, ...prev])
    }

    return { data, error }
  }

  const toggleTask = async (id: string, is_done: boolean) => {
    const { data, error } = await supabase
      .from('tasks')
      .update({ 
        is_done,
        completed_at: is_done ? new Date().toISOString() : null
      })
      .eq('id', id)
      .select()
      .single()

    if (!error) {
      setTasks(prev => prev.map(task => 
        task.id === id ? data : task
      ))
    }

    return { data, error }
  }

  const deleteTask = async (id: string) => {
    const { error } = await supabase
      .from('tasks')
      .delete()
      .eq('id', id)

    if (!error) {
      setTasks(prev => prev.filter(task => task.id !== id))
    }

    return { error }
  }

  const updateTaskCost = async (id: string, cost: number, currency: string) => {
    const { data, error } = await supabase
      .from('tasks')
      .update({ 
        value_associated: cost,
        currency: currency
      })
      .eq('id', id)
      .select()
      .single()

    if (!error) {
      setTasks(prev => prev.map(task => 
        task.id === id ? data : task
      ))
    }

    return { data, error }
  }

  const addProject = async (name: string, description?: string, color?: string) => {
    if (!user) return

    const { data, error } = await supabase
      .from('projects')
      .insert({
        name,
        description: description || '',
        color: color || '#3b82f6',
        user_id: user.id
      })
      .select()
      .single()

    if (!error) {
      setProjects(prev => [...prev, data])
    }

    return { data, error }
  }

  const addTag = async (name: string, color?: string) => {
    if (!user) return

    const { data, error } = await supabase
      .from('tags')
      .insert({
        name,
        color: color || '#6b7280',
        user_id: user.id
      })
      .select()
      .single()

    if (!error) {
      setTags(prev => [...prev, data])
    }

    return { data, error }
  }

  const deleteProject = async (id: string) => {
    const { error } = await supabase
      .from('projects')
      .delete()
      .eq('id', id)

    if (!error) {
      setProjects(prev => prev.filter(project => project.id !== id))
    }

    return { error }
  }
  return {
    tasks,
    projects,
    tags,
    loading,
    addTask,
    toggleTask,
    deleteTask,
    updateTaskCost,
    addProject,
    deleteProject,
    addTag,
  }
}