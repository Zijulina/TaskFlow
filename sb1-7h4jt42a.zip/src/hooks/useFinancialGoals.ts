import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export type FinancialGoal = {
  id: string
  user_id: string
  title: string
  target_amount: number
  current_amount: number
  target_date: string | null
  is_completed: boolean
  created_at: string
  updated_at: string
}

export type Investment = {
  id: string
  user_id: string
  investment_type: 'renda_fixa' | 'renda_variavel' | 'criptomoedas' | 'outros'
  amount: number
  created_at: string
  updated_at: string
}

export function useFinancialGoals() {
  const { user } = useAuth()
  const [goals, setGoals] = useState<FinancialGoal[]>([])
  const [investments, setInvestments] = useState<Investment[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) {
      setGoals([])
      setInvestments([])
      setLoading(false)
      return
    }

    const fetchData = async () => {
      // Fetch financial goals
      const { data: goalsData } = await supabase
        .from('financial_goals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (goalsData) {
        setGoals(goalsData)
      }

      // Fetch investments
      const { data: investmentsData } = await supabase
        .from('investments')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (investmentsData) {
        setInvestments(investmentsData)
      }

      setLoading(false)
    }

    fetchData()
  }, [user])

  const createGoal = async (title: string, targetAmount: number, currentAmount: number = 0, targetDate?: string | null) => {
    if (!user) return

    const { data, error } = await supabase
      .from('financial_goals')
      .insert({
        user_id: user.id,
        title,
        target_amount: targetAmount,
        current_amount: currentAmount,
        target_date: targetDate,
        is_completed: currentAmount >= targetAmount
      })
      .select()
      .single()

    if (!error) {
      setGoals(prev => [data, ...prev])
    }

    return { data, error }
  }

  const updateGoal = async (id: string, updates: Partial<FinancialGoal>) => {
    const { data, error } = await supabase
      .from('financial_goals')
      .update({
        ...updates,
        is_completed: updates.current_amount && updates.target_amount 
          ? updates.current_amount >= updates.target_amount 
          : undefined
      })
      .eq('id', id)
      .select()
      .single()

    if (!error) {
      setGoals(prev => prev.map(goal => 
        goal.id === id ? data : goal
      ))
    }

    return { data, error }
  }

  const deleteGoal = async (id: string) => {
    const { error } = await supabase
      .from('financial_goals')
      .delete()
      .eq('id', id)

    if (!error) {
      setGoals(prev => prev.filter(goal => goal.id !== id))
    }

    return { error }
  }

  const createInvestment = async (investmentType: Investment['investment_type'], amount: number) => {
    if (!user) return

    const { data, error } = await supabase
      .from('investments')
      .insert({
        user_id: user.id,
        investment_type: investmentType,
        amount
      })
      .select()
      .single()

    if (!error) {
      setInvestments(prev => [data, ...prev])
    }

    return { data, error }
  }

  const updateInvestment = async (id: string, updates: Partial<Investment>) => {
    const { data, error } = await supabase
      .from('investments')
      .update(updates)
      .eq('id', id)
      .select()
      .single()

    if (!error) {
      setInvestments(prev => prev.map(investment => 
        investment.id === id ? data : investment
      ))
    }

    return { data, error }
  }

  const deleteInvestment = async (id: string) => {
    const { error } = await supabase
      .from('investments')
      .delete()
      .eq('id', id)

    if (!error) {
      setInvestments(prev => prev.filter(investment => investment.id !== id))
    }

    return { error }
  }

  return {
    goals,
    investments,
    loading,
    createGoal,
    updateGoal,
    deleteGoal,
    createInvestment,
    updateInvestment,
    deleteInvestment,
  }
}