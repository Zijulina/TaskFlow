import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export type QuickNote = {
  id: string
  user_id: string
  content: string
  color: string
  position_x: number
  position_y: number
  is_pinned: boolean
  created_at: string
  updated_at: string
}

export function useQuickNotes() {
  const { user } = useAuth()
  const [notes, setNotes] = useState<QuickNote[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) {
      setNotes([])
      setLoading(false)
      return
    }

    const fetchNotes = async () => {
      const { data, error } = await supabase
        .from('quick_notes')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })

      if (!error && data) {
        setNotes(data)
      }

      setLoading(false)
    }

    fetchNotes()
  }, [user])

  const createNote = async (content: string, color: string = '#fbbf24') => {
    if (!user) return

    const { data, error } = await supabase
      .from('quick_notes')
      .insert({
        user_id: user.id,
        content: content.trim(),
        color,
        position_x: Math.floor(Math.random() * 200),
        position_y: Math.floor(Math.random() * 200)
      })
      .select()
      .single()

    if (!error) {
      setNotes(prev => [data, ...prev])
    }

    return { data, error }
  }

  const updateNote = async (id: string, updates: Partial<QuickNote>) => {
    const { data, error } = await supabase
      .from('quick_notes')
      .update(updates)
      .eq('id', id)
      .select()
      .single()

    if (!error) {
      setNotes(prev => prev.map(note => 
        note.id === id ? data : note
      ))
    }

    return { data, error }
  }

  const deleteNote = async (id: string) => {
    const { error } = await supabase
      .from('quick_notes')
      .delete()
      .eq('id', id)

    if (!error) {
      setNotes(prev => prev.filter(note => note.id !== id))
    }

    return { error }
  }

  const updatePosition = async (id: string, x: number, y: number) => {
    const { error } = await supabase
      .from('quick_notes')
      .update({ position_x: x, position_y: y })
      .eq('id', id)

    if (!error) {
      setNotes(prev => prev.map(note => 
        note.id === id ? { ...note, position_x: x, position_y: y } : note
      ))
    }

    return { error }
  }

  return {
    notes,
    loading,
    createNote,
    updateNote,
    deleteNote,
    updatePosition,
  }
}