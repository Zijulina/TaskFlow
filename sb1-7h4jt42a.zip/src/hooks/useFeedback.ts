import { useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export function useFeedback() {
  const { user } = useAuth()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submitFeedback = async (message: string, rating: number) => {
    if (!user) {
      setError('Usuário não autenticado')
      return { data: null, error: 'Usuário não autenticado' }
    }

    setLoading(true)
    setError(null)

    try {
      const { data, error } = await supabase
        .from('feedback')
        .insert({
          user_id: user.id,
          message: message.trim(),
          rating
        })
        .select()
        .single()

      if (error) {
        setError(error.message)
        return { data: null, error: error.message }
      }

      return { data, error: null }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro desconhecido'
      setError(errorMessage)
      return { data: null, error: errorMessage }
    } finally {
      setLoading(false)
    }
  }

  return {
    submitFeedback,
    loading,
    error,
  }
}