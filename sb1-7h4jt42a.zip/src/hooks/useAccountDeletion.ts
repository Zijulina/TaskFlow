import { useState } from 'react'
import { supabase } from '../lib/supabase'

export function useAccountDeletion() {
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const deleteAccount = async (email: string, password: string, confirmationText: string) => {
    setLoading(true)
    setError(null)

    try {
      // Obter token de autenticação atual
      const { data: { session }, error: sessionError } = await supabase.auth.getSession()
      
      if (sessionError || !session?.access_token) {
        throw new Error('Usuário não autenticado')
      }

      // Chamar Edge Function para exclusão segura
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/delete-account`
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email.trim().toLowerCase(),
          password,
          confirmationText
        }),
      })

      const result = await response.json()

      if (!response.ok) {
        throw new Error(result.details || result.error || 'Erro ao excluir conta')
      }

      // Limpar dados locais imediatamente
      localStorage.clear()
      sessionStorage.clear()

      return { success: true, data: result }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Erro desconhecido'
      setError(errorMessage)
      console.error('Erro na exclusão de conta:', err)
      return { success: false, error: errorMessage }
    } finally {
      setLoading(false)
    }
  }

  return {
    deleteAccount,
    loading,
    error,
  }
}