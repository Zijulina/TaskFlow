import { useEffect, useState } from 'react'
import { User } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Get initial session
    const getSession = async () => {
      const { data: { session }, error } = await supabase.auth.getSession()
      
      // If there's an error or no session, clear any stale tokens
      if (error || !session) {
        await supabase.auth.signOut()
      }
      
      setUser(session?.user ?? null)
      setLoading(false)
    }

    getSession()

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setUser(session?.user ?? null)
        setLoading(false)
      }
    )

    return () => subscription.unsubscribe()
  }, [])

  const signUp = async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    })
    return { data, error }
  }

  const signUpWithName = async (email: string, password: string, name: string) => {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    })
    
    // If signup successful, create user profile with name
    if (!error && data.user) {
      await supabase.from('users').upsert({
        id: data.user.id,
        email: data.user.email!,
        name: name.trim(),
        plan: 'free'
      })
    }
    
    return { data, error }
  }

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email: email.trim().toLowerCase(),
        password,
      })
      
      if (error) {
        if (error.code === 'invalid_credentials') {
          console.warn('Login failed: Invalid credentials')
        } else {
          console.error('Login error:', error.message)
        }
      }
      
      return { data, error }
    } catch (err) {
      console.error('Unexpected login error:', err)
      return { 
        data: null, 
        error: { 
          message: 'Erro inesperado ao fazer login. Tente novamente.',
          code: 'unexpected_error'
        } as any
      }
    }
  }

  const signOut = async (saveTheme?: () => void) => {
    try {
      // Save theme before logout if function provided
      if (saveTheme) {
        saveTheme()
      }
      
      // Clear sessions (non-blocking for speed)
      supabase.auth.signOut({ scope: 'global' }).catch(console.error)
      
      // Clear user state immediately
      setUser(null)
      
      return { error: null }
    } catch (err) {
      console.error('SignOut error:', err)
      // Even if there's an error, clear local state
      setUser(null)
      return { error: err }
    }
  }

  return {
    user,
    loading,
    signUp,
    signUpWithName,
    signIn,
    signOut,
  }
}