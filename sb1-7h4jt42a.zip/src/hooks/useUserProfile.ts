import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export type UserProfile = {
  id: string
  email: string
  name: string | null
  plan: 'free' | 'pro'
  created_at: string
}

export function useUserProfile() {
  const { user } = useAuth()
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) {
      setProfile(null)
      setLoading(false)
      return
    }

    const fetchProfile = async () => {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', user.id)

      if (!error && data && data.length > 0) {
        setProfile(data[0])
      } else if (!error && data && data.length === 0) {
        // User doesn't exist, create profile
        const { data: newProfile, error: insertError } = await supabase
          .from('users')
          .insert({
            id: user.id,
            email: user.email!,
            name: null,
            plan: 'free'
          })
          .select()
          .single()

        if (!insertError) {
          setProfile(newProfile)
        } else if (insertError.code === '23505') {
          // Duplicate key error - profile was created by another process
          // Refetch the profile
          const { data: existingProfile, error: refetchError } = await supabase
            .from('users')
            .select('*')
            .eq('id', user.id)
            .single()
          
          if (!refetchError) {
            setProfile(existingProfile)
          }
        }
      }
      
      setLoading(false)
    }

    fetchProfile()
  }, [user])

  const upgradeToPro = async () => {
    if (!user) return

    const { data, error } = await supabase
      .from('users')
      .update({ plan: 'pro' })
      .eq('id', user.id)
      .select()
      .single()

    if (!error) {
      setProfile(data)
    }

    return { data, error }
  }

  const updateProfile = async (updates: { name?: string; email?: string }) => {
    if (!user) return { data: null, error: 'User not authenticated' }

    const { data, error } = await supabase
      .from('users')
      .update(updates)
      .eq('id', user.id)
      .select()
      .single()

    if (!error) {
      setProfile(data)
    }

    return { data, error }
  }

  return {
    profile,
    loading,
    upgradeToPro,
    updateProfile,
  }
}