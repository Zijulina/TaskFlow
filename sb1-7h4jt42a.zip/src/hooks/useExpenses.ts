import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export type Expense = {
  id: string
  user_id: string
  title: string
  amount: number
  category: string
  expense_date: string
  created_at: string
  updated_at: string
}

export function useExpenses() {
  const { user } = useAuth()
  const [expenses, setExpenses] = useState<Expense[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) {
      setExpenses([])
      setLoading(false)
      return
    }

    const fetchExpenses = async () => {
      const { data, error } = await supabase
        .from('expenses')
        .select('*')
        .eq('user_id', user.id)
        .order('expense_date', { ascending: false })

      if (!error && data) {
        setExpenses(data)
      }

      setLoading(false)
    }

    fetchExpenses()
  }, [user])

  const createExpense = async (title: string, amount: number, category: string, expenseDate: string) => {
    if (!user) return

    const { data, error } = await supabase
      .from('expenses')
      .insert({
        user_id: user.id,
        title,
        amount,
        category,
        expense_date: expenseDate
      })
      .select()
      .single()

    if (!error) {
      setExpenses(prev => [data, ...prev])
    }

    return { data, error }
  }

  const updateExpense = async (id: string, updates: Partial<Expense>) => {
    const { data, error } = await supabase
      .from('expenses')
      .update(updates)
      .eq('id', id)
      .select()
      .single()

    if (!error) {
      setExpenses(prev => prev.map(expense => 
        expense.id === id ? data : expense
      ))
    }

    return { data, error }
  }

  const deleteExpense = async (id: string) => {
    const { error } = await supabase
      .from('expenses')
      .delete()
      .eq('id', id)

    if (!error) {
      setExpenses(prev => prev.filter(expense => expense.id !== id))
    }

    return { error }
  }

  return {
    expenses,
    loading,
    createExpense,
    updateExpense,
    deleteExpense,
  }
}