import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useAuth } from './useAuth'

export type SubscriptionStatus = 
  | 'not_started'
  | 'incomplete'
  | 'incomplete_expired'
  | 'trialing'
  | 'active'
  | 'past_due'
  | 'canceled'
  | 'unpaid'
  | 'paused'

export type UserSubscription = {
  customer_id: string
  subscription_id: string | null
  subscription_status: SubscriptionStatus
  price_id: string | null
  current_period_start: number | null
  current_period_end: number | null
  cancel_at_period_end: boolean | null
  payment_method_brand: string | null
  payment_method_last4: string | null
}

export function useSubscription() {
  const { user } = useAuth()
  const [subscription, setSubscription] = useState<UserSubscription | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!user) {
      setSubscription(null)
      setLoading(false)
      return
    }

    const fetchSubscription = async () => {
      try {
        const { data, error } = await supabase
          .from('stripe_user_subscriptions')
          .select('*')
          .maybeSingle()

        if (error) {
          console.error('Erro ao buscar assinatura:', error)
        } else {
          setSubscription(data)
        }
      } catch (err) {
        console.error('Erro inesperado ao buscar assinatura:', err)
      } finally {
        setLoading(false)
      }
    }

    fetchSubscription()
  }, [user])

  const isActive = subscription?.subscription_status === 'active'
  const isPro = isActive && subscription?.price_id === 'price_1Rpa5iPJ1AWhgUPiM5hGnQrk'
  const isEssential = isActive && subscription?.price_id === 'price_essential_monthly'
  const hasPremiumFeatures = isPro || isEssential

  return {
    subscription,
    loading,
    isActive,
    isPro,
    isEssential,
    hasPremiumFeatures,
  }
}